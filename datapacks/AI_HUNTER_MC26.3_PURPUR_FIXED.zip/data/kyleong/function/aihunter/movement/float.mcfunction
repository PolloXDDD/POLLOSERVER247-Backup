execute if score @s aihunter_d matches ..25 if score @s aihunter_dy matches ..-1000 store result entity @s Motion[1] double 0.01 run scoreboard players set motion aihunter_dummy -60

execute if score @s aihunter_intent matches 0 if score @s aihunter_d matches ..25 if score @s aihunter_dy matches 2000.. if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,nbt={OnGround:1b}] store result entity @s Motion[1] double 0.01 run scoreboard players set motion aihunter_dummy -60

execute if score @s aihunter_intent matches 0 if score @s aihunter_d matches ..25 if score @s aihunter_dy matches 2000.. if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,nbt={OnGround:1b}] unless block ~ ~-2 ~ #kyleong:aihunter/space run function kyleong:aihunter/action/build/tower1

execute if score @s aihunter_intent matches 0 if score @s aihunter_d matches ..25 if score @s aihunter_dy matches 2000.. if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,nbt={OnGround:0b}] store result entity @s Motion[1] double 0.01 run scoreboard players set motion aihunter_dummy 45
