function kyleong:aihunter/adjust/position



execute unless block ~-0.6 ~ ~ #kyleong:aihunter/passable run setblock ~ ~ ~ minecraft:ladder[facing=east] keep

execute unless block ~0.6 ~ ~ #kyleong:aihunter/passable run setblock ~ ~ ~ minecraft:ladder[facing=west] keep

execute unless block ~ ~ ~0.6 #kyleong:aihunter/passable run setblock ~ ~ ~ minecraft:ladder[facing=north] keep

execute unless block ~ ~ ~-0.6 #kyleong:aihunter/passable run setblock ~ ~ ~ minecraft:ladder[facing=south] keep

scoreboard players set @s aihunter_fall 0


#debug reporting

execute if score debug aihunter_dummy matches 1 run say mlg: executed (nether)
