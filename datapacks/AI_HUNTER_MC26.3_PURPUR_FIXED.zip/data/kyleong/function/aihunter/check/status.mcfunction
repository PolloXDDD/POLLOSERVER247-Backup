tellraw @s {"text":"----------------------------------------","color":"white","bold":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/menu"}}


execute store result score #simulate aihunter_dummy if entity @e[tag=aihunter_simulate]

tellraw @s [{"text":"simulate: ","color":"white"},{"score":{"name":"#simulate","objective":"aihunter_dummy"},"color":"red"}]


execute store result score #intent-1 aihunter_dummy if entity @e[scores={aihunter_intent=-1}]

execute store result score #intent0 aihunter_dummy if entity @e[scores={aihunter_intent=0}]

execute store result score #intent1 aihunter_dummy if entity @e[scores={aihunter_intent=1}]

execute store result score #intent2 aihunter_dummy if entity @e[scores={aihunter_intent=2}]

tellraw @s [{"text":"intent -1: ","color":"white"},{"score":{"name":"#intent-1","objective":"aihunter_dummy"},"color":"red"},{"text":"   intent 0: ","color":"white"},{"score":{"name":"#intent0","objective":"aihunter_dummy"},"color":"red"}]

tellraw @s [{"text":"intent 1: ","color":"white"},{"score":{"name":"#intent1","objective":"aihunter_dummy"},"color":"red"},{"text":"    intent 2: ","color":"white"},{"score":{"name":"#intent2","objective":"aihunter_dummy"},"color":"red"}]


tellraw @s {"text":"----------------------------------------","color":"white","bold":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/check/status"}}
