function kyleong:aihunter/set

function kyleong:aihunter/check/version

execute as @a run function kyleong:aihunter/menu
