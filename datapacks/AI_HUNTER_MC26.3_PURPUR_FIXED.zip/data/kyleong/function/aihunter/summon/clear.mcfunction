fill ~2 ~-1 ~2 ~-2 ~-1 ~-2 minecraft:obsidian replace

fill ~2 ~2 ~2 ~-2 ~ ~-2 minecraft:air replace
