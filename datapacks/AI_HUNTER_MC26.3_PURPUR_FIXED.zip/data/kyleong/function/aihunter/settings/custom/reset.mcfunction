playsound minecraft:ui.button.click master @s ~ ~ ~ .1

execute if score started aihunter_dummy matches 0 run data remove storage minecraft:aihunter_custom armor

execute if score started aihunter_dummy matches 0 run data remove storage minecraft:aihunter_custom name

execute if score started aihunter_dummy matches 0 run tellraw @s {"text":"Hunter's Appearance Has Been Reset.","color":"gold"}

execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
