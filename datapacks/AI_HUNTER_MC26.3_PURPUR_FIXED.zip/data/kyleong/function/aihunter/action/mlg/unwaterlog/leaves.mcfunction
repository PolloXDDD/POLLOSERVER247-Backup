##MC1.16 leaves
#1

execute if block ~ ~ ~ minecraft:acacia_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:acacia_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:azalea_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:azalea_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:birch_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:birch_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:dark_oak_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:dark_oak_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:flowering_azalea_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:flowering_azalea_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:jungle_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:jungle_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:oak_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:spruce_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:spruce_leaves[waterlogged=false,persistent=true] replace


#2

execute if block ~ ~ ~ minecraft:acacia_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:acacia_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:azalea_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:azalea_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:birch_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:birch_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:dark_oak_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:dark_oak_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:flowering_azalea_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:flowering_azalea_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:jungle_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:jungle_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:oak_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:spruce_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:spruce_leaves[waterlogged=false,persistent=false] replace


##MC1.17-1.20 added leaves
#1

execute if block ~ ~ ~ minecraft:cherry_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:cherry_leaves[waterlogged=false,persistent=true] replace

execute if block ~ ~ ~ minecraft:mangrove_leaves[waterlogged=true,persistent=true] run setblock ~ ~ ~ minecraft:mangrove_leaves[waterlogged=false,persistent=true] replace


#2

execute if block ~ ~ ~ minecraft:cherry_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:cherry_leaves[waterlogged=false,persistent=false] replace

execute if block ~ ~ ~ minecraft:mangrove_leaves[waterlogged=true,persistent=false] run setblock ~ ~ ~ minecraft:mangrove_leaves[waterlogged=false,persistent=false] replace
