##as @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)

particle minecraft:block{block_state:"minecraft:stone"} ~ ~.1 ~ .6 0 .6 .1 20 normal
particle happy_villager ~ ~1.5 ~ .5 .5 .5 .1 3 normal

scoreboard players add @s aihunter_ani 1

execute if score quality aihunter_dummy matches 0 run scoreboard players set @s aihunter_ani 0

execute if score quality aihunter_dummy matches 2 if score @s aihunter_ani matches 1 run data merge entity @s {"Pose":{"Head":[60f,0f,0f],"LeftArm":[20f,0f,0f],"RightArm":[-20f,0f,0f],"LeftLeg":[0f,0f,0f],"RightLeg":[0f,0f,0f]}}

execute unless score quality aihunter_dummy matches 2 if score @s aihunter_ani matches 1 run data merge entity @s {"Pose":{"LeftArm":[20f,0f,0f],"RightArm":[-20f,0f,0f],"LeftLeg":[0f,0f,0f],"RightLeg":[0f,0f,0f]}}

execute if score @s aihunter_ani matches 2 run data merge entity @s {"Pose":{"LeftArm":[-20f,0f,0f],"RightArm":[20f,0f,0f]}}

execute if score @s aihunter_ani matches 2.. run scoreboard players set @s aihunter_ani 0
