scoreboard players add @s aihunter_ani 1

execute if score @s aihunter_ani matches 1 run data merge entity @s {"Pose":{"LeftArm":[20f,0f,0f],"RightArm":[-20f,0f,0f],"LeftLeg":[-20f,0f,0f],"RightLeg":[20f,0f,0f]}}

execute if score @s aihunter_ani matches 2 run data merge entity @s {"Pose":{"LeftArm":[40f,0f,0f],"RightArm":[-40f,0f,0f],"LeftLeg":[-40f,0f,0f],"RightLeg":[40f,0f,0f]}}

execute if score @s aihunter_ani matches 3 run data merge entity @s {"Pose":{"LeftArm":[60f,0f,0f],"RightArm":[-60f,0f,0f],"LeftLeg":[-60f,0f,0f],"RightLeg":[60f,0f,0f]}}

execute if score @s aihunter_ani matches 4 run data merge entity @s {"Pose":{"LeftArm":[40f,0f,0f],"RightArm":[-40f,0f,0f],"LeftLeg":[-40f,0f,0f],"RightLeg":[40f,0f,0f]}}

execute if score @s aihunter_ani matches 5 run data merge entity @s {"Pose":{"LeftArm":[20f,0f,0f],"RightArm":[-20f,0f,0f],"LeftLeg":[-20f,0f,0f],"RightLeg":[20f,0f,0f]}}

execute if score @s aihunter_ani matches 6 run data merge entity @s {"Pose":{"LeftArm":[0f,0f,0f],"RightArm":[0f,0f,0f],"LeftLeg":[0f,0f,0f],"RightLeg":[0f,0f,0f]}}

execute if score @s aihunter_ani matches 7 run data merge entity @s {"Pose":{"LeftArm":[-20f,0f,0f],"RightArm":[20f,0f,0f],"LeftLeg":[20f,0f,0f],"RightLeg":[-20f,0f,0f]}}

execute if score @s aihunter_ani matches 8 run data merge entity @s {"Pose":{"LeftArm":[-40f,0f,0f],"RightArm":[40f,0f,0f],"LeftLeg":[40f,0f,0f],"RightLeg":[-40f,0f,0f]}}

execute if score @s aihunter_ani matches 9 run data merge entity @s {"Pose":{"LeftArm":[-60f,0f,0f],"RightArm":[60f,0f,0f],"LeftLeg":[60f,0f,0f],"RightLeg":[-60f,0f,0f]}}

execute if score @s aihunter_ani matches 10 run data merge entity @s {"Pose":{"LeftArm":[-40f,0f,0f],"RightArm":[40f,0f,0f],"LeftLeg":[40f,0f,0f],"RightLeg":[-40f,0f,0f]}}

execute if score @s aihunter_ani matches 11 run data merge entity @s {"Pose":{"LeftArm":[-20f,0f,0f],"RightArm":[20f,0f,0f],"LeftLeg":[20f,0f,0f],"RightLeg":[-20f,0f,0f]}}

execute if score @s aihunter_ani matches 12 run data merge entity @s {"Pose":{"LeftArm":[0f,0f,0f],"RightArm":[0f,0f,0f],"LeftLeg":[0f,0f,0f],"RightLeg":[0f,0f,0f]}}

execute if score @s aihunter_ani matches 12.. run scoreboard players set @s aihunter_ani 0
