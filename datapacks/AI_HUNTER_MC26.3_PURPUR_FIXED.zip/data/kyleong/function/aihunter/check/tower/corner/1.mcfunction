
execute if block ~-0.8 ~-0.5 ~ #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-0.8 ~-1.5 ~ #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-0.8 ~-2.5 ~ #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~ ~-0.5 ~-0.8 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~ ~-1.5 ~-0.8 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~ ~-2.5 ~-0.8 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~-0.8 ~-0.5 ~-1.4 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-0.8 ~-1.5 ~-1.4 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-0.8 ~-2.5 ~-1.4 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~-1.4 ~-0.5 ~-0.8 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-1.4 ~-1.5 ~-0.8 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-1.4 ~-2.5 ~-0.8 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1
