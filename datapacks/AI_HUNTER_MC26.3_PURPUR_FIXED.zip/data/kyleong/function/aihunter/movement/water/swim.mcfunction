execute if score difficulty aihunter_dummy matches 1 store result entity @s Motion[0] double 0.00026 run scoreboard players get @s aihunter_vx

execute if score difficulty aihunter_dummy matches 1 store result entity @s Motion[2] double 0.00026 run scoreboard players get @s aihunter_vz


execute if score difficulty aihunter_dummy matches 2 store result entity @s Motion[0] double 0.00028 run scoreboard players get @s aihunter_vx

execute if score difficulty aihunter_dummy matches 2 store result entity @s Motion[2] double 0.00028 run scoreboard players get @s aihunter_vz


execute if score difficulty aihunter_dummy matches 3.. store result entity @s Motion[0] double 0.0003 run scoreboard players get @s aihunter_vx

execute if score difficulty aihunter_dummy matches 3.. store result entity @s Motion[2] double 0.0003 run scoreboard players get @s aihunter_vz


function kyleong:aihunter/movement/float

scoreboard players set #valve2 aihunter_dummy 1

function kyleong:aihunter/act/inliquid
