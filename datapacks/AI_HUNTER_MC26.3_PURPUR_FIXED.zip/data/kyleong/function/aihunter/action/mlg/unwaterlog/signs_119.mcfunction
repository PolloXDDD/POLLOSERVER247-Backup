##MC1.19 added wall signs (mangrove)
#1

execute if block ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=false,facing=east] replace


#2

execute if block ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=false,facing=north] replace


#3

execute if block ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=false,facing=south] replace


#4

execute if block ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:mangrove_wall_sign[waterlogged=false,facing=west] replace


##MC1.19 added signs (mangrove)
#0

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=0] replace


#1

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=1] replace


#2

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=2] replace


#3

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=3] replace


#4

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=4] replace


#5

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=5] replace


#6

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=6] replace


#7

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=7] replace


#8

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=8] replace


#9

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=9] replace


#10

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=10] replace


#11

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=11] replace


#12

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=12] replace


#13

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=13] replace


#14

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=14] replace


#15

execute if block ~ ~ ~ minecraft:mangrove_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:mangrove_sign[waterlogged=false,rotation=15] replace
