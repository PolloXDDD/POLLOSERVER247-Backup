schedule clear kyleong:aihunter/check/movestart/loop

schedule clear kyleong:aihunter/check/movestart/start

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:blindness 999999 99 true

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:weakness 999999 90 true


execute if score started aihunter_dummy matches 1 run tellraw @a {"text":"[AI Hunter] Challenge paused, click to resume","color":"light_purple","click_event":{"action":"run_command","command":"/function kyleong:aihunter/check/resume"},"hover_event":{"action":"show_text","value":[{"text":"click to resume","color":"light_purple"}]}}

execute unless score started aihunter_dummy matches 1 run tellraw @s {"text":"No Ongoing Challenge","color":"red"}

execute if score started aihunter_dummy matches 1 run scoreboard players set pause aihunter_dummy 1
