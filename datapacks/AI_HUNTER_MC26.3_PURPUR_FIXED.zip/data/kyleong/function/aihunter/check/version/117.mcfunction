execute if block ~ ~ ~ minecraft:azalea

scoreboard players set version aihunter_dummy 117
