##^aihunter/always
##as at server

#execute as @p[predicate=kyleong:aihunter/dimension/nether] at @s unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn] run function kyleong:aihunter/dimension/aec

execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn,limit=1,sort=nearest] run function kyleong:aihunter/check/respawn
