
execute if score started aihunter_dummy matches 0 run scoreboard players add hunters aihunter_dummy 1

execute unless score hunters aihunter_dummy matches 1..50 run scoreboard players set hunters aihunter_dummy 1

execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/settings/menu/1


execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
