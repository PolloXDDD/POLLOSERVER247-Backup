playsound minecraft:ui.button.click master @s ~ ~ ~ .1
tellraw @s {"text":"----------------------------------------","color":"yellow","bold":true}


tellraw @s {"text":"Misode's Predicate Generator is used:","color":"gold"}


tellraw @s {"text":"[URL] Misode's Twitter (@misode_)","color":"yellow","click_event":{"action":"open_url","url":"https://twitter.com/misode_"},"hover_event":{"action":"show_text","value":[{"text":"URL To: twitter.com","color":"gold"}]}}


tellraw @s {"text":"[URL] Misode's Youtube","color":"yellow","click_event":{"action":"open_url","url":"https://www.youtube.com/c/misode"},"hover_event":{"action":"show_text","value":[{"text":"URL To: youtube.com","color":"gold"}]}}


tellraw @s {"text":"[URL] Misode's Data Pack Generators","color":"yellow","click_event":{"action":"open_url","url":"https://misode.github.io"},"hover_event":{"action":"show_text","value":[{"text":"URL To: github.io","color":"gold"}]}}



tellraw @s {"text":"TheDestruc7i0n's Advancements Generator is used:","color":"gold"}


tellraw @s {"text":"[URL] TheDestruc7i0n's Twitter (@thedestruc7i0n)","color":"yellow","click_event":{"action":"open_url","url":"https://twitter.com/thedestruc7i0n"},"hover_event":{"action":"show_text","value":[{"text":"URL To: twitter.com","color":"gold"}]}}


tellraw @s {"text":"[URL] TheDestruc7i0n's Youtube","color":"yellow","click_event":{"action":"open_url","url":"https://www.youtube.com/c/TheDestruc7i0n"},"hover_event":{"action":"show_text","value":[{"text":"URL To: youtube.com","color":"gold"}]}}


tellraw @s {"text":"[URL] TheDestruc7i0n's Website","color":"yellow","click_event":{"action":"open_url","url":"https://thedestruc7i0n.ca"},"hover_event":{"action":"show_text","value":[{"text":"URL To: TheDestruc7i0n's website","color":"gold"}]}}

tellraw @s {"text":"MCStacker's Command Generator is used:","color":"gold"}


tellraw @s {"text":"[URL] McStacker's Twitter (@PyroStunts)","color":"yellow","click_event":{"action":"open_url","url":"https://twitter.com/PyroStunts"},"hover_event":{"action":"show_text","value":[{"text":"URL To: twitter.com","color":"gold"}]}}


tellraw @s {"text":"[URL] MCStacker's Discord","color":"yellow","click_event":{"action":"open_url","url":"https://discord.com/invite/WCb6GNf"},"hover_event":{"action":"show_text","value":[{"text":"URL To: discord.com","color":"gold"}]}}


tellraw @s {"text":"[URL] MCStacker's Command Generator","color":"yellow","click_event":{"action":"open_url","url":"https://mcstacker.net"},"hover_event":{"action":"show_text","value":[{"text":"URL To: mcstacker.net","color":"gold"}]}}


tellraw @s {"text":"About me (Kyleong):","color":"gold"}


#tellraw @s {"text":"[URL] My Twitter (@kyleong123)","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: twitter.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://twitter.com/kyleong123"}}


tellraw @s {"text":"[URL] My Youtube","color":"yellow","click_event":{"action":"open_url","url":"https://www.youtube.com/channel/UCGclCRGdWUjJdVcHLZfdaOg"},"hover_event":{"action":"show_text","value":[{"text":"URL To: youtube.com","color":"gold"}]}}


tellraw @s {"text":"[URL] My Planet Minecraft, where I post my creations","color":"yellow","click_event":{"action":"open_url","url":"https://www.planetminecraft.com/member/kyleong/"},"hover_event":{"action":"show_text","value":[{"text":"URL To: planetminecraft.com","color":"gold"}]}}


tellraw @s {"text":" "}
tellraw @s {"text":"<Start Menu>","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/menu"},"hover_event":{"action":"show_text","value":[{"text":"Go back to the main menu.","color":"aqua"}]}}


tellraw @s {"text":"----------------------------------------","color":"yellow","bold":true}
