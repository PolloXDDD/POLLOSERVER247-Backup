#MC1.19 added walls (mud brick)

execute if block ~ ~ ~ minecraft:mud_brick_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:mud_brick_wall[waterlogged=false] replace
