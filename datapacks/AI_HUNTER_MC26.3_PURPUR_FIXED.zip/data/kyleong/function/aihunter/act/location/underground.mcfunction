
execute unless score @s aihunter_busy matches 1.. if score @s aihunter_y2 matches 57000.. run function kyleong:aihunter/action/build/tower


#below bedrock level, tower out. For two version's different bedrock level.

execute unless score @s aihunter_busy matches 1.. if score version aihunter_dummy matches 117 if score @s aihunter_y1 matches ..4999 if score @s aihunter_dy matches 1.. run function kyleong:aihunter/action/build/tower
execute unless score @s aihunter_busy matches 1.. if score version aihunter_dummy matches 118 if score @s aihunter_y1 matches ..-60001 if score @s aihunter_dy matches 1.. run function kyleong:aihunter/action/build/tower


#behaviour above bedrock level. For two version's different bedrock level.

execute unless score @s aihunter_busy matches 1.. run function kyleong:aihunter/find/action/underground/facing
