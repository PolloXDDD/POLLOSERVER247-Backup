##as at @e[type=minecraft:vindicator,tag=aihunter]
#always

execute store result score @s aihunter_hp run data get entity @s Health 10

execute if score falldamage aihunter_dummy matches 1 if predicate kyleong:aihunter/falling run data modify entity @s fall_distance set value -999.0d

execute if score difficulty aihunter_dummy matches ..3 if predicate kyleong:aihunter/onfire if predicate kyleong:aihunter/dimension/nether unless predicate kyleong:aihunter/fire_resistance if predicate kyleong:aihunter/chance/30 run function kyleong:aihunter/action/potion/fire


#engaged: target available

execute unless predicate kyleong:aihunter/idle if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/act/engaged


#suppose in act/onground but moved here for head animation.

execute unless score @s aihunter_busy matches ..0 run scoreboard players remove @s aihunter_busy 1
