advancement revoke @s only kyleong:aihunter/test
say aihunter test
