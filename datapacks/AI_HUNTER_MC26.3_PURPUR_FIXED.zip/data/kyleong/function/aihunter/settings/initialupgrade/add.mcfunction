scoreboard players add initialupgrade aihunter_dummy 1

execute unless score initialupgrade aihunter_dummy matches 0..6 run scoreboard players set initialupgrade aihunter_dummy 0

function kyleong:aihunter/settings/menu/2
