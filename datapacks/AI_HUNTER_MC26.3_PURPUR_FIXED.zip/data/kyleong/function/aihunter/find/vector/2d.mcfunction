#vx, vz in 2d

execute store result score @s aihunter_x1 run data get entity @s Pos[0] 10

execute store result score @s aihunter_z1 run data get entity @s Pos[2] 10

execute store result score @s aihunter_x2 run data get entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] Pos[0] 10

execute store result score @s aihunter_z2 run data get entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] Pos[2] 10

scoreboard players operation @s aihunter_x2 -= @s aihunter_x1

scoreboard players operation @s aihunter_z2 -= @s aihunter_z1

scoreboard players operation @s aihunter_vx = @s aihunter_x2

scoreboard players operation @s aihunter_vz = @s aihunter_z2

scoreboard players operation @s aihunter_vx *= #1000 aihunter_dummy

scoreboard players operation @s aihunter_vz *= #1000 aihunter_dummy


scoreboard players operation @s aihunter_x2 *= @s aihunter_x2

scoreboard players operation @s aihunter_z2 *= @s aihunter_z2

scoreboard players operation @s aihunter_x2 += @s aihunter_z2

scoreboard players operation in math_sqrt = @s aihunter_x2
function kyleong:aihunter/math/sqrt/run
scoreboard players operation @s aihunter_d = out math_sqrt

scoreboard players operation @s aihunter_vx /= @s aihunter_d

scoreboard players operation @s aihunter_vz /= @s aihunter_d


#facing

execute if score @s aihunter_intent matches -1 run function kyleong:aihunter/reverse

execute if score @s aihunter_intent matches 1 unless entity @p[distance=..5,gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/reverse

execute unless score #valve1 aihunter_dummy matches 1 facing entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] feet run tp @s ~ ~ ~ ~ ~

scoreboard players set #valve1 aihunter_dummy 0
