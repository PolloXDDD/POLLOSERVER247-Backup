playsound minecraft:entity.iron_golem.repair player @a ~ ~ ~ .6 2

particle minecraft:block{block_state:"minecraft:oak_planks"} ~ ~1 ~ .1 .6 .1 .1 20 normal @a

fill ~-0.3 ~1.5 ~-0.3 ~0.3 ~1.5 ~0.3 minecraft:air replace #kyleong:aihunter/falling

execute positioned ~ ~1.5 ~ unless block ~ ~ ~ #kyleong:aihunter/unbreakable unless block ~ ~ ~ #kyleong:aihunter/passable run function kyleong:aihunter/action/break/block


execute if score showhp aihunter_dummy matches 1 in minecraft:the_end run function kyleong:aihunter/hp
