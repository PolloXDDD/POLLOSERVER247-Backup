playsound minecraft:ui.button.click master @s ~ ~ ~ .1

execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/settings/custom/edit

execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
