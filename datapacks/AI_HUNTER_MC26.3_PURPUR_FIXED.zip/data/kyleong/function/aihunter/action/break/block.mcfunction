execute unless block ~ ~ ~ #kyleong:aihunter/space unless block ~ ~ ~ #kyleong:aihunter/unbreakable run function kyleong:aihunter/action/break/block1
