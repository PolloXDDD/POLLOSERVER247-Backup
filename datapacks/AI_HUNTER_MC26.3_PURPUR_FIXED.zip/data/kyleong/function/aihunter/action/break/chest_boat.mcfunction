execute if entity @s[type=minecraft:oak_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:oak_chest_boat",count:1}}
execute if entity @s[type=minecraft:spruce_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:spruce_chest_boat",count:1}}
execute if entity @s[type=minecraft:birch_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:birch_chest_boat",count:1}}
execute if entity @s[type=minecraft:jungle_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:jungle_chest_boat",count:1}}
execute if entity @s[type=minecraft:acacia_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:acacia_chest_boat",count:1}}
execute if entity @s[type=minecraft:cherry_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:cherry_chest_boat",count:1}}
execute if entity @s[type=minecraft:dark_oak_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:dark_oak_chest_boat",count:1}}
execute if entity @s[type=minecraft:pale_oak_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:pale_oak_chest_boat",count:1}}
execute if entity @s[type=minecraft:mangrove_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:mangrove_chest_boat",count:1}}
execute if entity @s[type=minecraft:bamboo_chest_raft] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:bamboo_chest_raft",count:1}}
execute if entity @s[type=minecraft:poplar_chest_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:poplar_chest_boat",count:1}}







kill @s
