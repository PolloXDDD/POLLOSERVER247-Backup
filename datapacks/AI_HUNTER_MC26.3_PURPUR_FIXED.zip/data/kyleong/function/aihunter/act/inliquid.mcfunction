execute unless score @s aihunter_busy matches 1.. run function kyleong:aihunter/find/action/liquid/facing

execute unless score @s aihunter_busy matches ..0 run scoreboard players remove @s aihunter_busy 1
