tellraw @a {"text":"AI Hunter pre-set applied","color":"green"}
