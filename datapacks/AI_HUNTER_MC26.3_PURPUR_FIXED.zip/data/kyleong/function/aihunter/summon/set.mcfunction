##as @e[type=#kyleong:aihunter/hunter,tag=aihunter,predicate=kyleong:aihunter/fresh]
#visuals

scoreboard players set @s[type=minecraft:vindicator] aihunter_hp 200

data modify entity @s[type=minecraft:armor_stand] equipment set from storage minecraft:aihunter_custom armor

data modify entity @s[type=minecraft:vindicator] CustomName set from storage minecraft:aihunter_custom name

execute as @e[type=minecraft:area_effect_cloud,tag=aihunter_name] run function kyleong:aihunter/summon/set_name

execute if entity @s[type=minecraft:armor_stand] unless data storage minecraft:aihunter_custom armor run function kyleong:aihunter/summon/set_buff


#intention

scoreboard players set @s[type=minecraft:vindicator] aihunter_intent 0

scoreboard players operation @s[type=minecraft:vindicator] aihunter_upgrade = initialupgrade aihunter_dummy

scoreboard players set @s[type=minecraft:vindicator,scores={aihunter_upgrade=..0}] aihunter_intent 1

scoreboard players set @s[type=minecraft:vindicator,scores={aihunter_upgrade=1},predicate=kyleong:aihunter/chance/50] aihunter_intent 1

execute if score difficulty aihunter_dummy matches 4.. run scoreboard players set @s[type=minecraft:vindicator] aihunter_intent 0


#spreadplayers

execute unless score dimension aihunter_dummy matches 1..2 run spreadplayers ~ ~ 1 6 false @s[type=minecraft:vindicator]

#execute if score dimension aihunter_dummy matches 1 run spreadplayers ~ ~ 1 6 under 100 false @s[type=minecraft:vindicator]


#hunters' stats

function kyleong:aihunter/adjust/damage

execute unless score dimension aihunter_dummy matches 0 run effect give @s minecraft:weakness 5 90 true

execute unless score dimension aihunter_dummy matches 0 run effect give @s minecraft:blindness 5 99 true

execute unless score dimension aihunter_dummy matches 0 run effect give @s minecraft:resistance 8 5 true

execute if score difficulty aihunter_dummy matches 4.. run effect give @s[type=minecraft:vindicator] minecraft:resistance 999999 6 true
