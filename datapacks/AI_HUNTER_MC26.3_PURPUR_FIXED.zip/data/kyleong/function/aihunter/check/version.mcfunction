# Compatibility port targets Minecraft Java 26.3.
# 120 selects the newest legacy feature branch throughout the original AI.
scoreboard players set version aihunter_dummy 120
