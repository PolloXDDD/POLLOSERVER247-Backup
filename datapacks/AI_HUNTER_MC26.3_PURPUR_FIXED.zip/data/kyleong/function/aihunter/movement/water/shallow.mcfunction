execute store result entity @s Motion[0] double 0.00017 run scoreboard players get @s aihunter_vx

execute store result entity @s Motion[2] double 0.00017 run scoreboard players get @s aihunter_vz

function kyleong:aihunter/movement/float

scoreboard players set #valve2 aihunter_dummy 1

function kyleong:aihunter/act/inliquid
