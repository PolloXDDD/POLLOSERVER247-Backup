function kyleong:aihunter/find/vector/2d

scoreboard players set #valve2 aihunter_dummy 0

execute positioned ~ ~-1 ~ if predicate kyleong:aihunter/water positioned ~ ~-1 ~ if predicate kyleong:aihunter/water positioned ~ ~2 ~ run function kyleong:aihunter/movement/water/deep

execute unless score #valve2 aihunter_dummy matches 1 run function kyleong:aihunter/movement/water/shallow
