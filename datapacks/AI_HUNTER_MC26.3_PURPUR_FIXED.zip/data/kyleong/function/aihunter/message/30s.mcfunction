tellraw @a {"text":"30 Seconds Left Until All Hunters Are Activated!","color":"aqua"}

playsound minecraft:block.bell.resonate master @a
