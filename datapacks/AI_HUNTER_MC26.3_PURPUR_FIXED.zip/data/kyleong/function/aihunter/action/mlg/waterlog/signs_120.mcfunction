##MC1.20 added wall signs
#1

execute if block ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=true,facing=east] replace


#2

execute if block ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=true,facing=north] replace


#3

execute if block ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=true,facing=south] replace


#4

execute if block ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:bamboo_wall_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:cherry_wall_sign[waterlogged=true,facing=west] replace


##MC1.20 added signs
#0

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=0] replace


#1

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=1] replace


#2

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=2] replace


#3

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=3] replace


#4

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=4] replace


#5

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=5] replace


#6

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=6] replace


#7

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=7] replace


#8

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=8] replace


#9

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=9] replace


#10

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=10] replace


#11

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=11] replace


#12

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=12] replace


#13

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=13] replace


#14

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=14] replace


#15

execute if block ~ ~ ~ minecraft:bamboo_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:bamboo_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:cherry_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:cherry_sign[waterlogged=true,rotation=15] replace


##MC1.20 added wall hanging signs
#1

execute if block ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=true,facing=east] replace


#2

execute if block ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=true,facing=north] replace


#3

execute if block ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=true,facing=south] replace


#4

execute if block ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:bamboo_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:cherry_wall_hanging_sign[waterlogged=true,facing=west] replace


##MC1.20 added hanging signs
#0,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=0,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=0,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=0,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=0,attached=true] replace


#1,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=1,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=1,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=1,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=1,attached=true] replace


#2,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=2,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=2,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=2,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=2,attached=true] replace


#3,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=3,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=3,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=3,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=3,attached=true] replace


#4,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=4,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=4,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=4,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=4,attached=true] replace


#5,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=5,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=5,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=5,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=5,attached=true] replace


#6,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=6,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=6,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=6,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=6,attached=true] replace


#7,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=7,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=7,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=7,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=7,attached=true] replace


#8,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=8,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=8,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=8,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=8,attached=true] replace


#9,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=9,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=9,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=9,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=9,attached=true] replace


#10,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=10,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=10,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=10,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=10,attached=true] replace


#11,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=11,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=11,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=11,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=11,attached=true] replace


#12,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=12,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=12,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=12,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=12,attached=true] replace


#13,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=13,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=13,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=13,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=13,attached=true] replace


#14,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=14,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=14,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=14,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=14,attached=true] replace


#15,1

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=15,attached=true] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=15,attached=true] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=15,attached=true] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=15,attached=true] replace


#0,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=0,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=0,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=0,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=0,attached=false] replace


#1,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=1,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=1,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=1,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=1,attached=false] replace


#2,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=2,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=2,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=2,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=2,attached=false] replace


#3,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=3,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=3,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=3,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=3,attached=false] replace


#4,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=4,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=4,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=4,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=4,attached=false] replace


#5,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=5,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=5,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=5,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=5,attached=false] replace


#6,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=6,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=6,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=6,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=6,attached=false] replace


#7,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=7,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=7,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=7,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=7,attached=false] replace


#8,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=8,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=8,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=8,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=8,attached=false] replace


#9,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=9,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=9,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=9,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=9,attached=false] replace


#10,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=10,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=10,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=10,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=10,attached=false] replace


#11,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=11,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=11,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=11,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=11,attached=false] replace


#12,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=12,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=12,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=12,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=12,attached=false] replace


#13,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=13,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=13,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=13,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=13,attached=false] replace


#14,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=14,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=14,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=14,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=14,attached=false] replace


#15,2

execute if block ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=false,rotation=15,attached=false] run setblock ~ ~ ~ minecraft:bamboo_hanging_sign[waterlogged=true,rotation=15,attached=false] replace

execute if block ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=false,rotation=15,attached=false] run setblock ~ ~ ~ minecraft:cherry_hanging_sign[waterlogged=true,rotation=15,attached=false] replace


##old material wall hanging signs
#1

execute if block ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=true,facing=east] replace


#2

execute if block ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=true,facing=north] replace


#3

execute if block ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=true,facing=south] replace


#4

execute if block ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:acacia_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:birch_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:crimson_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:dark_oak_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:jungle_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:spruce_wall_hanging_sign[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:warped_wall_hanging_sign[waterlogged=true,facing=west] replace


##old material hanging signs
#0

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=0] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=0] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=0] replace


#1

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=1] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=1] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=1] replace


#2

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=2] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=2] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=2] replace


#3

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=3] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=3] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=3] replace


#4

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=4] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=4] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=4] replace


#5

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=5] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=5] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=5] replace


#6

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=6] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=6] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=6] replace


#7

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=7] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=7] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=7] replace


#8

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=8] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=8] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=8] replace


#9

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=9] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=9] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=9] replace


#10

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=10] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=10] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=10] replace


#11

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=11] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=11] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=11] replace


#12

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=12] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=12] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=12] replace


#13

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=13] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=13] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=13] replace


#14

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=14] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=14] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=14] replace


#15

execute if block ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:acacia_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:birch_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:crimson_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:dark_oak_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:jungle_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:oak_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:spruce_hanging_sign[waterlogged=true,rotation=15] replace

execute if block ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=false,rotation=15] run setblock ~ ~ ~ minecraft:warped_hanging_sign[waterlogged=true,rotation=15] replace


#data

data modify block ~ ~ ~ is_waxed set from storage minecraft:aihunter temp.is_waxed

data modify block ~ ~ ~ front_text set from storage minecraft:aihunter temp.front_text

data modify block ~ ~ ~ back_text set from storage minecraft:aihunter temp.back_text
