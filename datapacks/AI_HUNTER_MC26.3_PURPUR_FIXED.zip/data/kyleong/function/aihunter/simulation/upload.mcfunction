##as @e[type=minecraft:vindicator,tag=aihunter] at @e[type=minecraft:area_effect_cloud,tag=aihunter_worldspawn,limit=1,sort=arbitrary]

scoreboard players add simulation aihunter_dummy 1

summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_register","aihunter_simulate"],"Duration":9000000}

execute if score debug aihunter_dummy matches 1 run say simulation:upload


#transfer hunter's data (position)

execute store result score @s aihunter_x1 run data get entity @s Pos[0] 10

execute store result score @s aihunter_z1 run data get entity @s Pos[2] 10

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_x1 = @s aihunter_x1

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_z1 = @s aihunter_z1


#transfer hunter's data (hp & more)

execute unless score @s aihunter_hp matches 1.. run scoreboard players set @s aihunter_hp 200

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_hp = @s aihunter_hp

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_intent = @s aihunter_intent

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_potion = @s aihunter_potion

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_arrow = @s aihunter_arrow


#transfer hunter's data (upgrades)

scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_upgrade = @s aihunter_upgrade

execute if score @s aihunter_uptimer matches -2147483648..214748364 run scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_uptimer = @s aihunter_uptimer

execute unless score @s aihunter_upgrade matches 1.. unless score @s aihunter_uptimer matches 1.. run scoreboard players set @s aihunter_uptimer 83

execute if score @s aihunter_upgrade matches 1 unless score @s aihunter_uptimer matches 1.. run scoreboard players set @s aihunter_uptimer 1400

execute if score @s aihunter_upgrade matches 2 unless score @s aihunter_uptimer matches 1.. run scoreboard players set @s aihunter_uptimer 1200

execute if score @s aihunter_upgrade matches 3 unless score @s aihunter_uptimer matches 1.. run scoreboard players set @s aihunter_uptimer 4000


#transfer hunter's data (idle time, weakness time)

execute store result score @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] aihunter_busy run data get entity @s active_effects[{id:"minecraft:blindness"}].duration 1


#lock registered aec

tag @e[type=minecraft:area_effect_cloud,tag=aihunter_register,limit=1,sort=arbitrary] remove aihunter_register


#kill hunter

execute at @s run kill @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest]

kill @s
