##^aihunter/always
##as at server
#if score wincondition aihunter_dummy matches 6

execute unless score pause aihunter_dummy matches 1 if score timer1 aihunter_dummy matches 0.. run scoreboard players remove timer1 aihunter_dummy 1

execute unless score pause aihunter_dummy matches 1 if score timer1 aihunter_dummy matches 0.. run function kyleong:aihunter/survivetimer/calculate

execute if score timer1 aihunter_dummy matches 0.. run function kyleong:aihunter/survivetimer/show

execute if score timer1 aihunter_dummy matches -10..0 run function kyleong:aihunter/win
