execute as @e[type=#kyleong:aihunter/hunter,tag=aihunter] at @s run function kyleong:aihunter/summon/return/cdp1
