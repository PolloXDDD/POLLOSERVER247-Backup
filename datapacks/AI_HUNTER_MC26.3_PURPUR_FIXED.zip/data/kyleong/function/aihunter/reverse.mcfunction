scoreboard players operation @s aihunter_vx *= #-1 aihunter_dummy

scoreboard players operation @s aihunter_vz *= #-1 aihunter_dummy

execute facing entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] feet run tp @s ~ ~ ~ ~180 ~

scoreboard players set #valve1 aihunter_dummy 1
