execute if block ~ ~ ~ minecraft:lantern[waterlogged=false,hanging=true] run setblock ~ ~ ~ minecraft:lantern[waterlogged=true,hanging=true] replace

execute if block ~ ~ ~ minecraft:soul_lantern[waterlogged=false,hanging=true] run setblock ~ ~ ~ minecraft:soul_lantern[waterlogged=true,hanging=true] replace

execute if block ~ ~ ~ minecraft:lantern[waterlogged=false,hanging=false] run setblock ~ ~ ~ minecraft:lantern[waterlogged=true,hanging=false] replace

execute if block ~ ~ ~ minecraft:soul_lantern[waterlogged=false,hanging=false] run setblock ~ ~ ~ minecraft:soul_lantern[waterlogged=true,hanging=false] replace


execute if block ~ ~ ~ minecraft:glow_lichen run function kyleong:aihunter/action/mlg/waterlog/lichens


execute if score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf run setblock ~ ~ ~ minecraft:water destroy

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=east,tilt=none] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=east,tilt=none] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=north,tilt=none] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=north,tilt=none] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=south,tilt=none] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=south,tilt=none] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=west,tilt=none] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=west,tilt=none] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=east,tilt=partial] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=east,tilt=partial] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=north,tilt=partial] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=north,tilt=partial] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=south,tilt=partial] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=south,tilt=partial] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=west,tilt=partial] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=west,tilt=partial] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=east,tilt=unstable] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=east,tilt=unstable] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=north,tilt=unstable] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=north,tilt=unstable] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=south,tilt=unstable] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=south,tilt=unstable] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=west,tilt=unstable] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=west,tilt=unstable] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=east,tilt=full] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=east,tilt=full] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=north,tilt=full] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=north,tilt=full] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=south,tilt=full] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=south,tilt=full] replace

execute unless score @s aihunter_upgrade matches 2.. if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false,facing=west,tilt=full] run setblock ~ ~ ~ minecraft:big_dripleaf[waterlogged=true,facing=west,tilt=full] replace


execute if block ~ ~ ~ minecraft:mangrove_roots[waterlogged=false] run setblock ~ ~ ~ minecraft:mangrove_roots[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:mangrove_roots[waterlogged=false] run setblock ~ ~ ~ minecraft:mangrove_roots[waterlogged=true] replace


execute if block ~ ~ ~ minecraft:pointed_dripstone[waterlogged=false,vertical_direction=down] run setblock ~ ~ ~ minecraft:pointed_dripstone[waterlogged=true,vertical_direction=down] replace


execute if block ~ ~ ~ minecraft:pointed_dripstone[waterlogged=false,vertical_direction=up] run setblock ~ ~ ~ minecraft:pointed_dripstone[waterlogged=true,vertical_direction=up] replace


execute if block ~ ~ ~ minecraft:sculk_sensor[waterlogged=false] run setblock ~ ~ ~ minecraft:sculk_sensor[waterlogged=true,power=15,sculk_sensor_phase=inactive] replace


execute if block ~ ~ ~ minecraft:lightning_rod[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:lightning_rod[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:lightning_rod[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:lightning_rod[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:lightning_rod[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:lightning_rod[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:lightning_rod[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:lightning_rod[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:lightning_rod[waterlogged=false,facing=up] run setblock ~ ~ ~ minecraft:lightning_rod[waterlogged=true,facing=up] replace

execute if block ~ ~ ~ minecraft:lightning_rod[waterlogged=false,facing=down] run setblock ~ ~ ~ minecraft:lightning_rod[waterlogged=true,facing=down] replace


#candles

execute if block ~ ~ ~ minecraft:candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:black_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:black_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:black_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:black_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:black_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:black_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:black_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:black_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:black_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:blue_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:blue_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:blue_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:blue_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:blue_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:blue_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:blue_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:blue_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:brown_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:brown_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:brown_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:brown_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:brown_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:brown_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:brown_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:brown_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:cyan_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:cyan_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:cyan_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:cyan_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:cyan_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:cyan_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:cyan_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:cyan_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:gray_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:gray_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:gray_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:gray_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:gray_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:gray_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:gray_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:gray_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:green_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:green_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:green_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:green_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:green_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:green_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:green_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:green_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:light_blue_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:light_blue_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:light_blue_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:light_blue_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:light_blue_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:light_blue_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:light_blue_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:light_blue_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:light_gray_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:light_gray_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:light_gray_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:light_gray_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:light_gray_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:light_gray_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:light_gray_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:light_gray_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:lime_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:lime_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:lime_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:lime_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:lime_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:lime_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:lime_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:lime_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:magenta_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:magenta_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:magenta_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:magenta_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:magenta_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:magenta_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:magenta_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:magenta_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:orange_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:orange_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:orange_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:orange_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:orange_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:orange_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:orange_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:orange_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:pink_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:pink_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:pink_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:pink_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:pink_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:pink_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:pink_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:pink_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:purple_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:purple_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:purple_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:purple_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:purple_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:purple_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:purple_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:purple_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:red_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:red_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:red_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:red_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:red_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:red_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:red_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:red_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:white_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:white_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:white_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:white_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:white_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:white_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:white_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:white_candle[waterlogged=true,lit=false,candles=4] replace

execute if block ~ ~ ~ minecraft:yellow_candle[waterlogged=false,candles=1] run setblock ~ ~ ~ minecraft:yellow_candle[waterlogged=true,lit=false,candles=1] replace

execute if block ~ ~ ~ minecraft:yellow_candle[waterlogged=false,candles=2] run setblock ~ ~ ~ minecraft:yellow_candle[waterlogged=true,lit=false,candles=2] replace

execute if block ~ ~ ~ minecraft:yellow_candle[waterlogged=false,candles=3] run setblock ~ ~ ~ minecraft:yellow_candle[waterlogged=true,lit=false,candles=3] replace

execute if block ~ ~ ~ minecraft:yellow_candle[waterlogged=false,candles=4] run setblock ~ ~ ~ minecraft:yellow_candle[waterlogged=true,lit=false,candles=4] replace


#amethysts

execute if block ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=false,facing=up] run setblock ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=true,facing=up] replace

execute if block ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=false,facing=down] run setblock ~ ~ ~ minecraft:small_amethyst_bud[waterlogged=true,facing=down] replace

execute if block ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=false,facing=up] run setblock ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=true,facing=up] replace

execute if block ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=false,facing=down] run setblock ~ ~ ~ minecraft:medium_amethyst_bud[waterlogged=true,facing=down] replace

execute if block ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=false,facing=up] run setblock ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=true,facing=up] replace

execute if block ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=false,facing=down] run setblock ~ ~ ~ minecraft:large_amethyst_bud[waterlogged=true,facing=down] replace

execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true,facing=west] replace

execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false,facing=up] run setblock ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true,facing=up] replace

execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false,facing=down] run setblock ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true,facing=down] replace


#rails

execute if block ~ ~ ~ minecraft:rail[waterlogged=false,shape=ascending_east] run setblock ~ ~ ~ minecraft:rail[waterlogged=true,shape=ascending_east] replace

execute if block ~ ~ ~ minecraft:rail[waterlogged=false,shape=ascending_north] run setblock ~ ~ ~ minecraft:rail[waterlogged=true,shape=ascending_north] replace

execute if block ~ ~ ~ minecraft:rail[waterlogged=false,shape=ascending_south] run setblock ~ ~ ~ minecraft:rail[waterlogged=true,shape=ascending_south] replace

execute if block ~ ~ ~ minecraft:rail[waterlogged=false,shape=ascending_west] run setblock ~ ~ ~ minecraft:rail[waterlogged=true,shape=ascending_west] replace

execute if block ~ ~ ~ minecraft:rail[waterlogged=false,shape=east_west] run setblock ~ ~ ~ minecraft:rail[waterlogged=true,shape=east_west] replace

execute if block ~ ~ ~ minecraft:rail[waterlogged=false,shape=north_south] run setblock ~ ~ ~ minecraft:rail[waterlogged=true,shape=north_south] replace

execute if block ~ ~ ~ minecraft:detector_rail[waterlogged=false,shape=ascending_east] run setblock ~ ~ ~ minecraft:detector_rail[waterlogged=true,shape=ascending_east] replace

execute if block ~ ~ ~ minecraft:detector_rail[waterlogged=false,shape=ascending_north] run setblock ~ ~ ~ minecraft:detector_rail[waterlogged=true,shape=ascending_north] replace

execute if block ~ ~ ~ minecraft:detector_rail[waterlogged=false,shape=ascending_south] run setblock ~ ~ ~ minecraft:detector_rail[waterlogged=true,shape=ascending_south] replace

execute if block ~ ~ ~ minecraft:detector_rail[waterlogged=false,shape=ascending_west] run setblock ~ ~ ~ minecraft:detector_rail[waterlogged=true,shape=ascending_west] replace

execute if block ~ ~ ~ minecraft:detector_rail[waterlogged=false,shape=east_west] run setblock ~ ~ ~ minecraft:detector_rail[waterlogged=true,shape=east_west] replace

execute if block ~ ~ ~ minecraft:detector_rail[waterlogged=false,shape=north_south] run setblock ~ ~ ~ minecraft:detector_rail[waterlogged=true,shape=north_south] replace

execute if block ~ ~ ~ minecraft:activator_rail[waterlogged=false,shape=ascending_east] run setblock ~ ~ ~ minecraft:activator_rail[waterlogged=true,shape=ascending_east] replace

execute if block ~ ~ ~ minecraft:activator_rail[waterlogged=false,shape=ascending_north] run setblock ~ ~ ~ minecraft:activator_rail[waterlogged=true,shape=ascending_north] replace

execute if block ~ ~ ~ minecraft:activator_rail[waterlogged=false,shape=ascending_south] run setblock ~ ~ ~ minecraft:activator_rail[waterlogged=true,shape=ascending_south] replace

execute if block ~ ~ ~ minecraft:activator_rail[waterlogged=false,shape=ascending_west] run setblock ~ ~ ~ minecraft:activator_rail[waterlogged=true,shape=ascending_west] replace

execute if block ~ ~ ~ minecraft:activator_rail[waterlogged=false,shape=east_west] run setblock ~ ~ ~ minecraft:activator_rail[waterlogged=true,shape=east_west] replace

execute if block ~ ~ ~ minecraft:activator_rail[waterlogged=false,shape=north_south] run setblock ~ ~ ~ minecraft:activator_rail[waterlogged=true,shape=north_south] replace

execute if block ~ ~ ~ minecraft:powered_rail[waterlogged=false,shape=ascending_east] run setblock ~ ~ ~ minecraft:powered_rail[waterlogged=true,shape=ascending_east] replace

execute if block ~ ~ ~ minecraft:powered_rail[waterlogged=false,shape=ascending_north] run setblock ~ ~ ~ minecraft:powered_rail[waterlogged=true,shape=ascending_north] replace

execute if block ~ ~ ~ minecraft:powered_rail[waterlogged=false,shape=ascending_south] run setblock ~ ~ ~ minecraft:powered_rail[waterlogged=true,shape=ascending_south] replace

execute if block ~ ~ ~ minecraft:powered_rail[waterlogged=false,shape=ascending_west] run setblock ~ ~ ~ minecraft:powered_rail[waterlogged=true,shape=ascending_west] replace

execute if block ~ ~ ~ minecraft:powered_rail[waterlogged=false,shape=east_west] run setblock ~ ~ ~ minecraft:powered_rail[waterlogged=true,shape=east_west] replace

execute if block ~ ~ ~ minecraft:powered_rail[waterlogged=false,shape=north_south] run setblock ~ ~ ~ minecraft:powered_rail[waterlogged=true,shape=north_south] replace

