
function kyleong:aihunter/action/break/above

execute if score debug aihunter_dummy matches 2 run say s1c
