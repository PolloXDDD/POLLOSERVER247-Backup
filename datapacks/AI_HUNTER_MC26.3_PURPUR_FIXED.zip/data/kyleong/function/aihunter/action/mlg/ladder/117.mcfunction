execute unless block ~-0.6 ~ ~ #kyleong:aihunter/unstable_117 run scoreboard players set #valve4 aihunter_dummy 1

execute unless block ~0.6 ~ ~ #kyleong:aihunter/unstable_117 run scoreboard players set #valve4 aihunter_dummy 2

execute unless block ~ ~ ~0.6 #kyleong:aihunter/unstable_117 run scoreboard players set #valve4 aihunter_dummy 3

execute unless block ~ ~ ~-0.6 #kyleong:aihunter/unstable_117 run scoreboard players set #valve4 aihunter_dummy 4
