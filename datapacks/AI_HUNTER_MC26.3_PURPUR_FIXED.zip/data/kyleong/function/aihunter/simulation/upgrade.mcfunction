#upgrade

execute unless score @s aihunter_upgrade matches 4.. run scoreboard players add @s aihunter_upgrade 1

scoreboard players set @s aihunter_arrow 0

scoreboard players set @s aihunter_potion 0

execute if score notifyupgrade aihunter_dummy matches 1.. run function kyleong:aihunter/message/upgrade

scoreboard players set @s aihunter_uptimer -999


#intent

scoreboard players set @s aihunter_intent 0

execute if score @s aihunter_upgrade matches 1 if predicate kyleong:aihunter/chance/40 run scoreboard players set @s aihunter_intent 1

execute if score @s aihunter_upgrade matches 2 if predicate kyleong:aihunter/chance/40 run scoreboard players set @s aihunter_intent 1

execute if score @s aihunter_upgrade matches 3 if predicate kyleong:aihunter/chance/10 run scoreboard players set @s aihunter_intent 1

execute if score dimension aihunter_dummy matches 2 run scoreboard players set @s aihunter_intent 0


#assign if intent (same as in kyleong:aihunter/act/upgrade/assign)
#lv 1 > 2

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 1 if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 7200

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 1 if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 6000

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 1 if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 4800


#lv 2 > 3

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 2 if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 7200

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 2 if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 6000

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 2 if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 4800


#lv 3 > 4

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 3 if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 18000

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 3 if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 14400

execute if score @s aihunter_intent matches 1 if score @s aihunter_upgrade matches 3 if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 12000
