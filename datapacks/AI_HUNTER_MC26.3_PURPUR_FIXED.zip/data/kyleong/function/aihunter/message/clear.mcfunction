schedule clear kyleong:aihunter/message/10s

schedule clear kyleong:aihunter/message/30s

schedule clear kyleong:aihunter/message/cross
