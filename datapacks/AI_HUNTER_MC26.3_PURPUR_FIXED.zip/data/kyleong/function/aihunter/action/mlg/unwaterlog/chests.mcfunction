#chest, trapped chest, ender chest

execute if block ~ ~ ~ #kyleong:aihunter/chest[waterlogged=true] unless block ~ ~ ~ minecraft:ender_chest run data modify storage aihunter temp set from block ~ ~ ~ Items

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=east,type=single] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=east,type=single] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=east,type=left] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=east,type=left] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=east,type=right] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=east,type=right] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=north,type=single] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=north,type=single] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=north,type=left] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=north,type=left] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=north,type=right] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=north,type=right] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=south,type=single] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=south,type=single] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=south,type=left] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=south,type=left] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=south,type=right] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=south,type=right] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=west,type=single] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=west,type=single] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=west,type=left] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=west,type=left] replace

execute if block ~ ~ ~ minecraft:chest[waterlogged=true,facing=west,type=right] run setblock ~ ~ ~ minecraft:chest[waterlogged=false,facing=west,type=right] replace


execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=east,type=single] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=east,type=single] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=east,type=left] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=east,type=left] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=east,type=right] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=east,type=right] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=north,type=single] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=north,type=single] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=north,type=left] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=north,type=left] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=north,type=right] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=north,type=right] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=south,type=single] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=south,type=single] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=south,type=left] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=south,type=left] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=south,type=right] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=south,type=right] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=west,type=single] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=west,type=single] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=west,type=left] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=west,type=left] replace

execute if block ~ ~ ~ minecraft:trapped_chest[waterlogged=true,facing=west,type=right] run setblock ~ ~ ~ minecraft:trapped_chest[waterlogged=false,facing=west,type=right] replace


execute if block ~ ~ ~ minecraft:ender_chest[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:ender_chest[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:ender_chest[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:ender_chest[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:ender_chest[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:ender_chest[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:ender_chest[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:ender_chest[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ #kyleong:aihunter/chest[waterlogged=false] unless block ~ ~ ~ minecraft:ender_chest run data modify block ~ ~ ~ Items set from storage minecraft:aihunter temp
