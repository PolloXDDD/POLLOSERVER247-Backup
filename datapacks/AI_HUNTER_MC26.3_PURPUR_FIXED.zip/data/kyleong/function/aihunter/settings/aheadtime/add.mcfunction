
execute if score started aihunter_dummy matches 0 run scoreboard players add aheadtime aihunter_dummy 30

execute unless score aheadtime aihunter_dummy matches 1..600 run scoreboard players set aheadtime aihunter_dummy 0


scoreboard players operation aheadtime_s aihunter_dummy = aheadtime aihunter_dummy

scoreboard players operation aheadtime_m aihunter_dummy = aheadtime aihunter_dummy

scoreboard players operation aheadtime_s aihunter_dummy %= #60 aihunter_dummy

scoreboard players operation aheadtime_m aihunter_dummy /= #60 aihunter_dummy


execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/settings/menu/1


execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
