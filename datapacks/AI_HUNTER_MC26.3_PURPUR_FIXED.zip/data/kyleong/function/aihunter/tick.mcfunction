execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/always
