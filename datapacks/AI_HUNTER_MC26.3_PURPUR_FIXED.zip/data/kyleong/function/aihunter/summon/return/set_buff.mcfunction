execute unless score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2.. run data modify entity @s equipment.feet set value {"id":"minecraft:leather_boots","count":1}
execute unless score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2.. run data modify entity @s equipment.legs set value {"id":"minecraft:leather_leggings","count":1}
execute unless score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2.. run data modify entity @s equipment.chest set value {"id":"minecraft:leather_chestplate","count":1}
execute unless score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2.. run data modify entity @s equipment.head set value {"id":"minecraft:skeleton_skull","count":1}
execute unless score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2.. run data remove entity @s equipment.mainhand
execute unless score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2.. run data remove entity @s equipment.offhand

execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2 run data modify entity @s equipment.feet set value {"id":"minecraft:iron_boots","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2 run data modify entity @s equipment.legs set value {"id":"minecraft:leather_leggings","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2 run data modify entity @s equipment.chest set value {"id":"minecraft:iron_chestplate","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2 run data modify entity @s equipment.head set value {"id":"minecraft:skeleton_skull","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2 run data remove entity @s equipment.mainhand
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 2 run data remove entity @s equipment.offhand

execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 3 run data modify entity @s equipment.feet set value {"id":"minecraft:iron_boots","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 3 run data modify entity @s equipment.legs set value {"id":"minecraft:iron_leggings","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 3 run data modify entity @s equipment.chest set value {"id":"minecraft:iron_chestplate","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 3 run data modify entity @s equipment.head set value {"id":"minecraft:skeleton_skull","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 3 run data remove entity @s equipment.mainhand
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 3 run data remove entity @s equipment.offhand

execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 4 run data modify entity @s equipment.feet set value {"id":"minecraft:iron_boots","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 4 run data modify entity @s equipment.legs set value {"id":"minecraft:diamond_leggings","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 4 run data modify entity @s equipment.chest set value {"id":"minecraft:diamond_chestplate","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 4 run data modify entity @s equipment.head set value {"id":"minecraft:skeleton_skull","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 4 run data remove entity @s equipment.mainhand
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 4 run data remove entity @s equipment.offhand

execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 5 run data modify entity @s equipment.feet set value {"id":"minecraft:diamond_boots","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 5 run data modify entity @s equipment.legs set value {"id":"minecraft:diamond_leggings","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 5 run data modify entity @s equipment.chest set value {"id":"minecraft:diamond_chestplate","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 5 run data modify entity @s equipment.head set value {"id":"minecraft:skeleton_skull","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 5 run data remove entity @s equipment.mainhand
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 5 run data remove entity @s equipment.offhand

execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 6.. run data modify entity @s equipment.feet set value {"id":"minecraft:netherite_boots","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 6.. run data modify entity @s equipment.legs set value {"id":"minecraft:netherite_leggings","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 6.. run data modify entity @s equipment.chest set value {"id":"minecraft:netherite_chestplate","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 6.. run data modify entity @s equipment.head set value {"id":"minecraft:wither_skeleton_skull","count":1}
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 6.. run data remove entity @s equipment.mainhand
execute if score @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade matches 6.. run data remove entity @s equipment.offhand
