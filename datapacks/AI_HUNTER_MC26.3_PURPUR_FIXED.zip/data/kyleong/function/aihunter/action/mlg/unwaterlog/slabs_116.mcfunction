#MC1.16 slabs
#TOP

execute if block ~ ~ ~ minecraft:acacia_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:acacia_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:andesite_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:andesite_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:birch_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:birch_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:blackstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:blackstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:cobblestone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:cobblestone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:crimson_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:crimson_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:cut_red_sandstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:cut_red_sandstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:cut_sandstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:cut_sandstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:dark_oak_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:dark_oak_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:dark_prismarine_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:diorite_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:diorite_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:end_stone_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:granite_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:granite_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:jungle_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:jungle_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:mossy_cobblestone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:mossy_stone_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:nether_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:nether_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:oak_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:oak_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:petrified_oak_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:petrified_oak_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:polished_andesite_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:polished_andesite_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:polished_blackstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:polished_diorite_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:polished_diorite_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:polished_granite_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:polished_granite_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:prismarine_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:prismarine_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:prismarine_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:purpur_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:purpur_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:quartz_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:quartz_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:red_nether_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:red_sandstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:red_sandstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:sandstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:sandstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:smooth_quartz_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:smooth_sandstone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:smooth_stone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:smooth_stone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:spruce_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:spruce_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:stone_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:stone_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:stone_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:stone_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:warped_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:warped_slab[waterlogged=false,type=top] replace


#BOTTOM

execute if block ~ ~ ~ minecraft:acacia_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:acacia_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:andesite_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:andesite_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:birch_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:birch_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:blackstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:blackstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:cobblestone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:cobblestone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:crimson_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:crimson_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:cut_red_sandstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:cut_red_sandstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:cut_sandstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:cut_sandstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:dark_oak_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:dark_oak_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:dark_prismarine_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:diorite_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:diorite_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:end_stone_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:granite_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:granite_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:jungle_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:jungle_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:mossy_cobblestone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:mossy_stone_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:nether_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:nether_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:oak_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:oak_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:petrified_oak_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:petrified_oak_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:polished_andesite_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:polished_andesite_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:polished_blackstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:polished_diorite_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:polished_diorite_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:polished_granite_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:polished_granite_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:prismarine_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:prismarine_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:prismarine_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:purpur_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:purpur_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:quartz_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:quartz_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:red_nether_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:red_sandstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:red_sandstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:sandstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:sandstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:smooth_quartz_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:smooth_sandstone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:smooth_stone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:smooth_stone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:spruce_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:spruce_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:stone_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:stone_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:stone_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:stone_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:warped_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:warped_slab[waterlogged=false,type=bottom] replace
