function kyleong:aihunter/adjust/position


execute unless score version aihunter_dummy matches 117.. run function kyleong:aihunter/action/mlg/ladder/116

execute if score version aihunter_dummy matches 117 run function kyleong:aihunter/action/mlg/ladder/117

execute if score version aihunter_dummy matches 119 run function kyleong:aihunter/action/mlg/ladder/119

execute if score version aihunter_dummy matches 120 run function kyleong:aihunter/action/mlg/ladder/120


execute unless score #valve4 aihunter_dummy matches 1.. run setblock ~-0.6 ~ ~ minecraft:dirt keep

execute unless score #valve4 aihunter_dummy matches 1.. unless block ~-0.6 ~ ~ minecraft:dirt run setblock ~0.6 ~ ~ minecraft:dirt keep

execute unless score #valve4 aihunter_dummy matches 1.. unless block ~-0.6 ~ ~ minecraft:dirt unless block ~0.6 ~ ~ minecraft:dirt run setblock ~ ~ ~0.6 minecraft:dirt keep

execute unless score #valve4 aihunter_dummy matches 1.. unless block ~-0.6 ~ ~ minecraft:dirt unless block ~0.6 ~ ~ minecraft:dirt unless block ~ ~ ~0.6 minecraft:dirt run setblock ~ ~ ~-0.6 minecraft:dirt keep

execute unless score #valve4 aihunter_dummy matches 1.. run playsound minecraft:block.gravel.place block @a ~ ~ ~ 1 .8


execute if block ~-0.6 ~ ~ minecraft:dirt run scoreboard players set #valve4 aihunter_dummy 1

execute if block ~0.6 ~ ~ minecraft:dirt run scoreboard players set #valve4 aihunter_dummy 2

execute if block ~ ~ ~0.6 minecraft:dirt run scoreboard players set #valve4 aihunter_dummy 3

execute if block ~ ~ ~-0.6 minecraft:dirt run scoreboard players set #valve4 aihunter_dummy 4


execute if score #valve4 aihunter_dummy matches 1 run setblock ~ ~ ~ minecraft:ladder[facing=east] keep

execute if score #valve4 aihunter_dummy matches 2 run setblock ~ ~ ~ minecraft:ladder[facing=west] keep

execute if score #valve4 aihunter_dummy matches 3 run setblock ~ ~ ~ minecraft:ladder[facing=north] keep

execute if score #valve4 aihunter_dummy matches 4 run setblock ~ ~ ~ minecraft:ladder[facing=south] keep


playsound minecraft:block.ladder.place block @a

scoreboard players set #valve4 aihunter_dummy 0

scoreboard players set @s aihunter_fall 0


#debug reporting

execute if score debug aihunter_dummy matches 1 run say mlg: executed (ladder)
