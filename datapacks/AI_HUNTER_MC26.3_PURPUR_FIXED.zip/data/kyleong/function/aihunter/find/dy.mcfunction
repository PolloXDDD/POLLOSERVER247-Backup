execute store result score @s aihunter_y1 run data get entity @s Pos[1] 1000

execute store result score @s aihunter_y2 run data get entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] Pos[1] 1000

scoreboard players operation @s aihunter_dy = @s aihunter_y2

scoreboard players operation @s aihunter_dy -= @s aihunter_y1
