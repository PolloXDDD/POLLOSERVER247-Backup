
scoreboard players add @s aihunter_busy 1


execute store result entity @s Motion[1] double 0.001 run scoreboard players set #motion aihunter_dummy 500

effect give @s minecraft:saturation 5 30 true
