advancement revoke @s only kyleong:aihunter/place

execute if score started aihunter_dummy matches 1 unless score pause aihunter_dummy matches 1 unless score @s aihunter_tower matches ..-1 run function kyleong:aihunter/check/tower
