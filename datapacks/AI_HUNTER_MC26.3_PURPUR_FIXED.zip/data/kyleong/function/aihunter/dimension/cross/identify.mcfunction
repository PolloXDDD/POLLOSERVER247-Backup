#identify going to which dimension

advancement revoke @s only kyleong:aihunter/dimension

execute if predicate kyleong:aihunter/dimension/overworld run function kyleong:aihunter/dimension/cross/0

execute unless score wincondition aihunter_dummy matches 2 if predicate kyleong:aihunter/dimension/nether run function kyleong:aihunter/dimension/cross/1

execute unless score dimension aihunter_dummy matches 2 if predicate kyleong:aihunter/dimension/end run function kyleong:aihunter/dimension/cross/2
