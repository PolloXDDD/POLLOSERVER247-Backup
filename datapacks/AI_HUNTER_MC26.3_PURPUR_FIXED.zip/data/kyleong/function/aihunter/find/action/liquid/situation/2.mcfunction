
execute positioned ^ ^0.5 ^0.5 run function kyleong:aihunter/action/build/block

execute if score debug aihunter_dummy matches 2 run say l2
