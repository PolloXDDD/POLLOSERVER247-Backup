
execute positioned ^ ^2.5 ^ run function kyleong:aihunter/action/break/block

execute if score debug aihunter_dummy matches 2 run say l1
