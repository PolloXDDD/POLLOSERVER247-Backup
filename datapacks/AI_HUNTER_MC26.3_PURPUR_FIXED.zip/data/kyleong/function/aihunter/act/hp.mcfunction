##as at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)
##not the only function that depends on health
#check if consume food

execute if entity @s[predicate=!kyleong:aihunter/slowed] unless entity @p[distance=..18,gamemode=!creative,gamemode=!spectator,team=!aihunter] if score @s aihunter_hp matches ..160 run function kyleong:aihunter/action/potion/food


#intention:

execute unless score dimension aihunter_dummy matches 2 if score @s aihunter_intent matches 0 if score @s aihunter_hp matches 41..80 if score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches 80.. if predicate kyleong:aihunter/chance/30 run scoreboard players set @s aihunter_intent -1

execute unless score dimension aihunter_dummy matches 2 if score @s aihunter_intent matches 0 if score @s aihunter_hp matches ..40 if score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches 50.. unless entity @p[distance=..4,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent -1

execute if score @s aihunter_intent matches -1 if score @s aihunter_hp matches 160.. run scoreboard players set @s aihunter_intent 0

execute if score @s aihunter_intent matches -1 if score @s aihunter_hp matches 41.. if entity @p[distance=..4,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent 0


execute if score canupgrade aihunter_dummy matches 1 unless score difficulty aihunter_dummy matches 4.. run function kyleong:aihunter/act/upgrade/intention

execute if score canupgrade aihunter_dummy matches 0 if score @s aihunter_intent matches 1.. run scoreboard players set @s aihunter_intent 0
