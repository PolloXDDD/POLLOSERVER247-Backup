
scoreboard players add quality aihunter_dummy 1

execute unless score quality aihunter_dummy matches 0..2 run scoreboard players set quality aihunter_dummy 0

function kyleong:aihunter/settings/menu/2
