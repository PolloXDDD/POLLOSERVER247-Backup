##as @e[type=minecraft:arrow,tag=aihunter_arrow]

execute at @s run particle minecraft:crit ~ ~ ~ 0 0 0 .1 1

tag @s[nbt={inGround:1b}] remove aihunter_arrow

kill @s[nbt={inGround:1b}]
