##as at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)


execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~1 ~1 ~ if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~-1 ~1 ~ if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~ ~1 ~1 if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}

execute positioned ~ ~1 ~-1 if block ~ ~ ~ #minecraft:replaceable run summon minecraft:area_effect_cloud ~ ~ ~ {"Tags":["aihunter_table"],"Duration":9000000}


execute unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_table,limit=1,sort=nearest,distance=..2] run function kyleong:aihunter/act/upgrade/table1

tag @e[type=minecraft:area_effect_cloud,tag=aihunter_table,limit=1,sort=nearest,distance=..2] add aihunter_table_built

execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_table_built,distance=..2] run setblock ~ ~ ~ minecraft:crafting_table keep

kill @e[tag=aihunter_table,tag=!aihunter_table_built]
