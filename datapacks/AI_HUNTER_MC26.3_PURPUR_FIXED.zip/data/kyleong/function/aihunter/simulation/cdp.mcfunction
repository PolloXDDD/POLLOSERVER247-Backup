tag @s remove aihunter_simulate

tag @s add aihunter_simulate_complete_cd

tag @s add aihunter_temp

tp @s ~ ~ ~
