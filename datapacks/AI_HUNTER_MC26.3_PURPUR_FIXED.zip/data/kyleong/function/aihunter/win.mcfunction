schedule function kyleong:aihunter/stop 1t

execute as @e[type=minecraft:armor_stand,tag=aihunter] run data merge entity @s {"Pose":{"LeftArm":[-50f,-30f,0f],"RightArm":[-50f,30f,0f]},"Glowing":0b,"CustomName":{"text":"Congrats!"},"Tags":[""],"Invulnerable":0b,"DisabledSlots":0}
execute as @e[type=minecraft:armor_stand,tag=aihunter] run data modify entity @s equipment.mainhand set value {"id":"minecraft:diamond","count":1}
execute as @e[type=minecraft:armor_stand,tag=aihunter] run data remove entity @s equipment.offhand

scoreboard players set #valve3 aihunter_dummy 1


#

function kyleong:aihunter/message/victory

execute at @a run playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ .8 1.6

execute at @a run summon minecraft:firework_rocket ~ ~ ~ {"Tags":["aihunter_congrats"],"LifeTime":30,"FireworksItem":{"id":"minecraft:firework_rocket","count":1,"components":{"minecraft:fireworks":{"flight_duration":0,"explosions":[{"shape":"large_ball","colors":[I;12063487],"fade_colors":[I;2303],"has_twinkle":true,"has_trail":true}]}}}}

execute if score difficulty aihunter_dummy matches 2.. at @a run summon minecraft:firework_rocket ~ ~ ~ {"Tags":["aihunter_congrats"],"LifeTime":40,"FireworksItem":{"id":"minecraft:firework_rocket","count":1,"components":{"minecraft:fireworks":{"flight_duration":0,"explosions":[{"shape":"creeper","colors":[I;63487],"fade_colors":[I;2303],"has_twinkle":true,"has_trail":true}]}}}}

execute if score difficulty aihunter_dummy matches 3.. at @a run summon minecraft:firework_rocket ~ ~ ~ {"Tags":["aihunter_congrats"],"LifeTime":50,"FireworksItem":{"id":"minecraft:firework_rocket","count":1,"components":{"minecraft:fireworks":{"flight_duration":0,"explosions":[{"shape":"star","colors":[I;2063487],"fade_colors":[I;2303],"has_twinkle":true,"has_trail":true}]}}}}

#

advancement revoke @s only kyleong:aihunter/win
