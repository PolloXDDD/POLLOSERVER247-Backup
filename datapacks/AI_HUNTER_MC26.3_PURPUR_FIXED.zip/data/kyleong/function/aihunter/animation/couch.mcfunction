scoreboard players add @s aihunter_ani 1

execute if score @s aihunter_ani matches 1 run data merge entity @s {"Pose":{"LeftArm":[8f,0f,0f],"RightArm":[-8f,0f,0f],"LeftLeg":[-8f,0f,0f],"RightLeg":[8f,0f,0f]}}

execute if score @s aihunter_ani matches 2 run data merge entity @s {"Pose":{"LeftArm":[16f,0f,0f],"RightArm":[-16f,0f,0f],"LeftLeg":[-16f,0f,0f],"RightLeg":[16f,0f,0f]}}

execute if score @s aihunter_ani matches 3 run data merge entity @s {"Pose":{"LeftArm":[24f,0f,0f],"RightArm":[-24f,0f,0f],"LeftLeg":[-24f,0f,0f],"RightLeg":[24f,0f,0f]}}

execute if score @s aihunter_ani matches 4 run data merge entity @s {"Pose":{"LeftArm":[16f,0f,0f],"RightArm":[-16f,0f,0f],"LeftLeg":[-16f,0f,0f],"RightLeg":[16f,0f,0f]}}

execute if score @s aihunter_ani matches 5 run data merge entity @s {"Pose":{"LeftArm":[8f,0f,0f],"RightArm":[-8f,0f,0f],"LeftLeg":[-8f,0f,0f],"RightLeg":[8f,0f,0f]}}

execute if score @s aihunter_ani matches 6 run data merge entity @s {"Pose":{"LeftArm":[0f,0f,0f],"RightArm":[0f,0f,0f],"LeftLeg":[0f,0f,0f],"RightLeg":[0f,0f,0f]}}

execute if score @s aihunter_ani matches 7 run data merge entity @s {"Pose":{"LeftArm":[-8f,0f,0f],"RightArm":[8f,0f,0f],"LeftLeg":[8f,0f,0f],"RightLeg":[-8f,0f,0f]}}

execute if score @s aihunter_ani matches 8 run data merge entity @s {"Pose":{"LeftArm":[-16f,0f,0f],"RightArm":[16f,0f,0f],"LeftLeg":[16f,0f,0f],"RightLeg":[-16f,0f,0f]}}

execute if score @s aihunter_ani matches 9 run data merge entity @s {"Pose":{"LeftArm":[-24f,0f,0f],"RightArm":[24f,0f,0f],"LeftLeg":[24f,0f,0f],"RightLeg":[-24f,0f,0f]}}

execute if score @s aihunter_ani matches 10 run data merge entity @s {"Pose":{"LeftArm":[-16f,0f,0f],"RightArm":[16f,0f,0f],"LeftLeg":[16f,0f,0f],"RightLeg":[-16f,0f,0f]}}

execute if score @s aihunter_ani matches 11 run data merge entity @s {"Pose":{"LeftArm":[-8f,0f,0f],"RightArm":[8f,0f,0f],"LeftLeg":[8f,0f,0f],"RightLeg":[-8f,0f,0f]}}

execute if score @s aihunter_ani matches 12 run data merge entity @s {"Pose":{"LeftArm":[0f,0f,0f],"RightArm":[0f,0f,0f],"LeftLeg":[0f,0f,0f],"RightLeg":[0f,0f,0f]}}

execute if score @s aihunter_ani matches 12.. run scoreboard players set @s aihunter_ani 0
