#MC1.17 added walls (deepstales)

execute if block ~ ~ ~ minecraft:polished_deepslate_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:polished_deepslate_wall[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:cobbled_deepslate_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:cobbled_deepslate_wall[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:deepslate_brick_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:deepslate_brick_wall[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:deepslate_tile_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:deepslate_tile_wall[waterlogged=false] replace
