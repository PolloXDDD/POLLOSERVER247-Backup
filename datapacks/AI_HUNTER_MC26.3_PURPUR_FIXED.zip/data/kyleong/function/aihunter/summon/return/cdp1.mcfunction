execute if score debug aihunter_dummy matches 1 run say cdp applied

scoreboard players set @s[type=minecraft:vindicator] aihunter_hp 200

data modify entity @s[type=minecraft:armor_stand] equipment set from storage minecraft:aihunter_custom armor

data modify entity @s[type=minecraft:vindicator] CustomName set from storage minecraft:aihunter_custom name

execute as @e[type=minecraft:area_effect_cloud,tag=aihunter_name] run data modify entity @s CustomName set from storage minecraft:aihunter_custom name

execute if entity @s[type=minecraft:armor_stand] unless data storage minecraft:aihunter_custom armor run function kyleong:aihunter/summon/return/set_buff


#effects

effect give @s[type=minecraft:vindicator,tag=aihunter] minecraft:blindness 999999 99 true

effect give @s[type=minecraft:vindicator,tag=aihunter] minecraft:weakness 999999 20 true

effect give @s[type=minecraft:vindicator,tag=aihunter] minecraft:resistance 999999 4 true


function kyleong:aihunter/adjust/damage
