#determine if hit player & player's posture

execute positioned ^ ^ ^-0.4 positioned ~-0.5 ~-0.15 ~-0.5 if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,dx=0,dy=0,dz=0] run scoreboard players add #raycastentities aihunter_dummy 1


scoreboard players add #raycastdistance aihunter_dummy 1

execute unless block ~ ~ ~ #kyleong:aihunter/shoot_through_119 unless block ~ ~ ~ minecraft:snow[layers=1] run scoreboard players set #raycastdistance aihunter_dummy 999999

execute unless block ~ ~0.1 ~ #kyleong:aihunter/shoot_through_119 unless block ~ ~0.1 ~ minecraft:snow[layers=1] run scoreboard players set #raycastdistance aihunter_dummy 999999

execute unless block ~ ~-0.1 ~ #kyleong:aihunter/shoot_through_119 unless block ~ ~-0.1 ~ minecraft:snow[layers=1] run scoreboard players set #raycastdistance aihunter_dummy 999999

execute unless block ^0.05 ^ ^ #kyleong:aihunter/shoot_through_119 unless block ^0.05 ^ ^ minecraft:snow[layers=1] run scoreboard players set #raycastdistance aihunter_dummy 999999

execute unless block ^-0.05 ^ ^ #kyleong:aihunter/shoot_through_119 unless block ^-0.05 ^ ^ minecraft:snow[layers=1] run scoreboard players set #raycastdistance aihunter_dummy 999999


#move forward if no players detected

execute unless score #raycastentities aihunter_dummy matches 1.. unless score #raycastdistance aihunter_dummy matches 465.. positioned ^ ^ ^0.2 rotated ~ ~0.06 run function kyleong:aihunter/action/shoot/raycast/119


#particles

execute if score debug aihunter_dummy matches 2 unless score #redo aihunter_dummy matches 1.. run particle minecraft:dust{color:[0,1,0],scale:1} ~ ~ ~ 0 0 0 5 1

execute if score debug aihunter_dummy matches 2 if score #redo aihunter_dummy matches 1 run particle minecraft:dust{color:[1,1,0],scale:1} ~ ~ ~ 0 0 0 5 1

execute if score debug aihunter_dummy matches 2 if score #redo aihunter_dummy matches 2.. run particle minecraft:dust{color:[1,0,0],scale:1} ~ ~ ~ 0 0 0 5 1
