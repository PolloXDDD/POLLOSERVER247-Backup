execute unless score pause aihunter_dummy matches 1 run tellraw @s {"text":"[AI Hunter] No Paused Challenge","color":"red","bold":true}

execute if score pause aihunter_dummy matches 1 run function kyleong:aihunter/resume

