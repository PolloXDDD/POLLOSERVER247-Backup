execute unless score @s aihunter_death matches 999999999 run function kyleong:aihunter/fail

scoreboard players set @s aihunter_death 0

execute if score started aihunter_dummy matches 1 unless score dimension aihunter_dummy matches 2 run function kyleong:aihunter/dimension/respawn
