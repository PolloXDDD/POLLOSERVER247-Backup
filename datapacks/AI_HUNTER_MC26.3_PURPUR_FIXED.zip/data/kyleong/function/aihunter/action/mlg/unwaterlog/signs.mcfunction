data modify storage aihunter temp set from block ~ ~ ~

function kyleong:aihunter/action/mlg/unwaterlog/signs_116

function kyleong:aihunter/action/mlg/unwaterlog/signs_119

execute if score version aihunter_dummy matches 120.. run function kyleong:aihunter/action/mlg/unwaterlog/signs_120


#

execute unless score version aihunter_dummy matches 120.. run data modify block ~ ~ ~ GlowingText set from storage minecraft:aihunter temp.GlowingText

execute unless score version aihunter_dummy matches 120.. run data modify block ~ ~ ~ Color set from storage minecraft:aihunter temp.Color

execute unless score version aihunter_dummy matches 120.. run data modify block ~ ~ ~ Text1 set from storage minecraft:aihunter temp.Text1

execute unless score version aihunter_dummy matches 120.. run data modify block ~ ~ ~ Text2 set from storage minecraft:aihunter temp.Text2

execute unless score version aihunter_dummy matches 120.. run data modify block ~ ~ ~ Text3 set from storage minecraft:aihunter temp.Text3

execute unless score version aihunter_dummy matches 120.. run data modify block ~ ~ ~ Text4 set from storage minecraft:aihunter temp.Text4
