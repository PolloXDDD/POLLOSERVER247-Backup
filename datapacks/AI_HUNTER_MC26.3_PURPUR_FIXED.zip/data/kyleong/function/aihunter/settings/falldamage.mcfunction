
scoreboard players add falldamage aihunter_dummy 1

execute unless score falldamage aihunter_dummy matches 0..1 run scoreboard players set falldamage aihunter_dummy 0

function kyleong:aihunter/settings/menu/2



