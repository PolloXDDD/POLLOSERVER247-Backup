execute store result entity @s Motion[0] double 0.00304 run scoreboard players get @e[limit=1,sort=nearest,type=minecraft:vindicator,tag=aihunter] aihunter_vx

execute store result entity @s Motion[1] double 0.00304 run scoreboard players get #vy aihunter_dummy

execute store result entity @s Motion[2] double 0.00304 run scoreboard players get @e[limit=1,sort=nearest,type=minecraft:vindicator,tag=aihunter] aihunter_vz

tag @s remove aihunter_arrow_fresh
