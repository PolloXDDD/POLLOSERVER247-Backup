execute as @a[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/check/movestart/check

execute as @a[gamemode=!survival,gamemode=!adventure] run function kyleong:aihunter/check/movestart/clear

execute unless score #movestart aihunter_dummy matches 1 run schedule function kyleong:aihunter/check/movestart/loop 2t

execute if score #movestart aihunter_dummy matches 1 run schedule function kyleong:aihunter/active 1t
