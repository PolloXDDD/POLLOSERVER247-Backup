
scoreboard players add crosstime aihunter_dummy 30

execute unless score crosstime aihunter_dummy matches -29..600 run scoreboard players set crosstime aihunter_dummy -30


scoreboard players operation crosstime_s aihunter_dummy = crosstime aihunter_dummy

scoreboard players operation crosstime_m aihunter_dummy = crosstime aihunter_dummy

scoreboard players operation crosstime_s aihunter_dummy %= #60 aihunter_dummy

scoreboard players operation crosstime_m aihunter_dummy /= #60 aihunter_dummy


function kyleong:aihunter/settings/menu/2
