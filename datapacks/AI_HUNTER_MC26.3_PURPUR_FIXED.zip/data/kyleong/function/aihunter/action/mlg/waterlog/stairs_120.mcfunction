#MC1.120 added stairs (cherry, bamboo's)
#111

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace


#211

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace


#311

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace


#411

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace


#121

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace


#221

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace


#321

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace


#421

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace


#122

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace


#123

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace


#124

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace


#125

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace


#112

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace


#113

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace


#114

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace


#115

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace


#212

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace


#213

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace


#214

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace


#215

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace


#312

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace


#313

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace


#314

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace


#315

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace


#412

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace


#413

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace


#414

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace


#415

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace


#222

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace


#223

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace


#224

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace


#225

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace


#322

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace


#323

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace


#324

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace


#325

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace


#422

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace


#423

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace


#424

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace


#425

execute if block ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_mosaic_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:bamboo_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:bamboo_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cherry_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cherry_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace
