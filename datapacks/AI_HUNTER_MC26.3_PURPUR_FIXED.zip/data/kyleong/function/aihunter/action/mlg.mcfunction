##as at @e[type=minecraft:vindicator,tag=aihunter]
#cannot be put in one because version complications 

execute unless score version aihunter_dummy matches 117.. run function kyleong:aihunter/action/mlg/116

execute if score version aihunter_dummy matches 117..118 run function kyleong:aihunter/action/mlg/117

execute if score version aihunter_dummy matches 119 run function kyleong:aihunter/action/mlg/119

execute if score version aihunter_dummy matches 120 run function kyleong:aihunter/action/mlg/120
