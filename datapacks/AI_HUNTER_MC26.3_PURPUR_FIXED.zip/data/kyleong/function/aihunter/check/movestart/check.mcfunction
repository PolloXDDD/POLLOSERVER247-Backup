execute if score @s aihunter_walk matches 1.. run scoreboard players set #movestart aihunter_dummy 1

execute if score @s aihunter_sprint matches 1.. run scoreboard players set #movestart aihunter_dummy 1

execute if score @s aihunter_crouch matches 1.. run scoreboard players set #movestart aihunter_dummy 1

execute if score @s aihunter_swim matches 1.. run scoreboard players set #movestart aihunter_dummy 1

execute if score @s aihunter_owwalk matches 1.. run scoreboard players set #movestart aihunter_dummy 1

execute if score @s aihunter_uwwalk matches 1.. run scoreboard players set #movestart aihunter_dummy 1

execute if score @s aihunter_pearl matches 1.. run scoreboard players set #movestart aihunter_dummy 1
