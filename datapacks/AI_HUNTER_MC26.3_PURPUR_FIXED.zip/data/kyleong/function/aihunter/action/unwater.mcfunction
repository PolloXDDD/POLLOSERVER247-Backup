##as at @e[type=minecraft:area_effect_cloud,tag=aihunter_water,scores={aihunter_hp=..-3}]

execute if block ~ ~ ~ minecraft:water run setblock ~ ~ ~ minecraft:air replace

execute if block ~ ~ ~ minecraft:bubble_column run setblock ~ ~ ~ minecraft:air replace

kill @s
