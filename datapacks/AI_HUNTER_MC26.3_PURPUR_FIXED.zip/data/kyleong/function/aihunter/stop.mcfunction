function kyleong:aihunter/reset

scoreboard players set activetime aihunter_dummy -999

scoreboard players set timer1 aihunter_dummy -999

scoreboard players set started aihunter_dummy 0

scoreboard players set pause aihunter_dummy 0

execute unless score #valve3 aihunter_dummy matches 1 as @a run function kyleong:aihunter/menu

scoreboard players set #valve3 aihunter_dummy 0

scoreboard players set dimension aihunter_dummy 0

scoreboard players set bed aihunter_dummy 0

scoreboard players set simulation aihunter_dummy 0

scoreboard players set @a aihunter_death 0

execute at @e[type=minecraft:area_effect_cloud] run forceload remove all

kill @e[tag=aihunter]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_name]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_worldspawn]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_overworld_portal]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_bed]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate]

kill @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate_complete]
