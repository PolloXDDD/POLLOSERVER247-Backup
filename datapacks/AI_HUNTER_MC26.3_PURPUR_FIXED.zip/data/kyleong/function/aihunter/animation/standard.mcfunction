scoreboard players add @s aihunter_ani 1

execute if score @s aihunter_ani matches 1 run data merge entity @s {"Pose":{"LeftArm":[30f,0f,0f],"RightArm":[-30f,0f,0f],"LeftLeg":[-30f,0f,0f],"RightLeg":[30f,0f,0f]}}

execute if score @s aihunter_ani matches 2 run data merge entity @s {"Pose":{"LeftArm":[-30f,0f,0f],"RightArm":[30f,0f,0f],"LeftLeg":[30f,0f,0f],"RightLeg":[-30f,0f,0f]}}

execute if score @s aihunter_ani matches 2.. run scoreboard players set @s aihunter_ani 0
