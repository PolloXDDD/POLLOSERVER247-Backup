
execute positioned ^ ^0.5 ^0.5 run function kyleong:aihunter/action/break/block

execute if score debug aihunter_dummy matches 2 run say u1d
