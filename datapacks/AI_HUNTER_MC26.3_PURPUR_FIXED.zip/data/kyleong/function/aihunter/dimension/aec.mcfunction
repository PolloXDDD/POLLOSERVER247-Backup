execute if predicate kyleong:aihunter/dimension/overworld run summon minecraft:area_effect_cloud ~ ~6 ~ {"Duration":9000000,"Tags":["aihunter_overworld_portal"]}

execute if predicate kyleong:aihunter/dimension/nether run summon minecraft:area_effect_cloud ~ ~6 ~ {"Duration":9000000,"Tags":["aihunter_nether_spawn"]}

execute if predicate kyleong:aihunter/dimension/end run summon minecraft:area_effect_cloud ~ ~ ~ {"Duration":9000000,"Tags":["aihunter_end_spawn"]}

forceload add ~ ~

execute if score debug aihunter_dummy matches 1 run say aec
