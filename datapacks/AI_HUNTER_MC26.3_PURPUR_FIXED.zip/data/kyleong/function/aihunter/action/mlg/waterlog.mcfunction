##block ~ ~ ~ is waterlogable

summon minecraft:area_effect_cloud ~ ~ ~ {"Duration":40,"Tags":["aihunter_fading","aihunter_waterlog"]}

function kyleong:aihunter/action/mlg/waterlog/glass_panes

function kyleong:aihunter/action/mlg/waterlog/chests

function kyleong:aihunter/action/mlg/waterlog/slabs_116

function kyleong:aihunter/action/mlg/waterlog/slabs_117

function kyleong:aihunter/action/mlg/waterlog/slabs_119

function kyleong:aihunter/action/mlg/waterlog/slabs_120


function kyleong:aihunter/action/mlg/waterlog/stairs_116

function kyleong:aihunter/action/mlg/waterlog/stairs_117

function kyleong:aihunter/action/mlg/waterlog/stairs_119

function kyleong:aihunter/action/mlg/waterlog/stairs_120


function kyleong:aihunter/action/mlg/waterlog/fences_116

function kyleong:aihunter/action/mlg/waterlog/fences_119

function kyleong:aihunter/action/mlg/waterlog/fences_120


function kyleong:aihunter/action/mlg/waterlog/trapdoors_116

function kyleong:aihunter/action/mlg/waterlog/trapdoors_119

function kyleong:aihunter/action/mlg/waterlog/trapdoors_120


execute if block ~ ~ ~ #minecraft:signs[waterlogged=false] run function kyleong:aihunter/action/mlg/waterlog/signs


function kyleong:aihunter/action/mlg/waterlog/walls_116

function kyleong:aihunter/action/mlg/waterlog/walls_117

function kyleong:aihunter/action/mlg/waterlog/walls_119


function kyleong:aihunter/action/mlg/waterlog/others_117

function kyleong:aihunter/action/mlg/waterlog/others_119

function kyleong:aihunter/action/mlg/waterlog/others_120


#ladder

execute if block ~ ~ ~ minecraft:ladder[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:ladder[waterlogged=true,facing=east] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:ladder[waterlogged=true,facing=north] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:ladder[waterlogged=true,facing=south] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:ladder[waterlogged=true,facing=west] replace


#chain

execute if block ~ ~ ~ minecraft:iron_chain[waterlogged=false,axis=x] run setblock ~ ~ ~ minecraft:iron_chain[waterlogged=true,axis=x] replace

execute if block ~ ~ ~ minecraft:iron_chain[waterlogged=false,axis=y] run setblock ~ ~ ~ minecraft:iron_chain[waterlogged=true,axis=y] replace

execute if block ~ ~ ~ minecraft:iron_chain[waterlogged=false,axis=z] run setblock ~ ~ ~ minecraft:iron_chain[waterlogged=true,axis=z] replace


#campfire

execute if block ~ ~ ~ minecraft:campfire[lit=true] run playsound minecraft:block.fire.extinguish block @a ~ ~ ~

execute if block ~ ~ ~ minecraft:campfire[waterlogged=false,facing=east] run setblock ~ ~ ~ minecraft:campfire[waterlogged=true,lit=false,facing=east] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=false,facing=north] run setblock ~ ~ ~ minecraft:campfire[waterlogged=true,lit=false,facing=north] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=false,facing=south] run setblock ~ ~ ~ minecraft:campfire[waterlogged=true,lit=false,facing=south] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=false,facing=west] run setblock ~ ~ ~ minecraft:campfire[waterlogged=true,lit=false,facing=west] replace


#others

execute if block ~ ~ ~ minecraft:iron_bars[waterlogged=false] run setblock ~ ~ ~ minecraft:iron_bars[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:conduit[waterlogged=false] run setblock ~ ~ ~ minecraft:conduit[waterlogged=true] replace


#special

execute if block ~ ~ ~ minecraft:scaffolding run data modify entity @s fall_distance set value -999.0d


#sound

execute unless block ~ ~ ~ minecraft:scaffolding run playsound minecraft:item.bucket.empty master @a ~ ~ ~


#debug reporting

execute if score debug aihunter_dummy matches 1 run say mlg: executed (waterlog)
