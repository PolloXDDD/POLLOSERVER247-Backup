##as at @e[type=minecraft:vindicator,tag=aihunter]
#set

scoreboard players set @s aihunter_upgrade 4

attribute @s minecraft:armor base set 18

attribute @s minecraft:armor_toughness base set 4

data modify entity @s equipment.mainhand set value {"id":"minecraft:diamond_sword","count":1,"components":{"minecraft:unbreakable":{}}}
data remove entity @s equipment.offhand

execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.feet set value {"id":"minecraft:iron_boots","count":1}
execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.legs set value {"id":"minecraft:diamond_leggings","count":1}
execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.chest set value {"id":"minecraft:diamond_chestplate","count":1}
execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.head set value {"id":"minecraft:skeleton_skull","count":1}


scoreboard players add @s aihunter_arrow 12


#message

execute if score notifyupgrade aihunter_dummy matches 1.. run function kyleong:aihunter/message/upgrade
