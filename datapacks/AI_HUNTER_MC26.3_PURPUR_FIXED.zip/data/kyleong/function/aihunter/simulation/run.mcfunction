##as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,tag=!aihunter_register] at server
#health regeneration ,similar to effect lv 1

execute if score @s aihunter_hp matches ..199 run scoreboard players add @s aihunter_hp 1


#prepare upgrade

execute if score canupgrade aihunter_dummy matches 1 run function kyleong:aihunter/simulation/check/upgrade


#intention

execute if score canupgrade aihunter_dummy matches 0 if score @s aihunter_intent matches 1.. run scoreboard players set @s aihunter_intent 0

execute if score @s aihunter_intent matches -1 if score @s aihunter_hp matches 161.. run scoreboard players set @s aihunter_intent 0

execute if score @s aihunter_intent matches -1 run scoreboard players operation @s aihunter_vx *= #-1 aihunter_dummy

execute if score @s aihunter_intent matches -1 run scoreboard players operation @s aihunter_vz *= #-1 aihunter_dummy


#calculate new position; player's aihunter_d=0 means it is the target. player sprint jumping is 7.127 m/s, normal sprinting is 5.612 m/s (minecraft wiki). Take average ~= 6.4 m/s, normalise aihunter_d by /0.1 = 64 d/s = 19.2 d/6t. max /47

execute if score difficulty aihunter_dummy matches 1 run scoreboard players operation @p[scores={aihunter_d=0}] aihunter_vx /= #70 aihunter_dummy

execute if score difficulty aihunter_dummy matches 1 run scoreboard players operation @p[scores={aihunter_d=0}] aihunter_vz /= #70 aihunter_dummy

execute if score difficulty aihunter_dummy matches 2 run scoreboard players operation @p[scores={aihunter_d=0}] aihunter_vx /= #60 aihunter_dummy

execute if score difficulty aihunter_dummy matches 2 run scoreboard players operation @p[scores={aihunter_d=0}] aihunter_vz /= #60 aihunter_dummy

execute if score difficulty aihunter_dummy matches 3.. run scoreboard players operation @p[scores={aihunter_d=0}] aihunter_vx /= #55 aihunter_dummy

execute if score difficulty aihunter_dummy matches 3.. run scoreboard players operation @p[scores={aihunter_d=0}] aihunter_vz /= #55 aihunter_dummy

execute unless score @s aihunter_intent matches 1.. run scoreboard players operation @s aihunter_x1 += @p[scores={aihunter_d=0}] aihunter_vx

execute unless score @s aihunter_intent matches 1.. run scoreboard players operation @s aihunter_z1 += @p[scores={aihunter_d=0}] aihunter_vz
