playsound minecraft:ui.button.click master @s ~ ~ ~ .1

execute unless entity @e[type=minecraft:armor_stand,tag=aihunter_custom] run tellraw @s {"text":"Failed to Save, Please Try Again.","color":"red"}

execute if score started aihunter_dummy matches 0 if entity @e[type=minecraft:armor_stand,tag=aihunter_custom] run tellraw @s {"text":"Hunter's Custom Appearance Has Been Saved.","color":"gold"}

data modify storage aihunter_custom name set from entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter_custom] CustomName

data modify storage aihunter_custom armor set from entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter_custom] equipment

kill @e[type=minecraft:armor_stand,tag=aihunter_custom]


execute if score started aihunter_dummy matches 0 run gamemode survival @s

execute if score started aihunter_dummy matches 0 run effect give @s minecraft:resistance 5 4 true

execute if score started aihunter_dummy matches 0 run clear @s
