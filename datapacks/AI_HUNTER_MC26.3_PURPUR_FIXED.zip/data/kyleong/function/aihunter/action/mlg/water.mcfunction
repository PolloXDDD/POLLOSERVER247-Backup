##at the nearest, vertically non-passable block
##all blocks between hunter and this block, is passable
#cannot be put in one because version complications

execute unless score version aihunter_dummy matches 117.. run function kyleong:aihunter/action/mlg/water/116

execute if score version aihunter_dummy matches 117..118 run function kyleong:aihunter/action/mlg/water/117

execute if score version aihunter_dummy matches 119 run function kyleong:aihunter/action/mlg/water/119

execute if score version aihunter_dummy matches 120 run function kyleong:aihunter/action/mlg/water/120


#visual

data modify entity @s equipment.mainhand set value {"id":"minecraft:bucket","count":1}
data remove entity @s equipment.offhand

data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.mainhand set value {"id":"minecraft:bucket","count":1}
data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.offhand
