##as at @e[type=minecraft:vindicator,tag=aihunter] positioned ~ ~1.6 ~
##upgrade >= 2, busy <= 0, arrow > -6, target within 4-31 blocks

execute if score @s aihunter_intent matches 0 if score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches ..110 run function kyleong:aihunter/action/shoot/check1

execute if score @s aihunter_intent matches 0 unless score @s aihunter_arrow matches ..-2 unless score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches ..110 if predicate kyleong:aihunter/chance/30 run function kyleong:aihunter/action/shoot/check1
