
#scoreboard players add @s aihunter_busy 1

#SWNE

execute if entity @s[y_rotation=-45.1..45] store result entity @s Motion[2] double 0.001 run scoreboard players set #motion aihunter_dummy 100

execute if entity @s[y_rotation=45.1..135] store result entity @s Motion[0] double 0.001 run scoreboard players set #motion aihunter_dummy -100

execute if entity @s[y_rotation=135.1..225] store result entity @s Motion[2] double 0.001 run scoreboard players set #motion aihunter_dummy -100

execute if entity @s[y_rotation=225.1..315] store result entity @s Motion[0] double 0.001 run scoreboard players set #motion aihunter_dummy 100
