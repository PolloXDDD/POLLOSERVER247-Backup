##first half
#all 1

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=true,up=true,down=true] replace


#1 2s

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=true,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=true,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=true,up=true,down=true] replace


#2 2s

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=true,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=true,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=true,up=true,down=true] replace


#3 2s

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=true,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=true,west=false,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=false,up=true,down=true] replace


#second half
#all 1

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=false,up=false,down=false] replace


#1 2s

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=false,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=false,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=false,up=false,down=false] replace


#2 2s

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=false,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=false,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=false,west=true,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=false,south=true,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=false,south=true,west=false,up=false,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=true,north=true,south=false,west=false,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=true,north=true,south=false,west=false,up=false,down=false] replace


#3 2s

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=false,west=true,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=false,west=true,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=false,south=true,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=false,south=true,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=false,up=true,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=false,up=true,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=true,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=true,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=false,west=true,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=false,west=true,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=false,up=false,down=true] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=false,up=false,down=true] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=false,up=true,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=false,up=true,down=false] replace

execute if block ~ ~ ~ minecraft:glow_lichen[waterlogged=false,east=false,north=true,south=true,west=true,up=false,down=false] run setblock ~ ~ ~ minecraft:glow_lichen[waterlogged=true,east=false,north=true,south=true,west=true,up=false,down=false] replace
