#MC1.16 fences

execute if block ~ ~ ~ minecraft:acacia_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:acacia_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:birch_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:birch_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:crimson_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:crimson_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:dark_oak_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:dark_oak_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:jungle_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:jungle_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:nether_brick_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:nether_brick_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:oak_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:oak_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:spruce_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:spruce_fence[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:warped_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:warped_fence[waterlogged=false] replace
