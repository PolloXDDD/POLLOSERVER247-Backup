##as at @e[type=minecraft:vindicator,tag=aihunter] (non-idle, target available)
#check target's hp, dy

function kyleong:aihunter/find/dy

execute as @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] store result score @s aihunter_hp run data get entity @s Health 10


#weapon choosing

execute unless score @s aihunter_busy matches 1.. unless score @s aihunter_weapon matches 1 if entity @p[distance=..5,gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/action/weapon

execute unless score @s aihunter_busy matches 1.. if entity @p[distance=..5,gamemode=!creative,gamemode=!spectator,team=!aihunter,scores={aihunter_shield=1..}] run function kyleong:aihunter/action/axe


#other

execute unless score @s aihunter_intent matches 2 unless score version aihunter_dummy matches 120.. if predicate kyleong:aihunter/onground_116 run function kyleong:aihunter/act/onground

execute unless score @s aihunter_intent matches 2 if score version aihunter_dummy matches 120.. if predicate kyleong:aihunter/onground_120 run function kyleong:aihunter/act/onground

execute if score difficulty aihunter_dummy matches ..3 run function kyleong:aihunter/act/hp

execute if score @s aihunter_upgrade matches 2.. unless score @s aihunter_arrow matches ..-6 if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,distance=4..31] unless score @s aihunter_busy matches 1.. positioned ~ ~1.6 ~ run function kyleong:aihunter/action/shoot/check


#anti-stuck

execute unless score @s aihunter_intent matches 2 unless predicate kyleong:aihunter/towering run function kyleong:aihunter/check/stuck
