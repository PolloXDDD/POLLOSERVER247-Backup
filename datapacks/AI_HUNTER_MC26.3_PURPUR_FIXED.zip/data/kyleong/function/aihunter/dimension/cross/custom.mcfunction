#use preset cross time 

execute unless score crosstime aihunter_dummy matches ..0 run scoreboard players operation activetime aihunter_dummy = crosstime aihunter_dummy

execute if score crosstime aihunter_dummy matches ..0 run schedule function kyleong:aihunter/check/movestart/start 1t


#notify

function kyleong:aihunter/message/cross


#convert to ticks by *20

execute store result bossbar minecraft:aihunter_timer max run scoreboard players operation activetime aihunter_dummy *= #20 aihunter_dummy
