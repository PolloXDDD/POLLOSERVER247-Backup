
scoreboard players add @s aihunter_busy 1
scoreboard players set @s aihunter_weapon 0

data modify entity @s equipment.mainhand set value {"id":"minecraft:potion","count":1,"components":{"minecraft:potion_contents":{"potion":"minecraft:long_fire_resistance"}}}
data remove entity @s equipment.offhand

data modify entity @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] equipment.mainhand set value {"id":"minecraft:potion","count":1,"components":{"minecraft:potion_contents":{"potion":"minecraft:long_fire_resistance"}}}
data remove entity @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] equipment.offhand

playsound minecraft:entity.generic.drink master @a ~ ~ ~ .8 .8

effect give @s minecraft:luck 2 42 true

effect give @s minecraft:weakness 2 10 true

effect give @s minecraft:fire_resistance 144 0 false

