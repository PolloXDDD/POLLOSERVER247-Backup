##^aihunter/always
##as at @e[type=minecraft:vindicator,tag=aihunter]
#sync attacker and stand

tp @e[limit=1,sort=arbitrary,type=minecraft:armor_stand,tag=aihunter,tag=!aihunter_tped] @s

tag @e[limit=1,sort=arbitrary,type=minecraft:armor_stand,tag=aihunter,tag=!aihunter_tped] add aihunter_tped


#when hunter gets hurt

execute if predicate kyleong:aihunter/red run function kyleong:aihunter/hurt


#mlg

execute unless score falldamage aihunter_dummy matches 1 if score @s aihunter_upgrade matches 1.. if score difficulty aihunter_dummy matches ..3 if predicate kyleong:aihunter/falling run function kyleong:aihunter/action/mlg


##bridging
#in overworld: hunter on ground, not in water, not towering, not idle, target beyond 0.8 blocks, 8.9999+ blocks higher than target.

execute unless score version aihunter_dummy matches 120.. if score dimension aihunter_dummy matches 0 if entity @s[predicate=kyleong:aihunter/onground_116,predicate=!kyleong:aihunter/water,predicate=!kyleong:aihunter/towering,predicate=!kyleong:aihunter/idle,scores={aihunter_d=8..,aihunter_dy=-8999..}] run function kyleong:aihunter/action/build/bridge

execute if score version aihunter_dummy matches 120.. if score dimension aihunter_dummy matches 0 if entity @s[predicate=kyleong:aihunter/onground_120,predicate=!kyleong:aihunter/water,predicate=!kyleong:aihunter/towering,predicate=!kyleong:aihunter/idle,scores={aihunter_d=8..,aihunter_dy=-8999..}] run function kyleong:aihunter/action/build/bridge


#in nether & the end: hunter on ground, not towering, not idle, target beyond 0.8 blocks.

execute unless score version aihunter_dummy matches 120.. if score dimension aihunter_dummy matches 1..2 if entity @s[predicate=kyleong:aihunter/onground_116,predicate=!kyleong:aihunter/towering,predicate=!kyleong:aihunter/idle,scores={aihunter_d=8..}] run function kyleong:aihunter/action/build/bridge

execute if score version aihunter_dummy matches 120.. if score dimension aihunter_dummy matches 1..2 if entity @s[predicate=kyleong:aihunter/onground_120,predicate=!kyleong:aihunter/towering,predicate=!kyleong:aihunter/idle,scores={aihunter_d=8..}] run function kyleong:aihunter/action/build/bridge


#turns

execute if score #turn aihunter_dummy matches 2 run function kyleong:aihunter/act

execute if score #turn aihunter_dummy matches 6 unless predicate kyleong:aihunter/idle unless predicate kyleong:aihunter/red if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/movement


#trigger simulation

execute if score potato aihunter_dummy matches 0 if score dimension aihunter_dummy matches 0 positioned ~-136 ~-384 ~-136 unless entity @p[dx=272,dy=768,dz=272] at @e[type=minecraft:area_effect_cloud,tag=aihunter_worldspawn,limit=1] run function kyleong:aihunter/simulation/upload

execute if score potato aihunter_dummy matches 0 if score dimension aihunter_dummy matches 1 positioned ~-136 ~-384 ~-136 unless entity @p[dx=272,dy=768,dz=272] at @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn,limit=1] run function kyleong:aihunter/simulation/upload

execute if score potato aihunter_dummy matches 0 if score dimension aihunter_dummy matches 2 positioned ~-136 ~-384 ~-136 unless entity @p[dx=272,dy=768,dz=272] at @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn,limit=1] run function kyleong:aihunter/simulation/upload

execute if score potato aihunter_dummy matches 1 if score dimension aihunter_dummy matches 0 positioned ~-40 ~-384 ~-40 unless entity @p[dx=80,dy=768,dz=80] at @e[type=minecraft:area_effect_cloud,tag=aihunter_worldspawn,limit=1] run function kyleong:aihunter/simulation/upload

execute if score potato aihunter_dummy matches 1 if score dimension aihunter_dummy matches 1 positioned ~-40 ~-384 ~-40 unless entity @p[dx=80,dy=768,dz=80] at @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn,limit=1] run function kyleong:aihunter/simulation/upload

execute if score potato aihunter_dummy matches 1 if score dimension aihunter_dummy matches 2 positioned ~-40 ~-384 ~-40 unless entity @p[dx=80,dy=768,dz=80] at @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn,limit=1] run function kyleong:aihunter/simulation/upload


#smooth animation

execute if score quality aihunter_dummy matches 2 unless predicate kyleong:aihunter/idle unless score @s aihunter_intent matches 2 if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/animation/smooth

#function kyleong:aihunter/action/shoot/check
