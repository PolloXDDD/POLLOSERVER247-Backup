execute if score @s aihunter_upgrade matches 1 run tellraw @a {"text":"A Hunter Has Upgraded Its Equipment. (Lv1)","color":"red"}

execute if score @s aihunter_upgrade matches 2 run tellraw @a {"text":"A Hunter Has Upgraded Its Equipment! (Lv2)","color":"red"}

execute if score @s aihunter_upgrade matches 3 run tellraw @a {"text":"A Hunter Has Upgraded Its Equipment!! (Lv3)","color":"red"}

execute if score @s aihunter_upgrade matches 4 run tellraw @a {"text":"A Hunter Has Upgraded Its Equipment!!! (Lv4)","color":"red"}

execute if score @s aihunter_upgrade matches 5 run tellraw @a {"text":"A Hunter Has Upgraded Its Equipment.. (Lv5)","color":"red"}

execute if score @s aihunter_upgrade matches 6 run tellraw @a {"text":"A Hunter Has Upgraded Its Equipment... (Lv6)","color":"red"}
