#MC1.19 added slabs (mangrove, mud brick)
#TOP

execute if block ~ ~ ~ minecraft:mangrove_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:mangrove_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:mud_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:mud_brick_slab[waterlogged=false,type=top] replace


#BOTTOM

execute if block ~ ~ ~ minecraft:mangrove_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:mangrove_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:mud_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:mud_brick_slab[waterlogged=false,type=bottom] replace
