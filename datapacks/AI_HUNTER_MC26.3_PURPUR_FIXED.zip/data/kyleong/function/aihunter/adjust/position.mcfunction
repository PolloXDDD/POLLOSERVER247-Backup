summon minecraft:item_frame ~ ~ ~ {"Facing":1b,"Invisible":0b,"Fixed":1b,"Tags":["aihunter_adjust"]}

execute unless block ~ ~ ~ #minecraft:slabs run tp @s @e[limit=1,sort=nearest,type=item_frame,tag=aihunter_adjust]

execute if block ~ ~ ~ #minecraft:slabs at @e[limit=1,sort=nearest,type=item_frame,tag=aihunter_adjust] run tp @s ~ ~0.46875 ~

kill @e[type=item_frame,tag=aihunter_adjust]
