effect give kyleong minecraft:night_vision 1000000 0 true

effect give kyleong minecraft:resistance 1000000 4 true

effect give kyleong minecraft:saturation 1000000 0 true
