
#execute unless score @s aihunter_busy matches 1.. run function kyleong:aihunter/find/action/move

execute unless score @s aihunter_busy matches 1.. positioned ^ ^1.5 ^0.5 run function kyleong:aihunter/action/break/block

execute if score debug aihunter_dummy matches 2 run say s2
