scoreboard players remove #spawn_remaining aihunter_dummy 1
function kyleong:aihunter/summon/attacker
function kyleong:aihunter/summon/stand
execute if score #spawn_remaining aihunter_dummy matches 1..50 run function kyleong:aihunter/summon/one
