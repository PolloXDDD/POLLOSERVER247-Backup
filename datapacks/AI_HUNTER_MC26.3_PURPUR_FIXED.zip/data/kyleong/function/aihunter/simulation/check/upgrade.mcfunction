##as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,tag=!aihunter_register] at server

execute if score @s aihunter_uptimer matches 1.. if score @s aihunter_intent matches ..0 run scoreboard players set @s aihunter_intent 2

execute unless score @s aihunter_uptimer matches -10.. if score @s aihunter_intent matches 1.. run function kyleong:aihunter/act/upgrade/assign

execute if score @s aihunter_uptimer matches 1.. run scoreboard players remove @s aihunter_uptimer 6

execute if score @s aihunter_uptimer matches -10..0 run function kyleong:aihunter/simulation/upgrade
