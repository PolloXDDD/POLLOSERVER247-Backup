##^aihunter/act/upgrade/intention
##as at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)
#uptimer in ticks
#lv1: 30/28/25s (+wooden sword)

execute unless score @s aihunter_upgrade matches 1.. unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 600

execute unless score @s aihunter_upgrade matches 1.. unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 560

execute unless score @s aihunter_upgrade matches 1.. unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 500


#lv2: 6/5/4 mins (+iron chesplate & boots, stone sword)

execute if score @s aihunter_upgrade matches 1 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 7200

execute if score @s aihunter_upgrade matches 1 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 6000

execute if score @s aihunter_upgrade matches 1 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 4800


#lv3: 6/5/4 mins (+iron helmet & leggings, iron sword)

execute if score @s aihunter_upgrade matches 2 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 7200

execute if score @s aihunter_upgrade matches 2 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 6000

execute if score @s aihunter_upgrade matches 2 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 4800


#lv4: 15/12/10 mins (+diamond chestplate & leggings, diamond sword)

execute if score @s aihunter_upgrade matches 3 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 1 run scoreboard players set @s aihunter_uptimer 18000

execute if score @s aihunter_upgrade matches 3 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 2 run scoreboard players set @s aihunter_uptimer 14400

execute if score @s aihunter_upgrade matches 3 unless score @s aihunter_uptimer matches 1.. if score difficulty aihunter_dummy matches 3.. run scoreboard players set @s aihunter_uptimer 12000


#no upgrade

execute unless score @s aihunter_uptimer matches 1.. run scoreboard players set @s aihunter_intent 0


#start prepare

execute if score @s aihunter_uptimer matches 1.. unless score @s aihunter_upgrade matches 1.. unless entity @p[distance=..10,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent 2

execute if score @s aihunter_uptimer matches 1.. if score @s aihunter_upgrade matches 1.. unless entity @p[distance=..25,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent 2
