#MC1.16 stairs
#111

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=top,shape=inner_left] replace


#211

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=top,shape=inner_left] replace


#311

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=top,shape=inner_left] replace


#411

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=top,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=top,shape=inner_left] replace


#121

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_left] replace


#221

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_left] replace


#321

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_left] replace


#421

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_left] replace


#112

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=bottom,shape=inner_right] replace


#123

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_left] replace


#124

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=bottom,shape=outer_right] replace


#125

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=top,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=top,shape=straight] replace


#112

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=top,shape=inner_right] replace


#113

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=top,shape=outer_left] replace


#114

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=top,shape=outer_right] replace


#115

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=east,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=east,half=bottom,shape=straight] replace


#212

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=top,shape=inner_right] replace


#213

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=top,shape=outer_left] replace


#214

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=top,shape=outer_right] replace


#125

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=top,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=top,shape=straight] replace


#312

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=top,shape=inner_right] replace


#313

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=top,shape=outer_left] replace


#314

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=top,shape=outer_right] replace

#315

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=top,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=top,shape=straight] replace


#412

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=top,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=top,shape=inner_right] replace


#413

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=top,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=top,shape=outer_left] replace


#414

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=top,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=top,shape=outer_right] replace


#415

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=top,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=top,shape=straight] replace


#222

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=bottom,shape=inner_right] replace


#223

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_left] replace


#224

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=bottom,shape=outer_right] replace


#225

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=north,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=north,half=bottom,shape=straight] replace


#322

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=bottom,shape=inner_right] replace


#323

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_left] replace


#324

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=bottom,shape=outer_right] replace


#325

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=south,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=south,half=bottom,shape=straight] replace


#422

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=bottom,shape=inner_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=bottom,shape=inner_right] replace


#423

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_left] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_left] replace


#424

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=bottom,shape=outer_right] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=bottom,shape=outer_right] replace


#425

execute if block ~ ~ ~ minecraft:acacia_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:acacia_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:birch_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:birch_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:crimson_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:crimson_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_oak_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:dark_prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:end_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:granite_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:granite_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:jungle_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:jungle_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_cobblestone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:mossy_stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:oak_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:oak_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_andesite_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_blackstone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_diorite_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:polished_granite_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:prismarine_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:prismarine_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:purpur_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:purpur_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_nether_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_quartz_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_red_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:smooth_sandstone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:spruce_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:spruce_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_brick_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:stone_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:stone_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace

execute if block ~ ~ ~ minecraft:warped_stairs[waterlogged=false,facing=west,half=bottom,shape=straight] run setblock ~ ~ ~ minecraft:warped_stairs[waterlogged=true,facing=west,half=bottom,shape=straight] replace
