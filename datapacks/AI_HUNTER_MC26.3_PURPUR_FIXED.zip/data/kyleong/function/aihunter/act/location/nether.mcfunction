execute unless score @s aihunter_busy matches 1.. run function kyleong:aihunter/find/action/underground/facing
