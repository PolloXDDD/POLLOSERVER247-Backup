#take highest aihunter_d (greater than 100

scoreboard players set #temp aihunter_dummy 0

scoreboard players operation #temp aihunter_dummy > @e[type=!minecraft:player,scores={aihunter_d=100..}] aihunter_d


#calculate time would have taken to the portal. t=d/v, player sprint jumping is 7.127 m/s, normal sprinting is 5.612 m/s (minecraft wiki). Take average ~= 6.4 m/s, normalise aihunter_d by /0.1 = 64

scoreboard players operation #temp aihunter_dummy /= #64 aihunter_dummy

execute if score #temp aihunter_dummy matches 1.. run scoreboard players operation activetime aihunter_dummy += #temp aihunter_dummy

execute if score activetime aihunter_dummy matches 601.. run scoreboard players set activetime aihunter_dummy 600
