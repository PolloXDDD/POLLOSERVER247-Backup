
tellraw @a {"text":"You Still Have 10 Seconds Ahead!","color":"aqua"}

playsound minecraft:block.bell.resonate master @a
