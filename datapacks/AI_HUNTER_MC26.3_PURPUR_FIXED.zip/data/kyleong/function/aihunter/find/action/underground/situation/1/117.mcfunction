#1a=jump
#oo
#oh
#xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 if block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/underground/situation/1/a

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 minecraft:snow[layers=1] if block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/underground/situation/1/a


#1b1=break feet (above player)
#_o
#xh
#xh

execute unless score @s aihunter_busy matches 1.. if score @s aihunter_dy matches ..0 unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/underground/situation/1/b1


#1b2=build jump (under player)
#_o
#xh
#xh

execute unless score @s aihunter_busy matches 1.. if score @s aihunter_dy matches 1.. unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/underground/situation/1/b2


#1c=break front
#_x
#xh
#xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 if block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 unless block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/underground/situation/1/c

execute unless score @s aihunter_busy matches 1.. unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] unless block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/underground/situation/1/c


#1d=break feet
#_x|xo
#oh|oh
#xh|xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^2.5 ^0.5 minecraft:snow[layers=1] run function kyleong:aihunter/find/action/underground/situation/1/d
