execute if block ~ ~ ~ minecraft:glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:black_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:black_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:blue_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:blue_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:brown_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:brown_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:cyan_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:cyan_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:gray_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:gray_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:green_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:green_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:light_blue_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:light_blue_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:light_gray_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:light_gray_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:lime_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:lime_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:magenta_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:orange_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:orange_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:pink_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:pink_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:purple_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:purple_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:red_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:red_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:white_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:white_stained_glass_pane[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:yellow_stained_glass_pane[waterlogged=true] run setblock ~ ~ ~ minecraft:yellow_stained_glass_pane[waterlogged=false] replace
