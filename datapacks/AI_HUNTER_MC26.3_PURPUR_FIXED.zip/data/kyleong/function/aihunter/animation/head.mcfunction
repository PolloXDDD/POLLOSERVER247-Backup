execute if score @s aihunter_dy matches ..-4001 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {"Pose":{"Head":[40f,0f,0f]}}

execute if score @s aihunter_dy matches -4000..-1001 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {"Pose":{"Head":[20f,0f,0f]}}

execute if score @s aihunter_dy matches -1000..1000 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {"Pose":{"Head":[0f,0f,0f]}}

execute if score @s aihunter_dy matches 1001..4000 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {"Pose":{"Head":[340f,0f,0f]}}

execute if score @s aihunter_dy matches 4001.. run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {"Pose":{"Head":[320f,0f,0f]}}



