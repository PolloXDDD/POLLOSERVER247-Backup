##^aihunter/always
##as at server (every 6t)
#check simulation

execute if score simulation aihunter_dummy matches 1.. if entity @p[predicate=!kyleong:aihunter/dead] as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate_complete_cd,tag=!aihunter_temp] at @s run function kyleong:aihunter/simulation/return_cd

execute if score simulation aihunter_dummy matches 1.. if entity @p[predicate=!kyleong:aihunter/dead] run tag @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate_complete_cd,tag=aihunter_temp] remove aihunter_temp


execute if score simulation aihunter_dummy matches 1.. if entity @p[predicate=!kyleong:aihunter/dead] as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate_complete] at @s run function kyleong:aihunter/simulation/return

execute if score simulation aihunter_dummy matches 1.. if entity @p[predicate=!kyleong:aihunter/dead] as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,tag=!aihunter_register] run function kyleong:aihunter/simulation/check/target


#check if set spawnpoint (bed)

execute if score dimension aihunter_dummy matches 0 unless score bed aihunter_dummy matches 1 if predicate kyleong:aihunter/chance/10 unless score version aihunter_dummy matches 120.. as @e[type=minecraft:vindicator,tag=aihunter,predicate=kyleong:aihunter/onground_116,predicate=!kyleong:aihunter/idle,limit=1,sort=furthest] run function kyleong:aihunter/check/bed

execute if score dimension aihunter_dummy matches 0 unless score bed aihunter_dummy matches 1 if predicate kyleong:aihunter/chance/10 if score version aihunter_dummy matches 120.. as @e[type=minecraft:vindicator,tag=aihunter,predicate=kyleong:aihunter/onground_120,predicate=!kyleong:aihunter/idle,limit=1,sort=furthest] run function kyleong:aihunter/check/bed


#active timer count down

execute unless score pause aihunter_dummy matches 1 if score activetime aihunter_dummy matches 1.. store result bossbar minecraft:aihunter_timer value run scoreboard players remove activetime aihunter_dummy 6

execute unless score pause aihunter_dummy matches 1 if score activetime aihunter_dummy matches -10..0 run function kyleong:aihunter/active


#other timer count down

scoreboard players add @a[scores={aihunter_tower=..-1}] aihunter_tower 1

scoreboard players add @a[scores={aihunter_shield=1..}] aihunter_shield 1

scoreboard players set @a[scores={aihunter_shield=4..}] aihunter_shield 0


#friendly golems

team join aihunter @e[type=#kyleong:aihunter/golem,team=!aihunter]
