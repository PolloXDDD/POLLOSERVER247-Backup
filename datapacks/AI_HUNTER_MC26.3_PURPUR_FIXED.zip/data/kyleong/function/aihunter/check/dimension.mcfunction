execute if entity @s[predicate=kyleong:aihunter/dimension/overworld] run scoreboard players set dimension aihunter_dummy 0

execute if entity @s[predicate=kyleong:aihunter/dimension/nether] run scoreboard players set dimension aihunter_dummy 1

execute if entity @s[predicate=kyleong:aihunter/dimension/end] run scoreboard players set dimension aihunter_dummy 2

execute unless score dimension aihunter_dummy matches 0 run function kyleong:aihunter/dimension/aec

execute in minecraft:the_end run forceload add 100 0
