scoreboard objectives add aihunter_x1 dummy

scoreboard objectives add aihunter_y1 dummy

scoreboard objectives add aihunter_z1 dummy

scoreboard objectives add aihunter_x2 dummy

scoreboard objectives add aihunter_y2 dummy

scoreboard objectives add aihunter_z2 dummy

scoreboard objectives add aihunter_vx dummy

scoreboard objectives add aihunter_vz dummy

scoreboard objectives add aihunter_dy dummy

scoreboard objectives add aihunter_d dummy

scoreboard objectives add math_sqrt dummy
scoreboard players set 2 math_sqrt 2

scoreboard objectives add aihunter_death deathCount

scoreboard objectives add aihunter_hp dummy

scoreboard objectives add aihunter_weapon dummy

scoreboard objectives add aihunter_pastx dummy

scoreboard objectives add aihunter_pasty dummy

scoreboard objectives add aihunter_pastz dummy

scoreboard objectives add aihunter_stuck dummy

scoreboard objectives add aihunter_dummy dummy

scoreboard objectives add aihunter_intent dummy

scoreboard objectives add aihunter_upgrade dummy

scoreboard objectives add aihunter_uptimer dummy

scoreboard objectives add aihunter_busy dummy

scoreboard objectives add aihunter_walk minecraft.custom:minecraft.walk_one_cm

scoreboard objectives add aihunter_sprint minecraft.custom:minecraft.sprint_one_cm

scoreboard objectives add aihunter_crouch minecraft.custom:minecraft.crouch_one_cm

scoreboard objectives add aihunter_swim minecraft.custom:minecraft.swim_one_cm

scoreboard objectives add aihunter_owwalk minecraft.custom:minecraft.walk_on_water_one_cm

scoreboard objectives add aihunter_uwwalk minecraft.custom:minecraft.walk_under_water_one_cm

scoreboard objectives add aihunter_pearl minecraft.used:minecraft.ender_pearl

scoreboard objectives add aihunter_tower dummy

scoreboard objectives add aihunter_shield minecraft.used:minecraft.shield

scoreboard objectives add aihunter_ani dummy

scoreboard objectives add aihunter_ticket dummy

scoreboard objectives add aihunter_fall dummy

scoreboard objectives add aihunter_arrow dummy

scoreboard objectives add aihunter_potion dummy

scoreboard objectives add aihunter_posture dummy

#

scoreboard players set #aim0 aihunter_dummy 0

scoreboard players set #aim+ aihunter_dummy -800

scoreboard players set #aim- aihunter_dummy 700


#

scoreboard players set #1000 aihunter_dummy 1000

scoreboard players set #100 aihunter_dummy 100

scoreboard players set #64 aihunter_dummy 64

scoreboard players set #60 aihunter_dummy 60

scoreboard players set #70 aihunter_dummy 70

scoreboard players set #55 aihunter_dummy 55

scoreboard players set #20 aihunter_dummy 20

scoreboard players set #10 aihunter_dummy 10

scoreboard players set #-1 aihunter_dummy -1

scoreboard players add buff aihunter_dummy 0

scoreboard players add dimension aihunter_dummy 0

scoreboard players add glow aihunter_dummy 0

scoreboard players add showhp aihunter_dummy 0

scoreboard players add movestart aihunter_dummy 0

scoreboard players add aheadtime aihunter_dummy 0

scoreboard players add crosstime aihunter_dummy 0

execute unless score survivetime aihunter_dummy matches 10..120 run scoreboard players set survivetime aihunter_dummy 60

scoreboard players operation survivetime_m aihunter_dummy = survivetime aihunter_dummy

scoreboard players operation survivetime_h aihunter_dummy = survivetime aihunter_dummy

scoreboard players operation survivetime_m aihunter_dummy %= #60 aihunter_dummy

scoreboard players operation survivetime_h aihunter_dummy /= #60 aihunter_dummy

execute unless score notifyupgrade aihunter_dummy matches 0..1 run scoreboard players set notifyupgrade aihunter_dummy 1

scoreboard players add keepupgrade aihunter_dummy 0

scoreboard players add potato aihunter_dummy 0

execute if score potato aihunter_dummy matches 0 run scoreboard players set #returnrange aihunter_dummy 1350

execute if score potato aihunter_dummy matches 1 run scoreboard players set #returnrange aihunter_dummy 390

scoreboard players add bed aihunter_dummy 0

execute unless score difficulty aihunter_dummy matches 1..4 run scoreboard players set difficulty aihunter_dummy 2

execute unless score quality aihunter_dummy matches 0..2 run scoreboard players set quality aihunter_dummy 1

execute unless score canupgrade aihunter_dummy matches 0..1 run scoreboard players set canupgrade aihunter_dummy 1

scoreboard players add falldamage aihunter_dummy 0

scoreboard players add failcondition aihunter_dummy 0

scoreboard players add wincondition aihunter_dummy 0

scoreboard players add started aihunter_dummy 0

execute unless score hunters aihunter_dummy matches 1..50 run scoreboard players set hunters aihunter_dummy 1

team add aihunter

execute in minecraft:the_end run forceload add 100 0

execute unless score debug aihunter_dummy matches 1 run gamerule minecraft:send_command_feedback false

bossbar add aihunter_timer {"text":"Activation Time","color":"blue"}
bossbar set minecraft:aihunter_timer color blue

#bossbar add aihunter_timer1 {"text":"Time Survived","color":"yellow"}
#bossbar set minecraft:aihunter_timer1 color yellow

bossbar add aihunter_ms {"text":"Hunters Will Be Activated Immediately After Any Target Moves","color":"red"}
bossbar set minecraft:aihunter_ms color red
