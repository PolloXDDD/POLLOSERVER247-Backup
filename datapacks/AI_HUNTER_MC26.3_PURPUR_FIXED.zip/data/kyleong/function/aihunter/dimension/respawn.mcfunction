execute unless predicate kyleong:aihunter/dead if score dimension aihunter_dummy matches 0 unless predicate kyleong:aihunter/dimension/overworld run function kyleong:aihunter/dimension/cross/identify

execute unless predicate kyleong:aihunter/dead if score dimension aihunter_dummy matches 1 unless predicate kyleong:aihunter/dimension/nether run function kyleong:aihunter/dimension/cross/identify

execute unless predicate kyleong:aihunter/dead if predicate kyleong:aihunter/dimension/overworld run scoreboard players set dimension aihunter_dummy 0

execute unless predicate kyleong:aihunter/dead if predicate kyleong:aihunter/dimension/nether run scoreboard players set dimension aihunter_dummy 1

execute if predicate kyleong:aihunter/dead run scoreboard players set @s aihunter_death 999999999
