execute store result score @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate] aihunter_x1 run data get entity @s Pos[0] 10

execute store result score @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate] aihunter_z1 run data get entity @s Pos[2] 10

tp @e[type=#kyleong:aihunter/hunter,tag=aihunter] ~ ~ ~
