effect clear @e[type=minecraft:vindicator,tag=aihunter] minecraft:blindness

effect clear @e[type=minecraft:vindicator,tag=aihunter] minecraft:weakness

scoreboard players add @e[type=minecraft:vindicator,tag=aihunter] aihunter_intent 0

execute unless score difficulty aihunter_dummy matches 4.. run effect clear @e[type=minecraft:vindicator,tag=aihunter] minecraft:resistance

scoreboard players set @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate] aihunter_busy 0


tellraw @a {"text":"All Hunters Have Been Activated!","color":"red"}

execute at @a run playsound minecraft:entity.wither.ambient master @a ~ ~ ~ 0.3 0.5 1


bossbar set minecraft:aihunter_timer players 0
bossbar set minecraft:aihunter_ms players 0

scoreboard players set activetime aihunter_dummy -999

function kyleong:aihunter/reset

team modify aihunter collisionRule always


#set survive timer

execute unless score pause aihunter_dummy matches 1 if score wincondition aihunter_dummy matches 6 run function kyleong:aihunter/survivetimer/set
