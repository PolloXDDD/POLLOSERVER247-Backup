execute unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate] run tp @e[type=#kyleong:aihunter/hunter,tag=aihunter,limit=1,sort=furthest] ~ ~ ~

execute store result score @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,limit=1,sort=arbitrary] aihunter_x1 run data get entity @s Pos[0] 10

execute store result score @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,limit=1,sort=arbitrary] aihunter_z1 run data get entity @s Pos[2] 10
