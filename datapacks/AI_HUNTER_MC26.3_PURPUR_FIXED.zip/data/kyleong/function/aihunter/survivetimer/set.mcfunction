##^aihunter/active
##as at server

scoreboard players operation timer1 aihunter_dummy = survivetime aihunter_dummy

scoreboard players operation timer1 aihunter_dummy *= #60 aihunter_dummy

scoreboard players operation timer1 aihunter_dummy *= #20 aihunter_dummy
