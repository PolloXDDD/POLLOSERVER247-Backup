#positioned ~0.3 ~ ~

scoreboard players add @s aihunter_tower 1

execute if block ~0.5 ~-0.5 ~1 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~0.5 ~-1.5 ~1 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~0.5 ~-2.5 ~1 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~1.2 ~-0.5 ~ #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~1.2 ~-1.5 ~ #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~1.2 ~-2.5 ~ #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~0.5 ~-0.5 ~-1 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~0.5 ~-1.5 ~-1 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~0.5 ~-2.5 ~-1 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1
