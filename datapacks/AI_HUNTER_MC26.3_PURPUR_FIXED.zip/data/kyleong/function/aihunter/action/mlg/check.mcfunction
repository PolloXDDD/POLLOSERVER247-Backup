#mlg fail

execute if score difficulty aihunter_dummy matches 1 if predicate kyleong:aihunter/chance/40 run scoreboard players set @s aihunter_fall -99

execute if score difficulty aihunter_dummy matches 2 if predicate kyleong:aihunter/chance/20 run scoreboard players set @s aihunter_fall -99

execute if score difficulty aihunter_dummy matches 3 if predicate kyleong:aihunter/chance/5 run scoreboard players set @s aihunter_fall -99


#debug reporting

execute if score debug aihunter_dummy matches 1 unless score @s aihunter_fall matches -99 run say mlg: check succeed

execute if score debug aihunter_dummy matches 1 if score @s aihunter_fall matches -99 run say mlg: check failed


#actual mlg

execute unless score @s aihunter_fall matches -99 unless score dimension aihunter_dummy matches 1 run function kyleong:aihunter/action/mlg/water

execute unless score @s aihunter_fall matches -99 if score dimension aihunter_dummy matches 1 positioned ~ ~0.5 ~ run function kyleong:aihunter/action/mlg/ladder


#cooldown, avoid checking in the next ~2 ticks

scoreboard players set @s aihunter_fall -3
