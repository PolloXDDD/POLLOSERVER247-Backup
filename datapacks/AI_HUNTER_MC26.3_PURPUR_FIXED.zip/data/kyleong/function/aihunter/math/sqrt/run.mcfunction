#square root calculator data pack by NOPEname, it has been modified to use in aihunter data pack.

scoreboard players operation out math_sqrt = in math_sqrt
scoreboard players set tmp math_sqrt 1

execute if score out math_sqrt > tmp math_sqrt run function kyleong:aihunter/math/sqrt/loop
