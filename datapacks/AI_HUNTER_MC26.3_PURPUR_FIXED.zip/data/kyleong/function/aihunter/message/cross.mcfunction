tellraw @a {"text":"All Hunters Has Been Teleported To Your Dimension, Temporary Deactivated.","color":"aqua"}

execute unless score crosstime aihunter_dummy matches ..-1 run tellraw @a [{"score":{"name":"activetime","objective":"aihunter_dummy"},"color":"aqua"},{"text":" Seconds Before Reactivation.","color":"aqua"}]
