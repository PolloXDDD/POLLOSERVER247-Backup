title @a subtitle {"text":"Thanks For Playing AI Hunter Datapack!","color":"gold"}

title @a title {"text":"You Won!","color":"gold","bold":true}

tellraw @a ""
tellraw @a ""
tellraw @a ""
tellraw @a ""
tellraw @a ""
tellraw @a ""
tellraw @a ""
tellraw @a ""
tellraw @a {"text":"--------------------------------------------","color":"yellow","bold":true}
tellraw @a ""

execute if score difficulty aihunter_dummy matches 1 run tellraw @a {"text":"You Have Beaten AI Hunter Datapack In Easy Mode!","color":"yellow","bold":false}

execute if score difficulty aihunter_dummy matches 2 run tellraw @a {"text":"You Have Beaten AI Hunter Datapack In Normal Mode!","color":"gold","bold":false}

execute if score difficulty aihunter_dummy matches 3 run tellraw @a {"text":"You Have Beaten AI Hunter Datapack In Hard Mode!","color":"gold","bold":true}

execute if score difficulty aihunter_dummy matches 4 run tellraw @a {"text":"You Have Beaten AI Hunter Datapack In Terminator Mode!","color":"gold","bold":true}


execute if score wincondition aihunter_dummy matches 0 run tellraw @a [{"text":"Beaten Minecraft ","color":"gold","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]

execute if score wincondition aihunter_dummy matches 1 run tellraw @a [{"text":"Found Diamond ","color":"aqua","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]

execute if score wincondition aihunter_dummy matches 2 run tellraw @a [{"text":"Went To Nether ","color":"red","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]

execute if score wincondition aihunter_dummy matches 3 run tellraw @a [{"text":"Killed An Elder Guardian ","color":"blue","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]

execute if score wincondition aihunter_dummy matches 4 run tellraw @a [{"text":"Killed A Warden ","color":"light_purple","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]

execute if score wincondition aihunter_dummy matches 5 run tellraw @a [{"text":"Killed A Wither ","color":"dark_gray","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]

execute if score wincondition aihunter_dummy matches 6 run tellraw @a [{"text":"Survived For ","color":"yellow","bold":false},{"score":{"name":"survivetime_h","objective":"aihunter_dummy"},"color":"red"},{"text":"Hrs ","color":"yellow","bold":false},{"score":{"name":"survivetime_m","objective":"aihunter_dummy"},"color":"red"},{"text":"Mins ","color":"yellow","bold":false},{"text":"Under The Pursuit Of ","color":"gold","bold":false},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"},{"text":" AI Hunter(s) ","color":"gold","bold":false}]


tellraw @a ""

execute if score difficulty aihunter_dummy matches 1 run tellraw @a {"text":"Good job! May be you could try normal mode next!","color":"green"}

execute if score difficulty aihunter_dummy matches 2 run tellraw @a {"text":"You are pretty good! But are you capable of beating hard mode?","color":"green"}

execute if score difficulty aihunter_dummy matches 3 run tellraw @a {"text":"WOW! I now consider you as an awesome minecrafter!","color":"green"}

execute if score difficulty aihunter_dummy matches 4 run tellraw @a {"text":"Wait, I didn't expect anyone to be able to complete this mode!","color":"green"}

tellraw @a {"text":" "}
tellraw @a {"text":"[URL] Check out my other datapacks!","color":"yellow","underlined":true,"click_event":{"action":"open_url","url":"https://www.planetminecraft.com/member/kyleong/"},"hover_event":{"action":"show_text","value":[{"text":"To: planetminecraft.com","color":"yellow"}]}}

tellraw @a {"text":" "}
tellraw @a {"text":"[URL] Subscribe to me on Youtube!","color":"yellow","underlined":true,"click_event":{"action":"open_url","url":"https://www.youtube.com/channel/UCGclCRGdWUjJdVcHLZfdaOg"},"hover_event":{"action":"show_text","value":[{"text":"To: youtube.com","color":"yellow"}]}}

tellraw @a {"text":" "}
#tellraw @a {"text":"[URL] Follow me on twitter!","color":"yellow","underlined":true,"hoverEvent":{"action":"show_text","contents":[{"text":"To: twitter.com","color":"yellow"}]},"clickEvent":{"action":"open_url","value":"https://twitter.com/kyleong123"}}

tellraw @a [{"text":"<Start Menu>","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/menu"}}]

tellraw @a {"text":"--------------------------------------------","color":"yellow","bold":true}
