##as @a[scores={aihunter_death=1..}] at server
#failcondition: 0 = Never, pauses if dies; 1 = Never; 2 = Fail if dies

execute if score failcondition aihunter_dummy matches 0 run function kyleong:aihunter/pause

execute if score failcondition aihunter_dummy matches 2 run function kyleong:aihunter/stop

execute if score failcondition aihunter_dummy matches 2 run tellraw @a {"text":"[AI Hunter] You Have Failed The Challenge!","color":"red","bold":true}

execute if score failcondition aihunter_dummy matches 2 run tellraw @a {"text":"Oh how unfortunate... But please don't give up! You can always try again!","color":"green"}
