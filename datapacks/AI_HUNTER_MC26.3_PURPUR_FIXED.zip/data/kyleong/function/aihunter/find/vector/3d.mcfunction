#deltaX & deltaZ

execute store result score @s aihunter_x1 run data get entity @s Pos[0] 10

execute store result score @s aihunter_z1 run data get entity @s Pos[2] 10

execute store result score @s aihunter_x2 run data get entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] Pos[0] 10

execute store result score @s aihunter_z2 run data get entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] Pos[2] 10

scoreboard players operation @s aihunter_x2 -= @s aihunter_x1

scoreboard players operation @s aihunter_z2 -= @s aihunter_z1

scoreboard players operation @s aihunter_vx = @s aihunter_x2

scoreboard players operation @s aihunter_vz = @s aihunter_z2

scoreboard players operation @s aihunter_vx *= #1000 aihunter_dummy

scoreboard players operation @s aihunter_vz *= #1000 aihunter_dummy


#deltaY

function kyleong:aihunter/find/dy

scoreboard players operation #y aihunter_dummy = @s aihunter_dy

execute unless score #redo aihunter_dummy matches 1.. run scoreboard players operation #y aihunter_dummy -= #aim0 aihunter_dummy

execute if score #redo aihunter_dummy matches 1 run scoreboard players operation #y aihunter_dummy -= #aim+ aihunter_dummy

execute if score #redo aihunter_dummy matches 2.. run scoreboard players operation #y aihunter_dummy -= #aim- aihunter_dummy

scoreboard players operation #y aihunter_dummy /= #100 aihunter_dummy


scoreboard players operation #vy aihunter_dummy = #y aihunter_dummy

scoreboard players operation #vy aihunter_dummy *= #1000 aihunter_dummy


# r

scoreboard players operation @s aihunter_x2 *= @s aihunter_x2

scoreboard players operation @s aihunter_z2 *= @s aihunter_z2

scoreboard players operation #y aihunter_dummy *= #y aihunter_dummy


scoreboard players operation @s aihunter_x2 += @s aihunter_z2

scoreboard players operation @s aihunter_x2 += #y aihunter_dummy

scoreboard players operation in math_sqrt = @s aihunter_x2
function kyleong:aihunter/math/sqrt/run
scoreboard players operation #r aihunter_dummy = out math_sqrt


#vx, vy, vz in 3d


scoreboard players operation @s aihunter_vx /= #r aihunter_dummy

scoreboard players operation @s aihunter_vz /= #r aihunter_dummy

scoreboard players operation #vy aihunter_dummy /= #r aihunter_dummy
