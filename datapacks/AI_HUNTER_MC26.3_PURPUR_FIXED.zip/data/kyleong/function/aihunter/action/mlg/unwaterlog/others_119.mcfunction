execute unless score @s aihunter_upgrade matches 2.. run function kyleong:aihunter/action/mlg/unwaterlog/leaves

execute if score @s aihunter_upgrade matches 2.. if block ~ ~ ~ #minecraft:leaves run setblock ~ ~ ~ minecraft:water destroy


execute if block ~ ~ ~ minecraft:sculk_shrieker[waterlogged=true,can_summon=true] run setblock ~ ~ ~ minecraft:sculk_shrieker[waterlogged=false,can_summon=true,shrieking=false] replace

execute if block ~ ~ ~ minecraft:sculk_shrieker[waterlogged=true,can_summon=false] run setblock ~ ~ ~ minecraft:sculk_shrieker[waterlogged=false,can_summon=false,shrieking=false] replace

execute if block ~ ~ ~ minecraft:mangrove_roots[waterlogged=true] run setblock ~ ~ ~ minecraft:mangrove_roots[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:sculk_vein run function kyleong:aihunter/action/mlg/unwaterlog/veins
