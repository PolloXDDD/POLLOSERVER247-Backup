execute unless score dimension aihunter_dummy matches 2 run scoreboard players set dimension aihunter_dummy 0


#assume on the tick that player travel through dimension, area in the previous dimension is still loaded.

#execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_overworld_portal,limit=1] run function kyleong:aihunter/dimension/cross/hunter

#execute unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_overworld_portal,limit=1] run function kyleong:aihunter/dimension/cross/hunter

execute positioned ~ ~6 ~ run function kyleong:aihunter/dimension/cross/hunter
