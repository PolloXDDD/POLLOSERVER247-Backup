
execute unless score @s aihunter_busy matches 1.. if score @s aihunter_y2 matches ..56999 unless predicate kyleong:aihunter/dimension/end run function kyleong:aihunter/action/break/down


execute unless score @s aihunter_busy matches 1.. if score @s aihunter_d matches ..110 if score @s aihunter_dy matches 3500.. if score @s aihunter_intent matches 0 if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,scores={aihunter_tower=..-1}] run function kyleong:aihunter/action/build/tower


execute unless score @s aihunter_busy matches 1.. run function kyleong:aihunter/find/action/surface/facing
