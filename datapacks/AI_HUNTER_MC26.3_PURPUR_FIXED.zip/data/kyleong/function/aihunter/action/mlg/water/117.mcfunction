##117 block tags
##at the nearest, vertically non-passable block
##all blocks between hunter and this block is passable

#break instant mine-able blocks(only upper 2 blocks)

execute if block ~ ~1 ~ #kyleong:aihunter/instant_break_117 run setblock ~ ~1 ~ air destroy

execute if block ~ ~2 ~ #kyleong:aihunter/instant_break_117 run setblock ~ ~2 ~ air destroy


#break instant mine-able blocks(only upper 2 blocks)

execute if block ~ ~1 ~ #kyleong:aihunter/instant_break run setblock ~ ~1 ~ air destroy

execute if block ~ ~2 ~ #kyleong:aihunter/instant_break run setblock ~ ~2 ~ air destroy


#block above (passable) is water waterlogable

execute if block ~ ~1 ~ #kyleong:aihunter/waterlogable_117 positioned ~ ~1 ~ run function kyleong:aihunter/action/mlg/waterlog


#located block is waterlogable & block above (passable) is not water waterlogable

execute unless block ~ ~1 ~ #kyleong:aihunter/waterlogable_117 if block ~ ~ ~ #kyleong:aihunter/waterlogable_117 run function kyleong:aihunter/action/mlg/waterlog


#located block is not waterlogable & block above (passable) is not water waterlogable

execute unless block ~ ~1 ~ #kyleong:aihunter/waterlogable_117 unless block ~ ~ ~ #kyleong:aihunter/waterlogable_117 positioned ~ ~1 ~ run function kyleong:aihunter/action/mlg/water1
