#calculate distance between hunter and server

scoreboard players operation distancex aihunter_dummy = worldspawnx aihunter_dummy

scoreboard players operation distancez aihunter_dummy = worldspawnz aihunter_dummy

scoreboard players operation distancex aihunter_dummy -= @s aihunter_x1

scoreboard players operation distancez aihunter_dummy -= @s aihunter_z1

scoreboard players operation distancex aihunter_dummy /= #10 aihunter_dummy

scoreboard players operation distancez aihunter_dummy /= #10 aihunter_dummy

scoreboard players operation distancex aihunter_dummy *= distancex aihunter_dummy

scoreboard players operation distancez aihunter_dummy *= distancez aihunter_dummy

scoreboard players operation distancex aihunter_dummy += distancez aihunter_dummy


#place bed if >~ 300 from spawnpoint

execute if score distancex aihunter_dummy matches 100000.. if score @s aihunter_d matches 200.. run function kyleong:aihunter/action/build/bed
