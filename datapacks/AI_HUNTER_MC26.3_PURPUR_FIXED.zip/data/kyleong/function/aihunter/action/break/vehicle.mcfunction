execute if entity @s[type=minecraft:oak_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:oak_boat",count:1}}
execute if entity @s[type=minecraft:spruce_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:spruce_boat",count:1}}
execute if entity @s[type=minecraft:birch_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:birch_boat",count:1}}
execute if entity @s[type=minecraft:jungle_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:jungle_boat",count:1}}
execute if entity @s[type=minecraft:acacia_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:acacia_boat",count:1}}
execute if entity @s[type=minecraft:cherry_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:cherry_boat",count:1}}
execute if entity @s[type=minecraft:dark_oak_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:dark_oak_boat",count:1}}
execute if entity @s[type=minecraft:pale_oak_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:pale_oak_boat",count:1}}
execute if entity @s[type=minecraft:mangrove_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:mangrove_boat",count:1}}
execute if entity @s[type=minecraft:bamboo_raft] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:bamboo_raft",count:1}}
execute if entity @s[type=minecraft:poplar_boat] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:poplar_boat",count:1}}






execute if entity @s[type=minecraft:minecart] run summon minecraft:item ~ ~ ~ {"Item":{"id":"minecraft:minecart","count":1}}

kill @s
