execute unless score version aihunter_dummy matches 117.. run function kyleong:aihunter/action/shoot/raycast/116

execute if score version aihunter_dummy matches 117..118 run function kyleong:aihunter/action/shoot/raycast/117

execute if score version aihunter_dummy matches 119.. run function kyleong:aihunter/action/shoot/raycast/119


execute unless score #raycastentities aihunter_dummy matches 1.. run scoreboard players add #redo aihunter_dummy 1

scoreboard players set #raycastdistance aihunter_dummy 0
