#approximate for 6s

execute if score @s aihunter_stuck matches 0 run scoreboard players operation @s aihunter_pastx = @s aihunter_x1

execute if score @s aihunter_stuck matches 0 run scoreboard players operation @s aihunter_pasty = @s aihunter_y1

execute if score @s aihunter_stuck matches 0 run scoreboard players operation @s aihunter_pastz = @s aihunter_z1

scoreboard players add @s aihunter_stuck 1

execute unless score @s aihunter_pastx = @s aihunter_x1 run scoreboard players set @s aihunter_stuck 0

execute unless score @s aihunter_pastz = @s aihunter_z1 run scoreboard players set @s aihunter_stuck 0

execute if predicate kyleong:aihunter/onground unless score @s aihunter_pasty = @s aihunter_y1 run scoreboard players set @s aihunter_stuck 0

execute if score @s aihunter_stuck matches 19.. run function kyleong:aihunter/action/unstuck
