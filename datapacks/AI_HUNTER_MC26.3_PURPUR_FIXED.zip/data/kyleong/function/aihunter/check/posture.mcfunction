##needs to be as at player

execute anchored eyes positioned ^ ^ ^ if entity @s[distance=..0.21] run scoreboard players set @s aihunter_posture 4

execute anchored eyes positioned ^ ^ ^ unless entity @s[distance=..0.21] if entity @s[distance=..0.41] run scoreboard players set @s aihunter_posture 3

execute anchored eyes positioned ^ ^ ^ unless entity @s[distance=..0.41] if entity @s[distance=..1.27] run scoreboard players set @s aihunter_posture 2

execute anchored eyes positioned ^ ^ ^ unless entity @s[distance=..1.27] if entity @s[distance=..1.63] run scoreboard players set @s aihunter_posture 1


execute if score @s aihunter_posture matches 2..4 run summon minecraft:area_effect_cloud ~ ~1.6 ~ {"Duration":1,"Tags":["aihunter_anchor"]}
