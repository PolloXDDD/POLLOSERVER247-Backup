execute store result entity @s Motion[0] double 0.00026 run scoreboard players get @s aihunter_vx

execute store result entity @s Motion[2] double 0.00026 run scoreboard players get @s aihunter_vz
