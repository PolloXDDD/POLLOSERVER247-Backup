execute if block ~ ~ ~ minecraft:decorated_pot run setblock ~ ~ ~ minecraft:water destroy
