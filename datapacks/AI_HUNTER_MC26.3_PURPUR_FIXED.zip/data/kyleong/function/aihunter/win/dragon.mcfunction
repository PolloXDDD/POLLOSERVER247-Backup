#kyleong:aihunter/win must be executed first

execute if score started aihunter_dummy matches 1 if score wincondition aihunter_dummy matches 0 run function kyleong:aihunter/win

advancement revoke @s only kyleong:aihunter/win/dragon
