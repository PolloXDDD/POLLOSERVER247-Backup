advancement revoke @s only kyleong:aihunter/dimension

execute if score started aihunter_dummy matches 1 if entity @s[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/dimension/cross/identify
