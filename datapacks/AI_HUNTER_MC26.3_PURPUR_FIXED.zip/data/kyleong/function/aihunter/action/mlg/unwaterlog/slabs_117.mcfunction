#MC1.17 added slabs (deepslates, coppers)
#TOP

execute if block ~ ~ ~ minecraft:cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:waxed_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:waxed_cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:waxed_exposed_cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:waxed_oxidized_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:waxed_oxidized_cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:waxed_weathered_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:waxed_weathered_cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:weathered_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:weathered_cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:polished_deepslate_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:polished_deepslate_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:cobbled_deepslate_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:cobbled_deepslate_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:deepslate_brick_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:deepslate_brick_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:deepslate_tile_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:deepslate_tile_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:exposed_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:exposed_cut_copper_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:oxidized_cut_copper_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:oxidized_cut_copper_slab[waterlogged=false,type=top] replace


#BOTTOM

execute if block ~ ~ ~ minecraft:cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:waxed_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:waxed_cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:waxed_exposed_cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:waxed_oxidized_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:waxed_oxidized_cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:waxed_weathered_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:waxed_weathered_cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:weathered_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:weathered_cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:polished_deepslate_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:polished_deepslate_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:cobbled_deepslate_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:cobbled_deepslate_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:deepslate_brick_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:deepslate_brick_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:deepslate_tile_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:deepslate_tile_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:exposed_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:exposed_cut_copper_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:oxidized_cut_copper_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:oxidized_cut_copper_slab[waterlogged=false,type=bottom] replace
