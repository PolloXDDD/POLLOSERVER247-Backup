##as at the player who clicked start
#boot the system, reset world and heal player

playsound minecraft:block.bell.use master @a

scoreboard players set started aihunter_dummy 1

function kyleong:aihunter/check/dimension

execute if score dimension aihunter_dummy matches 0 run function kyleong:aihunter/check/worldspawn

function kyleong:aihunter/check/version

function kyleong:aihunter/menu

function kyleong:aihunter/reset

execute if score debug aihunter_dummy matches 1 run function kyleong:aihunter/debug/effect

scoreboard players set @a aihunter_death 0

time set 0

weather clear

effect give @a minecraft:instant_health 1 5 true

effect give @a minecraft:saturation 1 255 true


#the hunters (set_initial needs to be executed after summon/set)

function kyleong:aihunter/summon/hunter

execute as @e[type=#kyleong:aihunter/hunter,tag=aihunter,predicate=kyleong:aihunter/fresh] run function kyleong:aihunter/summon/set

execute as @e[type=minecraft:vindicator,tag=aihunter,predicate=kyleong:aihunter/fresh] run function kyleong:aihunter/summon/set_initial

execute unless score aheadtime aihunter_dummy matches 1.. run schedule function kyleong:aihunter/check/movestart/start 1t


#set ahead time

execute if score aheadtime aihunter_dummy matches 1.. run scoreboard players operation activetime aihunter_dummy = aheadtime aihunter_dummy

execute if score aheadtime aihunter_dummy matches 1.. store result bossbar minecraft:aihunter_timer max run scoreboard players operation activetime aihunter_dummy *= #20 aihunter_dummy

execute store result bossbar minecraft:aihunter_timer value run scoreboard players get activetime aihunter_dummy

execute if score aheadtime aihunter_dummy matches 1.. run bossbar set minecraft:aihunter_timer players @a


#messages

tellraw @a {"text":"[AI Hunter] Your Challenge Has Started, Good Luck!","color":"red","bold":true}

execute if score difficulty aihunter_dummy matches 1 run title @a subtitle {"text":"[Easy] Challenge Started","color":"green","bold":true}

execute if score difficulty aihunter_dummy matches 2 run title @a subtitle {"text":"[Normal] Challenge Started","color":"white","bold":true}

execute if score difficulty aihunter_dummy matches 3 run title @a subtitle {"text":"[Hard] Challenge Started","color":"red","bold":true}

execute if score difficulty aihunter_dummy matches 4 run title @a subtitle {"text":"[Terminator] Challenge Started","color":"dark_red","bold":true}

execute unless score hunters aihunter_dummy matches 2.. run title @a title {"text":"AI Hunter","color":"red","bold":true}

execute if score hunters aihunter_dummy matches 2.. run title @a title [{"text":"AI Hunter x ","color":"red","bold":true},{"score":{"name":"hunters","objective":"aihunter_dummy"},"color":"red"}]

execute if score aheadtime aihunter_dummy matches 1..600 run tellraw @a [{"text":"All Hunters Will Be Activated After ","color":"aqua"},{"score":{"name":"aheadtime","objective":"aihunter_dummy"},"color":"aqua"},{"text":" Seconds.","color":"aqua"}]
