#1=break above
#_x|_x
#xh|oh
#oh|xh

execute unless score @s aihunter_busy matches 1.. unless block ^ ^0.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^0.5 ^0.5 minecraft:snow[layers=1] unless block ^ ^2.5 ^ #kyleong:aihunter/passable_120 unless block ^ ^2.5 ^ minecraft:snow[layers=1] run function kyleong:aihunter/find/action/liquid/situation/1

execute unless score @s aihunter_busy matches 1.. unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] unless block ^ ^2.5 ^ #kyleong:aihunter/passable_120 unless block ^ ^2.5 ^ minecraft:snow[layers=1] run function kyleong:aihunter/find/action/liquid/situation/1


#2=build feet
#_o
#xh
#oh

execute unless score @s aihunter_busy matches 1.. if block ^ ^2.5 ^ #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] if block ^ ^0.5 ^0.5 #kyleong:aihunter/passable_120 run function kyleong:aihunter/find/action/liquid/situation/2


#3=break front
#_o
#xh
#xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^2.5 ^ #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] unless block ^ ^0.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^0.5 ^0.5 minecraft:snow[layers=1] run function kyleong:aihunter/find/action/liquid/situation/3


#4=break front-above
#xo
#oh
#xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^2.5 ^ #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] unless block ^ ^0.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^0.5 ^0.5 minecraft:snow[layers=1] unless block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_120 unless block ^ ^2.5 ^0.5 minecraft:snow[layers=1] run function kyleong:aihunter/find/action/liquid/situation/4
