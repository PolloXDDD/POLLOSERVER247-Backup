#max speed 0.72%

execute if score difficulty aihunter_dummy matches 1 store result entity @s Motion[0] double 0.0006 run scoreboard players get @s aihunter_vx

execute if score difficulty aihunter_dummy matches 1 store result entity @s Motion[2] double 0.0006 run scoreboard players get @s aihunter_vz


execute if score difficulty aihunter_dummy matches 2 store result entity @s Motion[0] double 0.00069 run scoreboard players get @s aihunter_vx

execute if score difficulty aihunter_dummy matches 2 store result entity @s Motion[2] double 0.00069 run scoreboard players get @s aihunter_vz


execute if score difficulty aihunter_dummy matches 3.. store result entity @s Motion[0] double 0.00071 run scoreboard players get @s aihunter_vx

execute if score difficulty aihunter_dummy matches 3.. store result entity @s Motion[2] double 0.00071 run scoreboard players get @s aihunter_vz
