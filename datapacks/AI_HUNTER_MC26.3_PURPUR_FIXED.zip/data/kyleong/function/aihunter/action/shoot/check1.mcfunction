##as at @e[type=minecraft:vindicator,tag=aihunter] positioned ~ ~1.6 ~

scoreboard players set #raycastentities aihunter_dummy 0

scoreboard players set #raycastdistance aihunter_dummy 0

scoreboard players set #redo aihunter_dummy 0

scoreboard players set #pose aihunter_dummy 0

execute as @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] at @s run function kyleong:aihunter/check/posture


##aim angles
#0

execute facing entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,distance=21..] feet rotated ~ ~-4 run function kyleong:aihunter/action/shoot/raycast/version

execute facing entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,distance=..20.99,scores={aihunter_posture=1}] eyes run function kyleong:aihunter/action/shoot/raycast/version

execute if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,distance=..20.99,scores={aihunter_posture=2..4}] facing entity @e[limit=1,sort=nearest,type=minecraft:area_effect_cloud,tag=aihunter_anchor] feet run function kyleong:aihunter/action/shoot/raycast/version


#+

execute if score #redo aihunter_dummy matches 1 facing entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,scores={aihunter_posture=1}] eyes rotated ~ ~-2 run function kyleong:aihunter/action/shoot/raycast/version

execute if score #redo aihunter_dummy matches 1 if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,scores={aihunter_posture=2..4}] facing entity @e[limit=1,sort=nearest,type=minecraft:area_effect_cloud,tag=aihunter_anchor] feet rotated ~ ~-2 run function kyleong:aihunter/action/shoot/raycast/version


#-

execute if score #redo aihunter_dummy matches 2 facing entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter,distance=..31] feet rotated ~ ~-3.4 run function kyleong:aihunter/action/shoot/raycast/version


#shoot

execute if score #raycastentities aihunter_dummy matches 1.. positioned ~ ~-1.6 ~ run function kyleong:aihunter/action/shoot/arrow
