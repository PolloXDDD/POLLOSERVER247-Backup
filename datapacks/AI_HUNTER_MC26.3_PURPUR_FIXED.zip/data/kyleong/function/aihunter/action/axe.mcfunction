execute if score @s aihunter_upgrade matches 1 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:wooden_axe","count":1}
execute if score @s aihunter_upgrade matches 1 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 2 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:stone_axe","count":1}
execute if score @s aihunter_upgrade matches 2 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 3 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:iron_axe","count":1}
execute if score @s aihunter_upgrade matches 3 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 4 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:diamond_axe","count":1}
execute if score @s aihunter_upgrade matches 4 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 5 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:diamond_axe","count":1}
execute if score @s aihunter_upgrade matches 5 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 6.. run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:netherite_axe","count":1}
execute if score @s aihunter_upgrade matches 6.. run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand


execute if score @s aihunter_upgrade matches 1 run data modify entity @s equipment.mainhand set value {"id":"minecraft:wooden_axe","count":1}
execute if score @s aihunter_upgrade matches 1 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 2 run data modify entity @s equipment.mainhand set value {"id":"minecraft:stone_axe","count":1}
execute if score @s aihunter_upgrade matches 2 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 3 run data modify entity @s equipment.mainhand set value {"id":"minecraft:iron_axe","count":1}
execute if score @s aihunter_upgrade matches 3 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 4 run data modify entity @s equipment.mainhand set value {"id":"minecraft:diamond_axe","count":1}
execute if score @s aihunter_upgrade matches 4 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 5 run data modify entity @s equipment.mainhand set value {"id":"minecraft:diamond_axe","count":1}
execute if score @s aihunter_upgrade matches 5 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 6.. run data modify entity @s equipment.mainhand set value {"id":"minecraft:netherite_axe","count":1}
execute if score @s aihunter_upgrade matches 6.. run data remove entity @s equipment.offhand


effect give @s minecraft:weakness 1 0 true

scoreboard players add @s aihunter_busy 4

scoreboard players set @s aihunter_weapon 0

execute if score debug aihunter_dummy matches 1 run say axe
