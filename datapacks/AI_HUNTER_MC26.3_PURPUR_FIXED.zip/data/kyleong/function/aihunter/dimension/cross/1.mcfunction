execute unless score dimension aihunter_dummy matches 2 run scoreboard players set dimension aihunter_dummy 1


#assume on the tick that player travel through dimension, area in the previous dimension is still loaded.

execute unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn] run function kyleong:aihunter/dimension/aec

#execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn,limit=1,sort=nearest] run function kyleong:aihunter/dimension/cross/hunter

#execute unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn] positioned ~ ~6 ~ run function kyleong:aihunter/dimension/cross/hunter

execute positioned ~ ~6 ~ run function kyleong:aihunter/dimension/cross/hunter
