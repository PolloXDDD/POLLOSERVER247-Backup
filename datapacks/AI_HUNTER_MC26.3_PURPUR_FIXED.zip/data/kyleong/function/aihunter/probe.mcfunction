# AI Hunter 26.3 installation probe
tellraw @s [{"text":"[AI Hunter 26.3] ","color":"aqua","bold":true},{"text":"FUNCTION REGISTRY OK — this ZIP is the one currently loaded.","color":"green"}]
