execute if block ~ ~ ~ #kyleong:aihunter/liquid_replaceable run setblock ~ ~ ~ water[level=8] destroy

execute unless block ~ ~ ~ #kyleong:aihunter/liquid_replaceable run setblock ~ ~1 ~ water[level=8] keep

playsound minecraft:item.bucket.empty master @a ~ ~ ~


#debug reporting

execute if score debug aihunter_dummy matches 1 run say mlg: executed (water)
