execute if score @s aihunter_upgrade matches ..0 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand
execute if score @s aihunter_upgrade matches ..0 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 1 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:wooden_sword","count":1}
execute if score @s aihunter_upgrade matches 1 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 2 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:stone_sword","count":1}
execute if score @s aihunter_upgrade matches 2 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 3 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:iron_sword","count":1}
execute if score @s aihunter_upgrade matches 3 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 4 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:diamond_sword","count":1}
execute if score @s aihunter_upgrade matches 4 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 5 run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:diamond_sword","count":1}
execute if score @s aihunter_upgrade matches 5 run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 6.. run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:netherite_sword","count":1}
execute if score @s aihunter_upgrade matches 6.. run data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand


execute if score @s aihunter_upgrade matches ..0 run data remove entity @s equipment.mainhand
execute if score @s aihunter_upgrade matches ..0 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 1 run data modify entity @s equipment.mainhand set value {"id":"minecraft:wooden_sword","count":1}
execute if score @s aihunter_upgrade matches 1 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 2 run data modify entity @s equipment.mainhand set value {"id":"minecraft:stone_sword","count":1}
execute if score @s aihunter_upgrade matches 2 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 3 run data modify entity @s equipment.mainhand set value {"id":"minecraft:iron_sword","count":1}
execute if score @s aihunter_upgrade matches 3 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 4 run data modify entity @s equipment.mainhand set value {"id":"minecraft:diamond_sword","count":1}
execute if score @s aihunter_upgrade matches 4 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 5 run data modify entity @s equipment.mainhand set value {"id":"minecraft:diamond_sword","count":1}
execute if score @s aihunter_upgrade matches 5 run data remove entity @s equipment.offhand

execute if score @s aihunter_upgrade matches 6.. run data modify entity @s equipment.mainhand set value {"id":"minecraft:netherite_sword","count":1}
execute if score @s aihunter_upgrade matches 6.. run data remove entity @s equipment.offhand


scoreboard players set @s aihunter_weapon 1
