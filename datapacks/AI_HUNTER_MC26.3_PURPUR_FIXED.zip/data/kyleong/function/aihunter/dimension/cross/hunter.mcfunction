#function kyleong:aihunter/reset

execute if score debug aihunter_dummy matches 1 run say hunter cross


#set active timer (count down in aihunter/6t

execute if score activetime aihunter_dummy matches 1.. run function kyleong:aihunter/dimension/cross/preactive

execute unless score activetime aihunter_dummy matches 1.. unless score crosstime aihunter_dummy matches 0 run function kyleong:aihunter/dimension/cross/custom

execute unless score activetime aihunter_dummy matches 1.. if score crosstime aihunter_dummy matches 0 run function kyleong:aihunter/dimension/cross/calculate


#other things

scoreboard players set #checkcd aihunter_dummy 20

execute as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate] run function kyleong:aihunter/simulation/cdp

bossbar set minecraft:aihunter_timer players @a

execute run fill ~2 ~2 ~2 ~-2 ~ ~-2 minecraft:air replace

execute if score dimension aihunter_dummy matches 2 run fill ~2 ~-1 ~2 ~-2 ~-1 ~-2 minecraft:obsidian replace

tp @e[type=#kyleong:aihunter/hunter,tag=aihunter] ~ ~ ~

execute unless score dimension aihunter_dummy matches 2 at @e[type=minecraft:area_effect_cloud,tag=aihunter_overworld_portal,limit=1] positioned ~ ~-2 ~ run function kyleong:aihunter/action/build/bed

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:blindness 999999 99 true

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:weakness 999999 20 true

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:resistance 999999 4 true


#spreadplayers ~ ~ 1 4 false @e[type=minecraft:vindicator,tag=aihunter]
#execute unless score dimension aihunter_dummy matches 1 run spreadplayers ~ ~ 1 4 false @e[type=minecraft:vindicator,tag=aihunter]
#execute if score dimension aihunter_dummy matches 1 run spreadplayers ~ ~ 1 4 under 100 false @e[type=minecraft:vindicator,tag=aihunter]
