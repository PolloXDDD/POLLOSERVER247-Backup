
scoreboard players add failcondition aihunter_dummy 1

execute unless score failcondition aihunter_dummy matches 0..2 run scoreboard players set failcondition aihunter_dummy 0

function kyleong:aihunter/settings/menu/1



