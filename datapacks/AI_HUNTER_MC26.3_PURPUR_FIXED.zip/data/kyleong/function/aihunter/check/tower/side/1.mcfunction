#positioned ~ ~ ~-0.3

scoreboard players add @s aihunter_tower 1

execute if block ~1 ~-0.5 ~-0.5 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~1 ~-1.5 ~-0.5 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~1 ~-2.5 ~-0.5 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~ ~-0.5 ~-1.2 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~ ~-1.5 ~-1.2 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~ ~-2.5 ~-1.2 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1


execute if block ~-1 ~-0.5 ~-0.5 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-1 ~-1.5 ~-0.5 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1

execute if block ~-1 ~-2.5 ~-0.5 #kyleong:aihunter/passable run scoreboard players add @s aihunter_tower 1
