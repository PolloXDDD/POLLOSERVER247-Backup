
execute positioned ~ ~ ~-0.3 unless block ~ ~-0.5 ~ #kyleong:aihunter/passable unless block ~ ~-1.5 ~ #kyleong:aihunter/passable unless block ~ ~-2.5 ~ #kyleong:aihunter/passable run function kyleong:aihunter/check/tower/side/1

execute positioned ~-0.3 ~ ~ unless block ~ ~-0.5 ~ #kyleong:aihunter/passable unless block ~ ~-1.5 ~ #kyleong:aihunter/passable unless block ~ ~-2.5 ~ #kyleong:aihunter/passable run function kyleong:aihunter/check/tower/side/2

execute positioned ~ ~ ~0.3 unless block ~ ~-0.5 ~ #kyleong:aihunter/passable unless block ~ ~-1.5 ~ #kyleong:aihunter/passable unless block ~ ~-2.5 ~ #kyleong:aihunter/passable run function kyleong:aihunter/check/tower/side/3

execute positioned ~0.3 ~ ~ unless block ~ ~-0.5 ~ #kyleong:aihunter/passable unless block ~ ~-1.5 ~ #kyleong:aihunter/passable unless block ~ ~-2.5 ~ #kyleong:aihunter/passable run function kyleong:aihunter/check/tower/side/4


execute unless score @s aihunter_tower matches 7.. run function kyleong:aihunter/check/tower/corner
