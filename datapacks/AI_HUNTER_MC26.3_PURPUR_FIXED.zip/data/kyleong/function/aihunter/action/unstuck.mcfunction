tp @s ^ ^ ^3

scoreboard players add usedstuck aihunter_dummy 1

scoreboard players set @s aihunter_stuck 0

execute if score debug aihunter_dummy matches 1 run say unstuck
