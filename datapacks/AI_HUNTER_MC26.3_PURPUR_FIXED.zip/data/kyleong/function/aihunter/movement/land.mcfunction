function kyleong:aihunter/find/vector/2d

execute unless predicate kyleong:aihunter/slowed run function kyleong:aihunter/movement/land/run

execute if predicate kyleong:aihunter/slowed run function kyleong:aihunter/movement/land/couch
