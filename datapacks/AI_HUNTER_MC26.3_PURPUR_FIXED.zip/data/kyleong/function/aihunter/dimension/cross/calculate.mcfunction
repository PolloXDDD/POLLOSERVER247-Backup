#take the highest aihunter_d

scoreboard players set activetime aihunter_dummy 0

scoreboard players operation activetime aihunter_dummy > @e[type=!minecraft:player,scores={aihunter_d=0..}] aihunter_d


#calculate time would have taken to the portal. t=d/v, player sprint jumping is 7.127 m/s, normal sprinting is 5.612 m/s (minecraft wiki). Take average ~= 6.4 m/s, normalise aihunter_d by /0.1 = 64

scoreboard players operation activetime aihunter_dummy /= #64 aihunter_dummy

execute if score activetime aihunter_dummy matches 601.. run scoreboard players set activetime aihunter_dummy 600

execute unless score activetime aihunter_dummy matches 5.. run scoreboard players set activetime aihunter_dummy 5


#notify

function kyleong:aihunter/message/cross


#convert to ticks by *20

execute store result bossbar minecraft:aihunter_timer max run scoreboard players operation activetime aihunter_dummy *= #20 aihunter_dummy
