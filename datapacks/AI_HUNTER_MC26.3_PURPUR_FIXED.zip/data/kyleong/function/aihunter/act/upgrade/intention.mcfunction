##^aihunter/act/hp
##as at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)

execute if score @s aihunter_intent matches 0 if score @s aihunter_uptimer matches 1.. if score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches 80.. unless entity @p[distance=..7,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent 1

execute if score @s aihunter_intent matches 1 if score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches ..79 if entity @p[distance=..15,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent 0

execute if score @s aihunter_intent matches 1 run function kyleong:aihunter/act/upgrade/assign

execute if score @s aihunter_intent matches 2 run function kyleong:aihunter/act/upgrade/prepare
