playsound minecraft:ui.button.click master @s ~ ~ ~ .1
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""

tellraw @s {"text":"----------------------------------------","color":"white","bold":true}


execute if score quality aihunter_dummy matches 0 run tellraw @s [{"text":"Animation Quality: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Hunters' animation quality. Although small, it may affects game performance.","color":"white"}]}},{"text":"<No Animation>","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/quality"}}]

execute if score quality aihunter_dummy matches 1 run tellraw @s [{"text":"Animation Quality: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Hunters' animation quality. Although small, it may affects game performance.","color":"white"}]}},{"text":"<Standard>","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/quality"}}]

execute if score quality aihunter_dummy matches 2 run tellraw @s [{"text":"Animation Quality: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Hunters' animation quality. Although small, it may affects game performance.","color":"white"}]}},{"text":"<Smooth>","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/quality"}}]


tellraw @s ""

tellraw @s [{"text":"Hunter's Appearance:  ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Visual only, won't affect any of hunters' stats.","color":"white"}]}},{"text":"<Customize>","color":"light_purple","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/custom/check"}},{"text":"    ","underlined":false},{"text":"<Reset>","color":"light_purple","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/custom/reset"}}]


tellraw @s ""
execute unless score falldamage aihunter_dummy matches 1 run tellraw @s [{"text":"If Hunters Immune To Fall Damage: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"If 'Disabled', hunters will try to MLG to avoid fall damage after level 1 upgrade. Hunters may 'fail' their MLG, which chance depends on challenge difficulty. If 'Enabled', hunters will be completely immune to fall damage and won't MLG.","color":"white"}]}},{"text":"<Disabled>","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/falldamage"}}]

execute if score falldamage aihunter_dummy matches 1 run tellraw @s [{"text":"If Hunters Immune To Fall Damage: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"If 'Disabled', hunters will try to MLG to avoid fall damage after level 1 upgrade. Hunters may 'fail' their MLG, which chance depends on challenge difficulty. If 'Enabled', hunters will be completely immune to fall damage and won't MLG.","color":"white"}]}},{"text":"<Enabled>","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/falldamage"}}]


tellraw @s ""
execute if score crosstime aihunter_dummy matches 1.. if score crosstime_m aihunter_dummy matches 10.. if score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" "},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins "},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]

execute if score crosstime aihunter_dummy matches 1.. if score crosstime_m aihunter_dummy matches 10.. unless score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" "},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins 0"},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]

execute if score crosstime aihunter_dummy matches 1.. unless score crosstime_m aihunter_dummy matches 10.. if score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" 0"},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins "},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]

execute if score crosstime aihunter_dummy matches 1.. unless score crosstime_m aihunter_dummy matches 10.. unless score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" 0"},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins 0"},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]

execute if score crosstime aihunter_dummy matches 0 run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" By Distance ","color":"white"},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]

execute unless score crosstime aihunter_dummy matches 0.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" Move Active ","color":"white"},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/crosstime/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]


tellraw @s ""
execute unless score initialupgrade aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Initial Equipment Level: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Level of equipment hunters will have upon spawning & respawning. ","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/initialupgrade/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" "},{"text":"0","color":"gray"},{"text":" "},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/initialupgrade/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]

execute if score initialupgrade aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Initial Equipment Level: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"Level of equipment hunters will have upon spawning & respawning. ","color":"white"}]}},{"text":"<->","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/initialupgrade/remove"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}},{"text":" "},{"score":{"name":"initialupgrade","objective":"aihunter_dummy"},"color":"white"},{"text":" "},{"text":"<+>  ","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/initialupgrade/add"},"hover_event":{"action":"show_text","value":[{"text":"","color":"white"}]}}]


tellraw @s ""
execute unless score canupgrade aihunter_dummy matches 1 run tellraw @s [{"text":"Do Hunters Upgrade Equipment: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"As stated. But hunters in terminator mode won't upgrade no matter what is set.","color":"white"}]}},{"text":"<Disabled>","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/canupgrade"}}]

execute if score canupgrade aihunter_dummy matches 1 run tellraw @s [{"text":"Do Hunters Upgrade Equipment: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"As stated. But hunters in terminator mode won't upgrade no matter what is set.","color":"white"}]}},{"text":"<Enabled>","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/canupgrade"}}]


tellraw @s ""
execute if score notifyupgrade aihunter_dummy matches 0 run tellraw @s [{"text":"Notify When Hunters Upgrade Equipment: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"As stated.","color":"white"}]}},{"text":"<Disabled>","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/notifyupgrade"}}]

execute if score notifyupgrade aihunter_dummy matches 1 run tellraw @s [{"text":"Notify When Hunters Upgrade Equipment: ","color":"white","hover_event":{"action":"show_text","value":[{"text":"As stated.","color":"white"}]}},{"text":"<Enabled>","color":"green","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/notifyupgrade"}}]

#


tellraw @s ""
tellraw @s [{"text":"(Page 2 of 2)     ","color":"white"},{"text":"<Next Page>","color":"green","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/menu/1"},"hover_event":{"action":"show_text","value":[{"text":"Go to the next page of settings menu.","color":"green"}]}},{"text":"     ","underlined":false},{"text":"<Start Menu>","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/menu"},"hover_event":{"action":"show_text","value":[{"text":"Go back to the main menu.","color":"aqua"}]}}]


tellraw @s {"text":"----------------------------------------","color":"white","bold":true}
