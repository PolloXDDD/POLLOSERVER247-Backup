#MC1.20 added fences

execute if block ~ ~ ~ minecraft:bamboo_fence[waterlogged=false] run setblock ~ ~ ~ minecraft:bamboo_fence[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:cherry_fence[waterlogged=false] run setblock ~ ~ ~ minecraft:cherry_fence[waterlogged=true] replace
