#cannot be put in one because version complications 

execute unless score version aihunter_dummy matches 117.. run function kyleong:aihunter/find/action/move/116

execute if score version aihunter_dummy matches 117..118 run function kyleong:aihunter/find/action/move/117

execute if score version aihunter_dummy matches 119 run function kyleong:aihunter/find/action/move/119

execute if score version aihunter_dummy matches 120 run function kyleong:aihunter/find/action/move/120
