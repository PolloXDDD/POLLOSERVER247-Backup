execute if score dimension aihunter_dummy matches 2 run function kyleong:aihunter/summon/clear

function kyleong:aihunter/summon/attacker

execute as @e[type=minecraft:vindicator,tag=aihunter,predicate=kyleong:aihunter/fresh] run function kyleong:aihunter/summon/set

title @a actionbar {"text":" A Hunter has fallen","color":"yellow"}

execute if score debug aihunter_dummy matches 1 run say respawn
