#scoreboard players set activetime aihunter_dummy -999

schedule clear kyleong:aihunter/check/movestart/loop

schedule clear kyleong:aihunter/check/movestart/start

bossbar set minecraft:aihunter_timer players 0

bossbar set minecraft:aihunter_ms players 0

#bossbar set minecraft:aihunter_timer1 players 0
