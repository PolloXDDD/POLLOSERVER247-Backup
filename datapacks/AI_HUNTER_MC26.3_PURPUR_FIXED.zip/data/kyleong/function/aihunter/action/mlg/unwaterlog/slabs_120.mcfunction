#MC1.120 added slabs (bamboo's, cherry)
#TOP

execute if block ~ ~ ~ minecraft:bamboo_mosaic_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:bamboo_mosaic_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:bamboo_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:bamboo_slab[waterlogged=false,type=top] replace

execute if block ~ ~ ~ minecraft:cherry_slab[waterlogged=true,type=top] run setblock ~ ~ ~ minecraft:cherry_slab[waterlogged=false,type=top] replace


#BOTTOM

execute if block ~ ~ ~ minecraft:bamboo_mosaic_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:bamboo_mosaic_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:bamboo_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:bamboo_slab[waterlogged=false,type=bottom] replace

execute if block ~ ~ ~ minecraft:cherry_slab[waterlogged=true,type=bottom] run setblock ~ ~ ~ minecraft:cherry_slab[waterlogged=false,type=bottom] replace
