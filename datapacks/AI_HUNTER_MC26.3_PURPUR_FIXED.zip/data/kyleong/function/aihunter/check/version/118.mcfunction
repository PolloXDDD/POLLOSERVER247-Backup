give @s[scores={ImpossibleImpossibleImpossible=-123}] minecraft:music_disc_otherside

scoreboard players set version aihunter_dummy 118
