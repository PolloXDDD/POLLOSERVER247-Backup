
execute if score started aihunter_dummy matches 0 run scoreboard players remove survivetime aihunter_dummy 10

execute unless score survivetime aihunter_dummy matches 10..120 run scoreboard players set survivetime aihunter_dummy 120


scoreboard players operation survivetime_m aihunter_dummy = survivetime aihunter_dummy

scoreboard players operation survivetime_h aihunter_dummy = survivetime aihunter_dummy

scoreboard players operation survivetime_m aihunter_dummy %= #60 aihunter_dummy

scoreboard players operation survivetime_h aihunter_dummy /= #60 aihunter_dummy


execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/settings/menu/1


execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
