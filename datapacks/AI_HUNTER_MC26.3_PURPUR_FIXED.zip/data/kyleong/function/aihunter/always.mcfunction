#active dimension:

execute if score dimension aihunter_dummy matches 0 run function kyleong:aihunter/dimension/overworld

execute if score dimension aihunter_dummy matches 1 run function kyleong:aihunter/dimension/nether

execute if score dimension aihunter_dummy matches 2 run function kyleong:aihunter/dimension/end


#survive timer count down

execute if score wincondition aihunter_dummy matches 6 run function kyleong:aihunter/survivetimer


#after player's death

execute as @a[scores={aihunter_death=1..}] run function kyleong:aihunter/death


#control the duration of placed water

scoreboard players remove @e[type=minecraft:area_effect_cloud,tag=aihunter_fading] aihunter_hp 1

execute as @e[type=minecraft:area_effect_cloud,tag=aihunter_water,scores={aihunter_hp=..-12}] at @s run function kyleong:aihunter/action/unwater

execute as @e[type=minecraft:area_effect_cloud,tag=aihunter_waterlog,scores={aihunter_hp=..-4}] at @s run function kyleong:aihunter/action/mlg/unwaterlog


#others

execute if score #turn aihunter_dummy matches 6.. run scoreboard players set #turn aihunter_dummy 0

scoreboard players add #turn aihunter_dummy 1

execute as @e[type=minecraft:vindicator,tag=aihunter] at @s run function kyleong:aihunter/attacker

tag @e[type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] remove aihunter_tped

execute if score #turn aihunter_dummy matches 6 run function kyleong:aihunter/6t

execute as @e[type=minecraft:arrow,tag=aihunter_arrow] run function kyleong:aihunter/animation/arrow
