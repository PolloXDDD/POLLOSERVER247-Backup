##^aihunter/survivetimer
##as at server
#actionbar  timer calculation

scoreboard players operation #temporary aihunter_dummy = timer1 aihunter_dummy

scoreboard players operation ticks aihunter_dummy = timer1 aihunter_dummy


scoreboard players operation ticks aihunter_dummy %= #20 aihunter_dummy

scoreboard players operation #temporary aihunter_dummy /= #20 aihunter_dummy

scoreboard players operation seconds aihunter_dummy = #temporary aihunter_dummy


scoreboard players operation seconds aihunter_dummy %= #60 aihunter_dummy

scoreboard players operation #temporary aihunter_dummy /= #60 aihunter_dummy

scoreboard players operation minutes aihunter_dummy = #temporary aihunter_dummy


scoreboard players operation minutes aihunter_dummy %= #60 aihunter_dummy

scoreboard players operation #temporary aihunter_dummy /= #60 aihunter_dummy

scoreboard players operation hours aihunter_dummy = #temporary aihunter_dummy
