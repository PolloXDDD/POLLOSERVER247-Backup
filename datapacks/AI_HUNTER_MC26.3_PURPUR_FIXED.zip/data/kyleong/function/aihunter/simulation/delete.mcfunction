##as at @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate_complete]

kill @s

scoreboard players remove simulation aihunter_dummy 1

execute if score debug aihunter_dummy matches 1 run say simulation:deleted
