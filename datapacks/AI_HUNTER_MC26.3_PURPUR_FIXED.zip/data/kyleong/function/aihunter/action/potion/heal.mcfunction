
scoreboard players add @s aihunter_busy 1
scoreboard players set @s aihunter_weapon 0

scoreboard players remove @s aihunter_potion 1

data modify entity @s equipment.mainhand set value {"id":"minecraft:splash_potion","count":1,"components":{"minecraft:potion_contents":{"potion":"minecraft:strong_healing"}}}
data remove entity @s equipment.offhand

data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.mainhand set value {"id":"minecraft:splash_potion","count":1,"components":{"minecraft:potion_contents":{"potion":"minecraft:strong_healing"}}}
data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.offhand

playsound minecraft:entity.splash_potion.throw master @a ~ ~ ~ .8 .5

summon minecraft:splash_potion ~ ~ ~ {"Item":{"id":"minecraft:splash_potion","count":1,"components":{"minecraft:potion_contents":{"custom_color":16711680},"minecraft:enchantment_glint_override":true}}}

effect give @s minecraft:instant_health 1 1 true
