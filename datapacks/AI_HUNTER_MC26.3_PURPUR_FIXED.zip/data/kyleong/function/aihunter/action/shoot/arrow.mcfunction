summon minecraft:arrow ~ ~1.6 ~ {"Tags":["aihunter_arrow","aihunter_arrow_fresh"],"pickup":1,"ShotFromCrossbow":1}

data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.mainhand set value {"id":"minecraft:crossbow","count":1}
data remove entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] equipment.offhand

execute if score @s aihunter_upgrade matches 6.. run data modify entity @s equipment.mainhand set value {"id":"minecraft:crossbow","count":1}
execute if score @s aihunter_upgrade matches 6.. run data remove entity @s equipment.offhand


scoreboard players set @s aihunter_weapon 0

scoreboard players remove @s aihunter_arrow 1

execute unless score @s aihunter_arrow matches ..-6 run scoreboard players add @s aihunter_busy 6

execute unless score @s aihunter_arrow matches ..-6 run effect give @s minecraft:saturation 2 31 true

execute unless score @s aihunter_arrow matches ..-6 run effect give @s minecraft:weakness 2 10 true


function kyleong:aihunter/find/vector/3d

execute as @e[limit=1,sort=nearest,type=minecraft:arrow,tag=aihunter_arrow_fresh] run function kyleong:aihunter/action/shoot/arrow1


playsound minecraft:item.crossbow.shoot master @a ~ ~ ~

execute unless score @s aihunter_arrow matches ..-6 run playsound minecraft:item.crossbow.loading_start master @a ~ ~ ~

execute unless score @s aihunter_arrow matches ..-6 run playsound minecraft:item.crossbow.loading_middle master @a ~ ~ ~
