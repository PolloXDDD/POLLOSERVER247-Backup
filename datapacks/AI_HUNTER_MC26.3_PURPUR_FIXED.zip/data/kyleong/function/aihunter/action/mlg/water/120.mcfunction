##120 block tags
##at the nearest, vertically non-passable block
##all blocks between hunter and this block, is passable

#break instant mine-able blocks(only upper 2 blocks)

execute if block ~ ~1 ~ #kyleong:aihunter/instant_break_120 run setblock ~ ~1 ~ air destroy

execute if block ~ ~2 ~ #kyleong:aihunter/instant_break_120 run setblock ~ ~2 ~ air destroy


#located block is not waterlogable & block above (passable) is not water waterlogable

execute unless block ~ ~1 ~ #kyleong:aihunter/waterlogable_120 unless block ~ ~ ~ #kyleong:aihunter/waterlogable_120 positioned ~ ~1 ~ run function kyleong:aihunter/action/mlg/water1


#block above (passable) is water waterlogable

execute if block ~ ~1 ~ #kyleong:aihunter/waterlogable_120 positioned ~ ~1 ~ run function kyleong:aihunter/action/mlg/waterlog


#located block is waterlogable & block above (passable) is not water waterlogable

execute unless block ~ ~1 ~ #kyleong:aihunter/waterlogable_120 if block ~ ~ ~ #kyleong:aihunter/waterlogable_120 run function kyleong:aihunter/action/mlg/waterlog
