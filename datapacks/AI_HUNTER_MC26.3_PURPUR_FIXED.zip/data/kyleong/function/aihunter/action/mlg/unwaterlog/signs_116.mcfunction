##MC1.16 wall signs
#1

execute if block ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:birch_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:birch_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:oak_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:oak_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:warped_wall_sign[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:warped_wall_sign[waterlogged=false,facing=east] replace


#2

execute if block ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:birch_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:birch_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:oak_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:oak_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:warped_wall_sign[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:warped_wall_sign[waterlogged=false,facing=north] replace


#3

execute if block ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:birch_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:birch_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:oak_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:oak_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:warped_wall_sign[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:warped_wall_sign[waterlogged=false,facing=south] replace


#4

execute if block ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:acacia_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:birch_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:birch_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:crimson_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:dark_oak_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:jungle_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:oak_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:oak_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:spruce_wall_sign[waterlogged=false,facing=west] replace

execute if block ~ ~ ~ minecraft:warped_wall_sign[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:warped_wall_sign[waterlogged=false,facing=west] replace


##MC1.16 signs
#0

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=0] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=0] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=0] replace


#1

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=1] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=1] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=1] replace


#2

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=2] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=2] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=2] replace


#3

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=3] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=3] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=3] replace


#4

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=4] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=4] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=4] replace


#5

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=5] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=5] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=5] replace


#6

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=6] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=6] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=6] replace


#7

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=7] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=7] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=7] replace


#8

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=8] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=8] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=8] replace


#9

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=9] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=9] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=9] replace


#10

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=10] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=10] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=10] replace


#11

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=11] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=11] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=11] replace


#12

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=12] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=12] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=12] replace


#13

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=13] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=13] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=13] replace


#14

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=14] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=14] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=14] replace


#15

execute if block ~ ~ ~ minecraft:acacia_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:acacia_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:birch_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:birch_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:crimson_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:crimson_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:dark_oak_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:dark_oak_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:jungle_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:jungle_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:oak_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:oak_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:spruce_sign[waterlogged=false,rotation=15] replace

execute if block ~ ~ ~ minecraft:warped_sign[waterlogged=true,rotation=15] run setblock ~ ~ ~ minecraft:warped_sign[waterlogged=false,rotation=15] replace
