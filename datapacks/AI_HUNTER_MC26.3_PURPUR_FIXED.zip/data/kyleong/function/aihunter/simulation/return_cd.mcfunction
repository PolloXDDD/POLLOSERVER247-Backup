##as at @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate_complete]

function kyleong:aihunter/summon/return/hunter

execute store result entity @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] Health float 0.1 run scoreboard players get @s aihunter_hp

execute store result entity @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] active_effects[{id:"minecraft:blindness"}].duration int 1 run scoreboard players get @s aihunter_busy


scoreboard players operation @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_intent = @s aihunter_intent

scoreboard players operation @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_upgrade = @s aihunter_upgrade

execute if score @s aihunter_uptimer matches -2147483648..214748364 run scoreboard players operation @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest] aihunter_uptimer = @s aihunter_uptimer


#set, need to be after transferring upgrade score

execute as @e[type=#kyleong:aihunter/hunter,tag=aihunter] at @s run function kyleong:aihunter/summon/return/set

#execute unless score dimension aihunter_dummy matches 1 run spreadplayers ~ ~ 0 1 true @e[type=#kyleong:aihunter/hunter,tag=aihunter,distance=..1]

#execute if score dimension aihunter_dummy matches 1 run spreadplayers ~ ~ 0 1 under 100 true @e[type=#kyleong:aihunter/hunter,tag=aihunter,distance=..1]

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:blindness 999999 99 true

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:weakness 999999 20 true

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:resistance 999999 4 true


#finishing

kill @s

scoreboard players remove simulation aihunter_dummy 1

execute if score debug aihunter_dummy matches 1 run say simulation:return_cd
