#MC1.16 walls

execute if block ~ ~ ~ minecraft:andesite_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:andesite_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:blackstone_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:blackstone_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:brick_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:cobblestone_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:cobblestone_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:diorite_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:diorite_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:end_stone_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:end_stone_brick_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:granite_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:granite_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:mossy_cobblestone_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:mossy_cobblestone_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:mossy_stone_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:mossy_stone_brick_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:nether_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:nether_brick_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:polished_blackstone_brick_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:polished_blackstone_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:polished_blackstone_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:prismarine_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:prismarine_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:red_nether_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:red_nether_brick_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:red_sandstone_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:red_sandstone_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:sandstone_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:sandstone_wall[waterlogged=true] replace

execute if block ~ ~ ~ minecraft:stone_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:stone_brick_wall[waterlogged=true] replace
