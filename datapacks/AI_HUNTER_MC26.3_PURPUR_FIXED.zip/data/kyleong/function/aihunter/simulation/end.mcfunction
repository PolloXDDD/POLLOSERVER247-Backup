##as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,tag=!aihunter_register] at server

tag @s remove aihunter_simulate

tag @s add aihunter_simulate_complete

execute store result entity @s Pos[0] double 0.1 run scoreboard players get @s aihunter_x1

execute store result entity @s Pos[2] double 0.1 run scoreboard players get @s aihunter_z1
