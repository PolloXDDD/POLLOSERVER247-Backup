execute if score @s aihunter_upgrade matches 1 if score wdiff aihunter_dummy matches 1 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set 3

execute if score @s aihunter_upgrade matches 1 if score wdiff aihunter_dummy matches 3 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set -0.33

execute if score @s aihunter_upgrade matches 2 if score wdiff aihunter_dummy matches 1 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set 4

execute if score @s aihunter_upgrade matches 2 if score wdiff aihunter_dummy matches 3 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set -0.66

execute if score @s aihunter_upgrade matches 3 if score wdiff aihunter_dummy matches 1 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set 5

execute if score @s aihunter_upgrade matches 3 if score wdiff aihunter_dummy matches 3 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set -1

execute if score @s aihunter_upgrade matches 4 if score wdiff aihunter_dummy matches 1 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set 6

execute if score @s aihunter_upgrade matches 4 if score wdiff aihunter_dummy matches 3 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set -1.33

execute if score @s aihunter_upgrade matches 5 if score wdiff aihunter_dummy matches 1 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set 6

execute if score @s aihunter_upgrade matches 5 if score wdiff aihunter_dummy matches 3 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set -1.33

execute if score @s aihunter_upgrade matches 6.. if score wdiff aihunter_dummy matches 1 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set 7

execute if score @s aihunter_upgrade matches 6.. if score wdiff aihunter_dummy matches 3 run attribute @s[type=minecraft:vindicator] minecraft:attack_damage base set -1.66
