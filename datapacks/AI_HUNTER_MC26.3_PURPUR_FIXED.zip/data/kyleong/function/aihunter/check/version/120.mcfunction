execute if block ~ ~ ~ minecraft:cherry_button

scoreboard players set version aihunter_dummy 120
