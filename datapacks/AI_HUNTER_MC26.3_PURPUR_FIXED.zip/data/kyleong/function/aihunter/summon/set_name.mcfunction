data modify entity @s CustomName set from storage minecraft:aihunter_custom name

execute if score showhp aihunter_dummy matches 1 in minecraft:the_end run function kyleong:aihunter/summon/set_hpbar
