kill @e[type=minecraft:experience_orb,nbt={Age:0}]
