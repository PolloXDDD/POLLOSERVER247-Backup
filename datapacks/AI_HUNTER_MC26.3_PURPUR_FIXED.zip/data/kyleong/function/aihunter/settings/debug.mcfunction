
scoreboard players add debug aihunter_dummy 1

execute unless score debug aihunter_dummy matches 1..2 run scoreboard players set debug aihunter_dummy 0

execute if score debug aihunter_dummy matches 1 run gamerule minecraft:send_command_feedback true

execute if score debug aihunter_dummy matches 0 run gamerule minecraft:send_command_feedback false

function kyleong:aihunter/debug/effect

execute if score debug aihunter_dummy matches 1 run title @s actionbar {"text":"debug on (1)","color":"dark_purple"}

execute if score debug aihunter_dummy matches 2 run title @s actionbar {"text":"debug on (2)","color":"dark_purple"}

execute if score debug aihunter_dummy matches 0 run title @s actionbar {"text":"debug off","color":"dark_purple"}
