##as at @e[type=minecraft:vindicator,tag=aihunter]
#set

scoreboard players set @s aihunter_upgrade 6

attribute @s minecraft:armor base set 20

attribute @s minecraft:armor_toughness base set 12

data modify entity @s equipment.mainhand set value {"id":"minecraft:netherite_sword","count":1,"components":{"minecraft:unbreakable":{}}}
data remove entity @s equipment.offhand

execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.feet set value {"id":"minecraft:netherite_boots","count":1}
execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.legs set value {"id":"minecraft:netherite_leggings","count":1}
execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.chest set value {"id":"minecraft:netherite_chestplate","count":1}
execute unless data storage minecraft:aihunter_custom armor run data modify entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] equipment.head set value {"id":"minecraft:skeleton_skull","count":1}


#message

execute if score notifyupgrade aihunter_dummy matches 1.. run function kyleong:aihunter/message/upgrade
