scoreboard players set @s aihunter_walk 0

scoreboard players set @s aihunter_sprint 0

scoreboard players set @s aihunter_crouch 0

scoreboard players set @s aihunter_swim 0

scoreboard players set @s aihunter_owwalk 0

scoreboard players set @s aihunter_uwwalk 0

scoreboard players set @s aihunter_pearl 0

team modify aihunter collisionRule never
