#as, at player

scoreboard players set @s aihunter_tower 0

execute unless predicate kyleong:aihunter/onground unless block ~ ~-0.5 ~ #kyleong:aihunter/passable unless block ~ ~-1.5 ~ #kyleong:aihunter/passable unless block ~ ~-2.5 ~ #kyleong:aihunter/passable run function kyleong:aihunter/check/tower/centre

execute unless predicate kyleong:aihunter/onground if block ~ ~-0.5 ~ #kyleong:aihunter/passable if block ~ ~-1.5 ~ #kyleong:aihunter/passable if block ~ ~-2.5 ~ #kyleong:aihunter/passable rotated ~ 0 run function kyleong:aihunter/check/tower/edge


execute if entity @s[x_rotation=51..90,scores={aihunter_tower=7..}] run scoreboard players set @s aihunter_tower -33
