#MC1.17-1.20 added trapdoors
#1111

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=top,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=top,open=true,powered=true] replace


#1112

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=top,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=top,open=true,powered=false] replace


#1121

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=top,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=top,open=false,powered=true] replace


#1211

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=bottom,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=bottom,open=true,powered=true] replace


#1221

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=bottom,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=bottom,open=false,powered=true] replace


#1222

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=bottom,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=bottom,open=false,powered=false] replace


#1122

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=top,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=top,open=false,powered=false] replace


#1212

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=east,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=east,half=bottom,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=east,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=east,half=bottom,open=true,powered=false] replace


#2111

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=top,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=top,open=true,powered=true] replace


#2112

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=top,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=top,open=true,powered=false] replace


#2121

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=top,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=top,open=false,powered=true] replace


#2211

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=bottom,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=bottom,open=true,powered=true] replace


#2221

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=bottom,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=bottom,open=false,powered=true] replace


#2222

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=bottom,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=bottom,open=false,powered=false] replace


#2122

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=top,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=top,open=false,powered=false] replace


#2212

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=north,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=north,half=bottom,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=north,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=north,half=bottom,open=true,powered=false] replace


#3111

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=top,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=top,open=true,powered=true] replace


#3112

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=top,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=top,open=true,powered=false] replace


#3121

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=top,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=top,open=false,powered=true] replace


#3211

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=bottom,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=bottom,open=true,powered=true] replace


#3221

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=bottom,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=bottom,open=false,powered=true] replace


#3222

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=bottom,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=bottom,open=false,powered=false] replace


#3122

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=top,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=top,open=false,powered=false] replace


#3212

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=south,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=south,half=bottom,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=south,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=south,half=bottom,open=true,powered=false] replace


#4111

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=top,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=top,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=top,open=true,powered=true] replace


#4112

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=top,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=top,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=top,open=true,powered=false] replace


#4121

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=top,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=top,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=top,open=false,powered=true] replace


#4211

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=bottom,open=true,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=bottom,open=true,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=bottom,open=true,powered=true] replace


#4221

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=bottom,open=false,powered=true] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=bottom,open=false,powered=true] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=bottom,open=false,powered=true] replace


#4222

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=bottom,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=bottom,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=bottom,open=false,powered=false] replace


#4122

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=top,open=false,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=top,open=false,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=top,open=false,powered=false] replace


#4212

execute if block ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=true,facing=west,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:bamboo_trapdoor[waterlogged=false,facing=west,half=bottom,open=true,powered=false] replace

execute if block ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=true,facing=west,half=bottom,open=true,powered=false] run setblock ~ ~ ~ minecraft:cherry_trapdoor[waterlogged=false,facing=west,half=bottom,open=true,powered=false] replace
