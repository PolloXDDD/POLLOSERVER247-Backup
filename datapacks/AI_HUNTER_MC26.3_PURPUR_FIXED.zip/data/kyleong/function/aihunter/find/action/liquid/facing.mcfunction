#SWNE

execute if entity @s[y_rotation=-45.1..45] rotated 0 0 run function kyleong:aihunter/find/action/liquid/check

execute if entity @s[y_rotation=45.1..135] rotated 90 0 run function kyleong:aihunter/find/action/liquid/check

execute if entity @s[y_rotation=135.1..225] rotated 180 0 run function kyleong:aihunter/find/action/liquid/check

execute if entity @s[y_rotation=225.1..315] rotated 270 0 run function kyleong:aihunter/find/action/liquid/check
