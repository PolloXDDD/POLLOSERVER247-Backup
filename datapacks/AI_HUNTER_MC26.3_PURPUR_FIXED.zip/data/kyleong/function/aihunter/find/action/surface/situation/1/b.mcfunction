
function kyleong:aihunter/action/build/jump

execute if score debug aihunter_dummy matches 2 run say s1b
