
function kyleong:aihunter/action/move/jump

execute if score debug aihunter_dummy matches 2 run say u1a
