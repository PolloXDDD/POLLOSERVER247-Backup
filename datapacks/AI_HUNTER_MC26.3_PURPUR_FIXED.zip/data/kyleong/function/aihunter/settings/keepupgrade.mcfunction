
scoreboard players add keepupgrade aihunter_dummy 1

execute unless score keepupgrade aihunter_dummy matches 0..1 run scoreboard players set keepupgrade aihunter_dummy 0

function kyleong:aihunter/settings/menu/1



