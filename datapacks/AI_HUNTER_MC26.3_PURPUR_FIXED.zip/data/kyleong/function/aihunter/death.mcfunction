execute if entity @s[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function kyleong:aihunter/death1

execute unless entity @s[gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_death 0
