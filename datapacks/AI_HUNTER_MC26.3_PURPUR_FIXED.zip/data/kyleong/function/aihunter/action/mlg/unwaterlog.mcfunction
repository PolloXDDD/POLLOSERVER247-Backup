##block ~ ~ ~ is waterlogable
#as at @e[type=minecraft:area_effect_cloud,tag=aihunter_waterlog]

function kyleong:aihunter/action/mlg/unwaterlog/glass_panes

function kyleong:aihunter/action/mlg/unwaterlog/chests

function kyleong:aihunter/action/mlg/unwaterlog/slabs_116

function kyleong:aihunter/action/mlg/unwaterlog/slabs_117

function kyleong:aihunter/action/mlg/unwaterlog/slabs_119

function kyleong:aihunter/action/mlg/unwaterlog/slabs_120


function kyleong:aihunter/action/mlg/unwaterlog/stairs_116

function kyleong:aihunter/action/mlg/unwaterlog/stairs_117

function kyleong:aihunter/action/mlg/unwaterlog/stairs_119

function kyleong:aihunter/action/mlg/unwaterlog/stairs_120


function kyleong:aihunter/action/mlg/unwaterlog/fences_116

function kyleong:aihunter/action/mlg/unwaterlog/fences_119

function kyleong:aihunter/action/mlg/unwaterlog/fences_120


function kyleong:aihunter/action/mlg/unwaterlog/trapdoors_116

function kyleong:aihunter/action/mlg/unwaterlog/trapdoors_119

function kyleong:aihunter/action/mlg/unwaterlog/trapdoors_120


execute if block ~ ~ ~ #minecraft:signs[waterlogged=true] run function kyleong:aihunter/action/mlg/unwaterlog/signs


function kyleong:aihunter/action/mlg/unwaterlog/walls_116

function kyleong:aihunter/action/mlg/unwaterlog/walls_117

function kyleong:aihunter/action/mlg/unwaterlog/walls_119


function kyleong:aihunter/action/mlg/unwaterlog/others_117

function kyleong:aihunter/action/mlg/unwaterlog/others_119

function kyleong:aihunter/action/mlg/unwaterlog/others_120


#ladder

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=west] replace


#chain

execute if block ~ ~ ~ minecraft:iron_chain[waterlogged=true,axis=x] run setblock ~ ~ ~ minecraft:iron_chain[waterlogged=false,axis=x] replace

execute if block ~ ~ ~ minecraft:iron_chain[waterlogged=true,axis=y] run setblock ~ ~ ~ minecraft:iron_chain[waterlogged=false,axis=y] replace

execute if block ~ ~ ~ minecraft:iron_chain[waterlogged=true,axis=z] run setblock ~ ~ ~ minecraft:iron_chain[waterlogged=false,axis=z] replace


#campfire

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=east] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=north] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=south] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=west] replace


#others

execute if block ~ ~ ~ minecraft:iron_bars[waterlogged=true] run setblock ~ ~ ~ minecraft:iron_bars[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:conduit[waterlogged=true] run setblock ~ ~ ~ minecraft:conduit[waterlogged=false] replace


#sound

playsound minecraft:item.bucket.fill master @a ~ ~ ~


#debug reporting

execute if score debug aihunter_dummy matches 1 run say unwaterloged

kill @s
