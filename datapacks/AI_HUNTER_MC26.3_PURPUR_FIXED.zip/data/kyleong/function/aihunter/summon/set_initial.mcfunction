##^aihunter/start
##as @e[type=minecraft:vindicator,tag=aihunter]
#initial intention (set to 0 again to apply chance)

scoreboard players set @s aihunter_intent 0

execute unless score difficulty aihunter_dummy matches 4.. if score @s aihunter_upgrade matches ..0 unless predicate kyleong:aihunter/chance/50 run scoreboard players set @s aihunter_intent 1

execute unless score difficulty aihunter_dummy matches 4.. if score @s aihunter_upgrade matches 1 if predicate kyleong:aihunter/chance/20 run scoreboard players set @s aihunter_intent 1


#initial effects

effect give @s minecraft:weakness 999999 90 true

effect give @s minecraft:blindness 999999 99 true

effect give @s minecraft:resistance 999999 5 true
