#MC1.19 added fences

execute if block ~ ~ ~ minecraft:mangrove_fence[waterlogged=false] run setblock ~ ~ ~ minecraft:mangrove_fence[waterlogged=true] replace
