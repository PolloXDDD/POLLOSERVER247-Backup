
schedule function kyleong:aihunter/stop 1t

scoreboard objectives remove hunterx

scoreboard objectives remove huntery

scoreboard objectives remove hunterz

scoreboard objectives remove hunterdx

scoreboard objectives remove diffy

scoreboard objectives remove hunterdz

scoreboard objectives remove preydeath

scoreboard objectives remove aihunter_hp

scoreboard objectives remove playery

scoreboard objectives remove aihunter_posx

scoreboard objectives remove aihunter_posy

scoreboard objectives remove aihunter_posz

scoreboard objectives remove aihunter_pastx

scoreboard objectives remove aihunter_pasty

scoreboard objectives remove aihunter_pastz

scoreboard objectives remove aihunter_stuck

#

scoreboard players reset started aihunter_dummy

scoreboard players reset difficulty aihunter_dummy

scoreboard players reset buff aihunter_dummy

scoreboard players reset dimension aihunter_dummy

scoreboard players reset #animation aihunter_dummy

scoreboard players reset motion aihunter_dummy

scoreboard players reset bossbar aihunter_dummy

scoreboard players reset glow aihunter_dummy

scoreboard players reset quality aihunter_dummy

scoreboard players reset hunters aihunter_dummy

scoreboard objectives remove aihunter_dummy


#

team remove aihunter

execute in minecraft:overworld run forceload remove all

execute in minecraft:the_nether run forceload remove all

execute in minecraft:the_end run forceload remove all

bossbar remove minecraft:aihunter

gamerule minecraft:send_command_feedback true


tellraw @a {"text":"AI Hunter Data Pack is ready to be uninstall, /reload to undo","color":"red"}
