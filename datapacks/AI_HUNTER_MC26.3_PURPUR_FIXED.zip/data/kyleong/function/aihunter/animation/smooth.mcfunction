#as @e[type=minecraft:vindicator,tag=aihunter]

execute unless score @s aihunter_busy matches 1.. unless predicate kyleong:aihunter/slowed run function kyleong:aihunter/animation/head

execute unless predicate kyleong:aihunter/slowed as @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] run function kyleong:aihunter/animation/run

execute if predicate kyleong:aihunter/slowed as @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] run function kyleong:aihunter/animation/couch
