execute if score @s aihunter_d matches ..200 run function kyleong:aihunter/movement/water/swim

execute unless score @s aihunter_d matches ..200 run function kyleong:aihunter/movement/water/boat
