#convert to seconds by /20

scoreboard players operation activetime aihunter_dummy /= #20 aihunter_dummy


#add time if should

execute if score crosstime aihunter_dummy matches 0 run function kyleong:aihunter/dimension/cross/preactive/calculate


#notify

function kyleong:aihunter/message/cross


#convert back to ticks by *20

execute store result bossbar minecraft:aihunter_timer value run scoreboard players operation activetime aihunter_dummy *= #20 aihunter_dummy

execute store result score #temp aihunter_dummy run bossbar get minecraft:aihunter_timer max

execute if score #temp aihunter_dummy < activetime aihunter_dummy store result bossbar minecraft:aihunter_timer max run scoreboard players get activetime aihunter_dummy
