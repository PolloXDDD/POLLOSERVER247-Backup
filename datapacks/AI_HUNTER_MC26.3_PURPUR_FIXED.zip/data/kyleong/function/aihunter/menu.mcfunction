playsound minecraft:ui.button.click master @s ~ ~ ~ .1
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""

tellraw @s {"text":"----------------------------------------","color":"aqua","bold":true}
tellraw @s [{"text":"AI","color":"aqua","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/debug"}},{"text":" Hunter","color":"aqua","click_event":{"action":"run_command","command":"/function kyleong:aihunter/check/status"}},{"text":" Datapack for Minecraft Java 26.3","color":"aqua"}]

tellraw @s ""
tellraw @s {"text":"[v1.8.0] Datapack made by Kyleong","color":"aqua","click_event":{"action":"open_url","url":"https://www.youtube.com/channel/UCGclCRGdWUjJdVcHLZfdaOg"},"hover_event":{"action":"show_text","value":[{"text":"Subscribe to my Youtube channel if you like it! (URL To: youtube.com)","color":"gold"}]}}

tellraw @s ""

execute if score pause aihunter_dummy matches 1 run tellraw @s {"text":"<[Resume]>","color":"green","bold":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/check/resume"},"hover_event":{"action":"show_text","value":[{"text":"Current (paused) challenge will be resumed.","color":"green"}]}}

execute unless score started aihunter_dummy matches 1 run tellraw @s {"text":"<[START]>","color":"green","bold":true,"underlined":false,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/check/start"},"hover_event":{"action":"show_text","value":[{"text":"Challenge will start immediately after clicking.","color":"green"}]}}

execute if score started aihunter_dummy matches 1 run tellraw @s {"text":"<[Cancel Current Challage]>","color":"dark_red","bold":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/cancel"},"hover_event":{"action":"show_text","value":[{"text":"Current challenge will be cancelled.","color":"dark_red"}]}}

tellraw @s ""
tellraw @s {"text":"<Settings Menu>","color":"white","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/menu/1"},"hover_event":{"action":"show_text","value":[{"text":"Go to settings menu, where you can customise your challenge.","color":"white"}]}}


tellraw @s ""
execute if score potato aihunter_dummy matches 0 run tellraw @s [{"text":"<Potato Device Mode: OFF>","color":"red","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/potato"},"hover_event":{"action":"show_text","value":[{"text":"If 'ON', you can play with render & simulation distance < 8, although few features may be disabled.","color":"red"}]}}]

execute if score potato aihunter_dummy matches 1 run tellraw @s [{"text":"<Potato Device Mode: ON>","color":"yellow","click_event":{"action":"run_command","command":"/function kyleong:aihunter/settings/potato"},"hover_event":{"action":"show_text","value":[{"text":"If 'ON', you can play with render & simulation distance < 8, although few features may be disabled.","color":"yellow"}]}}]


tellraw @s ""
tellraw @s {"text":"[URL] The pack was inspired by Dream's manhunt videos!","color":"gold","underlined":true,"click_event":{"action":"open_url","url":"https://www.youtube.com/watch?v=O60zJzhYGEA&t=1s"},"hover_event":{"action":"show_text","value":[{"text":"Please go see'2 Minecraft Speedrunners VS Terminator' by Dream. (URL To: Youtube.com)","color":"gold"}]}}


tellraw @s ""
tellraw @s {"text":"<Other Credits>","color":"gold","underlined":true,"click_event":{"action":"run_command","command":"/function kyleong:aihunter/credits"},"hover_event":{"action":"show_text","value":[{"text":"Please go see other credits!","color":"gold"}]}}

tellraw @s {"text":"----------------------------------------","color":"aqua","bold":true}
