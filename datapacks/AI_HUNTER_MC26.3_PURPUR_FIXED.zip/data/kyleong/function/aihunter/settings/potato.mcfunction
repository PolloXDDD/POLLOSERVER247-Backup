#if change #returnrage, also need to change in aihunter/set

execute if score started aihunter_dummy matches 0 run scoreboard players add potato aihunter_dummy 1

execute unless score potato aihunter_dummy matches 0..1 run scoreboard players set potato aihunter_dummy 0

execute if score potato aihunter_dummy matches 0 run scoreboard players set #retuenrange aihunter_dummy 1350

execute if score potato aihunter_dummy matches 1 run scoreboard players set #returnrange aihunter_dummy 390

execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/menu


execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
