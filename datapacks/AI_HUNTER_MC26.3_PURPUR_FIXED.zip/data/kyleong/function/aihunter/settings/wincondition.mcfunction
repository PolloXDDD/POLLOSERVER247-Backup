
execute if score started aihunter_dummy matches 0 run scoreboard players add wincondition aihunter_dummy 1

execute unless score wincondition aihunter_dummy matches 0..6 run scoreboard players set wincondition aihunter_dummy 0

execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/settings/menu/1


execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
