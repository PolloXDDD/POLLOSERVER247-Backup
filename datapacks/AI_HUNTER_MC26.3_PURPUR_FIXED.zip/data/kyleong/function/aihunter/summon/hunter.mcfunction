execute store result score existing aihunter_dummy if entity @e[type=minecraft:vindicator,tag=aihunter]
execute unless score hunters aihunter_dummy matches 1..50 run scoreboard players set hunters aihunter_dummy 1
execute if score hunters aihunter_dummy matches 20.. run gamerule minecraft:max_entity_cramming 60
scoreboard players operation #spawn_remaining aihunter_dummy = hunters aihunter_dummy
scoreboard players operation #spawn_remaining aihunter_dummy -= existing aihunter_dummy
execute if score #spawn_remaining aihunter_dummy matches 1..50 run function kyleong:aihunter/summon/one
