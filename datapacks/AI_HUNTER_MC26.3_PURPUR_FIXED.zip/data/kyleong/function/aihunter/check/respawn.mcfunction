execute store result score existing aihunter_dummy if entity @e[type=minecraft:vindicator,tag=aihunter]

execute store result score #armor aihunter_dummy if entity @e[type=minecraft:armor_stand,tag=aihunter]

execute if score existing aihunter_dummy < #armor aihunter_dummy run kill @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter]

execute if score existing aihunter_dummy > #armor aihunter_dummy run function kyleong:aihunter/summon/stand

execute if score existing aihunter_dummy > #armor aihunter_dummy as @e[type=minecraft:armor_stand,tag=aihunter,predicate=kyleong:aihunter/fresh] run function kyleong:aihunter/summon/set

scoreboard players operation existing aihunter_dummy += simulation aihunter_dummy

execute if score hunters aihunter_dummy < existing aihunter_dummy run kill @e[limit=1,sort=nearest,type=minecraft:vindicator,tag=aihunter]

execute as @e[type=minecraft:area_effect_cloud,tag=aihunter_name] unless predicate kyleong:aihunter/name_has_hunter run kill @s

execute unless score #checkcd aihunter_dummy matches 1.. if score hunters aihunter_dummy > existing aihunter_dummy run function kyleong:aihunter/respawn

execute if score #checkcd aihunter_dummy matches 1.. run scoreboard players remove #checkcd aihunter_dummy 1

