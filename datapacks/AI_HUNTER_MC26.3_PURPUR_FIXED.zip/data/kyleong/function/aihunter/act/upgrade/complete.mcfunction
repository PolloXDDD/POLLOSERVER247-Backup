##as at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)
#reset things

scoreboard players set @s aihunter_arrow 0

scoreboard players set @s aihunter_potion 0


#lv4: +diamond chestplate & leggings

execute if score @s aihunter_upgrade matches 3 run function kyleong:aihunter/act/upgrade/level/4


#lv3: +iron helmet & leggings

execute if score @s aihunter_upgrade matches 2 run function kyleong:aihunter/act/upgrade/level/3


#lv2: +iron chesplate & boots, stone axe

execute if score @s aihunter_upgrade matches 1 run function kyleong:aihunter/act/upgrade/level/2


#lv1: +wooden axe

execute unless score @s aihunter_upgrade matches 1.. run function kyleong:aihunter/act/upgrade/level/1


#check if resume chasing

scoreboard players set @s aihunter_uptimer -999

scoreboard players set @s aihunter_intent 0

execute if score @s aihunter_upgrade matches 1 if predicate kyleong:aihunter/chance/30 run scoreboard players set @s aihunter_intent 1

execute if score @s aihunter_upgrade matches 2 if predicate kyleong:aihunter/chance/10 run scoreboard players set @s aihunter_intent 1

execute if score @s aihunter_upgrade matches 3 if predicate kyleong:aihunter/chance/5 run scoreboard players set @s aihunter_intent 1

execute if score dimension aihunter_dummy matches 2 run scoreboard players set @s aihunter_intent 0
