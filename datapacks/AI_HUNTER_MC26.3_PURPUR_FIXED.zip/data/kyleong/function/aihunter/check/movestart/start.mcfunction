scoreboard players set #movestart aihunter_dummy 0

execute as @a run function kyleong:aihunter/check/movestart/clear

execute unless score aheadtime aihunter_dummy matches 1.. run schedule function kyleong:aihunter/check/movestart/loop 2t


bossbar set minecraft:aihunter_ms players @a

tellraw @a {"text":"Hunters Will Be Activated Immediately After Any Target Moves.","color":"red"}
