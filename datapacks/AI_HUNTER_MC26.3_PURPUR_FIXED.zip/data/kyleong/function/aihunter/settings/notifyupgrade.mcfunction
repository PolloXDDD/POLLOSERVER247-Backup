
scoreboard players add notifyupgrade aihunter_dummy 1

execute unless score notifyupgrade aihunter_dummy matches 0..1 run scoreboard players set notifyupgrade aihunter_dummy 0

function kyleong:aihunter/settings/menu/2



