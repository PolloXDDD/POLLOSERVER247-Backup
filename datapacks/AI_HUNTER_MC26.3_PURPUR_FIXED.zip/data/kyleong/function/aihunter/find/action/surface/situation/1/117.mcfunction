#1a=jump
#oo
#oh
#xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 if block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/surface/situation/1/a

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 minecraft:snow[layers=1] if block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/surface/situation/1/a


#1b=build jump
#_o
#xh
#xh

execute unless score @s aihunter_busy matches 1.. unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] if block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/surface/situation/1/b


#1c=break above
#_x
#xh
#xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 if block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 unless block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/surface/situation/1/c

execute unless score @s aihunter_busy matches 1.. unless block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] unless block ~ ~2.5 ~ #kyleong:aihunter/passable_117 run function kyleong:aihunter/find/action/surface/situation/1/c


#1d=break feet
#_x|xo
#oh|oh
#xh|xh

execute unless score @s aihunter_busy matches 1.. if block ^ ^1.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^2.5 ^0.5 #kyleong:aihunter/passable_117 unless block ^ ^2.5 ^0.5 minecraft:snow[layers=1] run function kyleong:aihunter/find/action/surface/situation/1/d
