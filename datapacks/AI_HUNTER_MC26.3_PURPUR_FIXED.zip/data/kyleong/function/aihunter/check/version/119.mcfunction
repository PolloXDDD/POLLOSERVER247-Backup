execute if block ~ ~ ~ minecraft:frogspawn

scoreboard players set version aihunter_dummy 119
