##as at @e[type=minecraft:vindicator,tag=aihunter] (every 6t)
#timer count down

execute if score @s aihunter_uptimer matches 1.. run scoreboard players remove @s aihunter_uptimer 6

execute if score @s aihunter_uptimer matches -10..0 run function kyleong:aihunter/act/upgrade/complete


execute if entity @p[distance=..6,gamemode=!creative,gamemode=!spectator,team=!aihunter] run scoreboard players set @s aihunter_intent 1

execute if entity @p[distance=..12,gamemode=!creative,gamemode=!spectator,team=!aihunter] if score @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] aihunter_hp matches ..60 run scoreboard players set @s aihunter_intent 0

execute as @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] run function kyleong:aihunter/animation/upgrade
