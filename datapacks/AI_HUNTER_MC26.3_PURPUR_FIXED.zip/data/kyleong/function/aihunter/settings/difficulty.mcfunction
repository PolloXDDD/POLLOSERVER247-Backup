
execute if score started aihunter_dummy matches 0 run scoreboard players add difficulty aihunter_dummy 1

execute unless score difficulty aihunter_dummy matches 1..4 run scoreboard players set difficulty aihunter_dummy 1

execute if score started aihunter_dummy matches 0 run function kyleong:aihunter/settings/menu/1


execute if score started aihunter_dummy matches 1 run function kyleong:aihunter/message/unchange
