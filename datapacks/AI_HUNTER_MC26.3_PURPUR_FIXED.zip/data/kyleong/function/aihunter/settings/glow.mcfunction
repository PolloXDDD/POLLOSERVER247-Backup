
scoreboard players add glow aihunter_dummy 1

execute unless score glow aihunter_dummy matches 0..1 run scoreboard players set glow aihunter_dummy 0

function kyleong:aihunter/settings/menu/1

execute if score glow aihunter_dummy matches 0 as @e[type=minecraft:armor_stand,tag=aihunter] run data merge entity @s {"Glowing":0b}

execute if score glow aihunter_dummy matches 1 as @e[type=minecraft:armor_stand,tag=aihunter] run data merge entity @s {"Glowing":1b}



